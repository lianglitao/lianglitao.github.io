// 3D风向游戏主脚本

// 全局变量
let scene, camera, renderer;
let tree, clouds = [];
let particleSystem, particles;
let currentWindLevel = 0;
let windSpeed = 0;

// 小球相关变量
let balls = [];
let ballGeometry, ballMaterial;
let mouse = new THREE.Vector2();
let raycaster = new THREE.Raycaster();

// 风级配置
const windConfig = {
    0: { speed: 0, particleCount: 0, treeSway: 0, cloudSpeed: 0 },
    1: { speed: 0.1, particleCount: 50, treeSway: 0.01, cloudSpeed: 0.005 },
    2: { speed: 0.2, particleCount: 100, treeSway: 0.02, cloudSpeed: 0.01 },
    3: { speed: 0.3, particleCount: 150, treeSway: 0.03, cloudSpeed: 0.015 },
    4: { speed: 0.4, particleCount: 200, treeSway: 0.04, cloudSpeed: 0.02 },
    5: { speed: 0.5, particleCount: 250, treeSway: 0.05, cloudSpeed: 0.025 },
    6: { speed: 0.6, particleCount: 300, treeSway: 0.06, cloudSpeed: 0.03 },
    7: { speed: 0.7, particleCount: 350, treeSway: 0.07, cloudSpeed: 0.035 },
    8: { speed: 0.8, particleCount: 400, treeSway: 0.08, cloudSpeed: 0.04 },
    9: { speed: 0.9, particleCount: 450, treeSway: 0.09, cloudSpeed: 0.045 },
    10: { speed: 1.0, particleCount: 500, treeSway: 0.1, cloudSpeed: 0.05 },
    11: { speed: 1.2, particleCount: 550, treeSway: 0.12, cloudSpeed: 0.06 },
    12: { speed: 1.5, particleCount: 600, treeSway: 0.15, cloudSpeed: 0.075 }
};

// 初始化场景
function init() {
    // 创建场景
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    
    // 创建相机
    camera = new THREE.PerspectiveCamera(
        75,
        (window.innerWidth - 250) / (window.innerHeight - 80),
        0.1,
        1000
    );
    camera.position.set(0, 10, 20);
    camera.lookAt(0, 0, 0);
    
    // 创建渲染器
    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('wind-canvas'), antialias: true });
    renderer.setSize(window.innerWidth - 250, window.innerHeight - 80);
    renderer.shadowMap.enabled = true;
    
    // 添加灯光
    addLights();
    
    // 创建地面
    createGround();
    
    // 创建树
    createTree();
    
    // 创建云朵
    createClouds();
    
    // 创建粒子系统
    createParticleSystem();
    
    // 初始化小球资源 - 增大球的大小
    ballGeometry = new THREE.SphereGeometry(2.0, 16, 16); // 半径从1.0扩大1倍到2.0
    ballMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xff6b35, // 更鲜艳的颜色，更易观察
        metalness: 0.5,
        roughness: 0.3
    });
    
    // 添加事件监听器
    addEventListeners();
    
    // 开始动画循环
    animate();
}

// 添加灯光
function addLights() {
    // 环境光
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    // 方向光（太阳光）
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 20, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
}

// 创建地面
function createGround() {
    const groundGeometry = new THREE.PlaneGeometry(100, 100);
    const groundMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x32cd32,
        roughness: 0.8,
        metalness: 0.2
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
}

// 创建树
function createTree() {
    // 创建组
    tree = new THREE.Group();
    
    // 树干
    const trunkGeometry = new THREE.CylinderGeometry(0.5, 0.8, 5, 8);
    const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x8b4513 });
    const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
    trunk.position.y = 2.5;
    trunk.castShadow = true;
    tree.add(trunk);
    
    // 树冠（3层）
    for (let i = 0; i < 3; i++) {
        const crownGeometry = new THREE.ConeGeometry(3 - i, 4 - i, 8);
        const crownMaterial = new THREE.MeshStandardMaterial({ color: 0x228b22 });
        const crown = new THREE.Mesh(crownGeometry, crownMaterial);
        crown.position.y = 6 + i * 2;
        crown.castShadow = true;
        tree.add(crown);
    }
    
    tree.position.set(0, 0, 0);
    scene.add(tree);
}

// 创建云朵
function createClouds() {
    const cloudCount = 5;
    
    for (let i = 0; i < cloudCount; i++) {
        const cloud = new THREE.Group();
        
        // 云朵由多个球体组成
        const cloudGeometry = new THREE.SphereGeometry(1, 16, 16);
        const cloudMaterial = new THREE.MeshStandardMaterial({ 
            color: 0xffffff,
            roughness: 1,
            metalness: 0,
            flatShading: false
        });
        
        // 创建云朵形状 - 水平排列为主
        const sphereCount = 8;
        for (let j = 0; j < sphereCount; j++) {
            const sphere = new THREE.Mesh(cloudGeometry, cloudMaterial);
            // 主要在水平方向分布，垂直方向变化较小
            sphere.position.set(
                (j - sphereCount/2) * 0.8 + (Math.random() - 0.5) * 0.5,
                (Math.random() - 0.5) * 1.5,
                (Math.random() - 0.5) * 1.5
            );
            sphere.scale.set(
                1.0 + Math.random() * 0.6,
                0.8 + Math.random() * 0.4,
                0.8 + Math.random() * 0.4
            );
            cloud.add(sphere);
        }
        
        // 设置云朵位置 - 更分散的分布
        cloud.position.set(
            (Math.random() - 0.5) * 60,
            12 + Math.random() * 8,
            (Math.random() - 0.5) * 60
        );
        
        clouds.push(cloud);
        scene.add(cloud);
    }
}

// 创建粒子系统
function createParticleSystem() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 600;
    
    // 粒子位置数组
    const positions = new Float32Array(particleCount * 3);
    
    // 初始化粒子位置
    for (let i = 0; i < particleCount * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 100;
        positions[i + 1] = Math.random() * 20;
        positions[i + 2] = (Math.random() - 0.5) * 100;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    // 粒子材质
    const particleMaterial = new THREE.PointsMaterial({
        color: 0xffffff,
        size: 0.2,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });
    
    // 创建粒子系统
    particleSystem = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particleSystem);
    
    // 存储粒子引用
    particles = particleGeometry.attributes.position.array;
}

// 更新粒子系统
function updateParticles() {
    const config = windConfig[currentWindLevel];
    
    for (let i = 0; i < particles.length; i += 3) {
        // 只有当粒子数量超过当前索引时才显示和更新
        if (i / 3 < config.particleCount) {
            // 粒子随风吹动 - 更平滑的运动
            particles[i] += windSpeed * 0.05;
            // 减少垂直方向的随机抖动
            particles[i + 1] += (Math.random() - 0.5) * 0.02;
            
            // 粒子循环
            if (particles[i] > 50) {
                particles[i] = -50;
                particles[i + 1] = Math.random() * 20;
                particles[i + 2] = (Math.random() - 0.5) * 100;
            }
        } else {
            // 隐藏超出数量的粒子
            particles[i + 1] = -100;
        }
    }
    
    particleSystem.geometry.attributes.position.needsUpdate = true;
}

// 更新树的摇摆
function updateTree() {
    const config = windConfig[currentWindLevel];
    const time = Date.now() * 0.001;
    
    // 树干摇摆
    tree.rotation.z = Math.sin(time * 2) * config.treeSway;
    
    // 树冠摇摆
    for (let i = 1; i < tree.children.length; i++) {
        const crown = tree.children[i];
        crown.rotation.z = Math.sin(time * 2 + i) * config.treeSway * 1.5;
    }
}

// 更新云朵
function updateClouds() {
    const config = windConfig[currentWindLevel];
    
    clouds.forEach((cloud, index) => {
        // 云朵随风吹动
        cloud.position.x += config.cloudSpeed;
        
        // 云朵循环
        if (cloud.position.x > 60) {
            cloud.position.x = -60;
            cloud.position.y = 10 + Math.random() * 10;
        }
        
        // 云朵上下浮动
        cloud.position.y += Math.sin(Date.now() * 0.001 + index) * 0.01;
    });
}

// 设置风级
function setWindLevel(level) {
    currentWindLevel = level;
    const config = windConfig[level];
    windSpeed = config.speed;
    
    // 更新UI
    document.getElementById('current-level').textContent = `${level}级 ${getWindDescription(level)}`;
    
    // 更新按钮状态
    document.querySelectorAll('.wind-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-wind-level="${level}"]`).classList.add('active');
}

// 获取风级描述
function getWindDescription(level) {
    const descriptions = [
        '无风', '软风', '轻风', '微风', '和风', '清风', '强风',
        '疾风', '大风', '烈风', '狂风', '暴风', '飓风'
    ];
    return descriptions[level] || '';
}

// 添加事件监听器
function addEventListeners() {
    // 风级按钮点击事件
    document.querySelectorAll('.wind-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const level = parseInt(btn.dataset.windLevel);
            setWindLevel(level);
        });
    });
    
    // 窗口大小变化事件
    window.addEventListener('resize', () => {
        camera.aspect = (window.innerWidth - 250) / (window.innerHeight - 80);
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth - 250, window.innerHeight - 80);
    });
    
    // 鼠标点击事件 - 发射小球
    renderer.domElement.addEventListener('click', onMouseClick);
}

// 鼠标点击事件处理
function onMouseClick(event) {
    // 计算鼠标在画布上的位置
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    
    // 使用射线投射计算点击位置
    raycaster.setFromCamera(mouse, camera);
    
    // 创建小球
    createBall();
}

// 创建小球
function createBall() {
    // 确保射线方向正确
    raycaster.setFromCamera(mouse, camera);
    
    // 创建小球网格
    const ball = new THREE.Mesh(ballGeometry, ballMaterial);
    
    // 设置小球初始位置（相机位置前方一点）
    ball.position.copy(camera.position);
    ball.position.add(camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(2));
    
    // 设置小球物理属性 - 更合理的物理参数
    ball.userData = {
        velocity: new THREE.Vector3(),
        gravity: new THREE.Vector3(0, -0.02, 0), // 减小重力
        life: 2000, // 延长生命周期
        windInfluence: 0.01 // 风力影响系数
    };
    
    // 计算小球发射方向（朝向点击点）
    const shootDirection = new THREE.Vector3();
    raycaster.ray.direction.multiplyScalar(3); // 适当的发射速度
    ball.userData.velocity.copy(shootDirection.copy(raycaster.ray.direction));
    
    // 启用阴影
    ball.castShadow = true;
    ball.receiveShadow = true;
    
    // 添加到场景和数组
    scene.add(ball);
    balls.push(ball);
}

// 更新小球
function updateBalls() {
    for (let i = balls.length - 1; i >= 0; i--) {
        const ball = balls[i];
        const userData = ball.userData;
        
        // 应用重力
        userData.velocity.add(userData.gravity);
        
        // 应用风力影响
        userData.velocity.x += windSpeed * userData.windInfluence;
        
        // 更新位置
        ball.position.add(userData.velocity);
        
        // 地面碰撞检测与弹跳效果 - 只有在绿色平台上才会弹跳
        const ballRadius = 2.0; // 球的半径
        const groundSize = 50; // 地面的半宽（100/2）
        
        // 检查球是否在绿色平台（地面）范围内
        if (ball.position.y <= ballRadius && 
            Math.abs(ball.position.x) <= groundSize && 
            Math.abs(ball.position.z) <= groundSize) {
            // 限制球的位置在地面之上
            ball.position.y = ballRadius;
            
            // 弹跳效果 - 反转垂直速度并减少能量（摩擦）
            userData.velocity.y *= -0.8; // 反弹系数
            
            // 水平速度衰减（地面摩擦）
            userData.velocity.x *= 0.99;
            userData.velocity.z *= 0.99;
        }
        
        // 树碰撞检测与反弹效果
        // 简化处理：将树视为一个球体，半径3，位置在(0, 5.5, 0)
        const treeCenter = new THREE.Vector3(0, 5.5, 0); // 树的中心位置
        const treeRadius = 3.0; // 树的有效碰撞半径
        const ballToTree = ball.position.clone().sub(treeCenter);
        const distance = ballToTree.length();
        
        if (distance < ballRadius + treeRadius) {
            // 发生碰撞，计算碰撞法线
            const normal = ballToTree.normalize();
            
            // 计算反弹速度：反射速度向量
            const dotProduct = userData.velocity.dot(normal);
            userData.velocity.sub(normal.multiplyScalar(2 * dotProduct));
            
            // 减少反弹能量
            userData.velocity.multiplyScalar(0.8);
            
            // 确保球不会卡在树里面
            const overlap = (ballRadius + treeRadius) - distance;
            ball.position.add(normal.multiplyScalar(overlap));
        }
        
        // 球与球之间的碰撞检测
        for (let j = i + 1; j < balls.length; j++) {
            const otherBall = balls[j];
            const otherUserData = otherBall.userData;
            
            // 计算两球之间的距离
            const distance = ball.position.distanceTo(otherBall.position);
            const ballRadius = 2.0;
            
            if (distance < ballRadius * 2) {
                // 发生碰撞，计算碰撞法线
                const normal = ball.position.clone().sub(otherBall.position).normalize();
                
                // 计算相对速度
                const relativeVelocity = userData.velocity.clone().sub(otherUserData.velocity);
                
                // 计算速度在法线方向上的分量
                const velocityAlongNormal = relativeVelocity.dot(normal);
                
                // 如果两球正在分离，不需要处理
                if (velocityAlongNormal > 0) continue;
                
                // 计算恢复系数（弹性）
                const restitution = 0.8;
                
                // 计算冲量标量
                const j = -(1 + restitution) * velocityAlongNormal / 2; // 两个质量相同的球
                
                // 应用冲量
                userData.velocity.add(normal.clone().multiplyScalar(j));
                otherUserData.velocity.sub(normal.clone().multiplyScalar(j));
                
                // 分离重叠的球
                const overlap = ballRadius * 2 - distance;
                const separation = normal.clone().multiplyScalar(overlap / 2);
                ball.position.add(separation);
                otherBall.position.sub(separation);
            }
        }
        
        // 更新生命周期
        userData.life--;
        
        // 只有当生命周期结束时才移除
        if (userData.life <= 0) {
            scene.remove(ball);
            balls.splice(i, 1);
        }
    }
}

// 动画循环
function animate() {
    requestAnimationFrame(animate);
    
    // 更新粒子系统
    updateParticles();
    
    // 更新树
    updateTree();
    
    // 更新云朵
    updateClouds();
    
    // 更新小球
    updateBalls();
    
    // 渲染场景
    renderer.render(scene, camera);
}

// 初始化游戏
window.addEventListener('DOMContentLoaded', init);

// 设置初始风级
setWindLevel(0);