#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Windows杀毒软件 - 4.0版
自研核心功能，减少外部依赖
"""

import os
import sys
import subprocess
import shutil
import ctypes
import time
import stat
import threading
import queue
import hashlib
import re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# 仅在Windows系统上导入winreg
winreg = None
if sys.platform.startswith('win'):
    try:
        import winreg
    except ImportError:
        pass


class MalwareScanner:
    """自研恶意软件扫描器"""
    
    def __init__(self):
        self.signatures = self._load_signatures()
        self.is_windows = sys.platform.startswith('win')
    
    def _load_signatures(self):
        """加载恶意软件签名库"""
        # 自研签名库，可扩展
        signatures = {
            # 常见恶意软件哈希值（示例）
            "e7d7f1b4c675c81b48b690e8f2d1c3a0": "恶意软件A",
            "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6": "恶意软件B",
            "f1e2d3c4b5a6f7e8d9c0b1a2f3e4d5c6": "恶意软件C",
            # 恶意文件扩展名
            "extensions": [".exe", ".dll", ".scr", ".bat", ".cmd", ".vbs", ".js", ".wsf"],
            # 恶意进程名
            "processes": ["malware.exe", "virus.exe", "trojan.exe"],
            # 恶意注册表项
            "registry": [
                r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\Malware",
                r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\Virus"
            ]
        }
        return signatures
    
    def calculate_hash(self, file_path):
        """计算文件哈希值"""
        try:
            hasher = hashlib.md5()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b''):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except:
            return None
    
    def scan_file(self, file_path):
        """扫描单个文件"""
        if not os.path.isfile(file_path):
            return False, "不是文件"
        
        # 检查文件扩展名
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext in self.signatures["extensions"]:
            # 计算文件哈希
            file_hash = self.calculate_hash(file_path)
            if file_hash and file_hash in self.signatures:
                return True, f"发现恶意软件：{self.signatures[file_hash]}"
        
        return False, "文件安全"
    
    def scan_directory(self, directory, recursive=True):
        """扫描目录"""
        results = []
        try:
            if recursive:
                for root, dirs, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        is_malicious, msg = self.scan_file(file_path)
                        if is_malicious:
                            results.append((file_path, msg))
            else:
                for item in os.listdir(directory):
                    item_path = os.path.join(directory, item)
                    if os.path.isfile(item_path):
                        is_malicious, msg = self.scan_file(item_path)
                        if is_malicious:
                            results.append((item_path, msg))
        except Exception as e:
            results.append((directory, f"扫描错误：{e}"))
        
        return results
    
    def scan_running_processes(self):
        """扫描运行中的进程"""
        malicious_processes = []
        
        if self.is_windows:
            # Windows系统使用WMIC
            try:
                output = subprocess.check_output("wmic process get name", shell=True, text=True)
                processes = output.strip().split('\n')[1:]
                for process in processes:
                    process_name = process.strip()
                    if process_name.lower() in self.signatures["processes"]:
                        malicious_processes.append(process_name)
            except:
                pass
        else:
            # 非Windows系统使用ps命令
            try:
                output = subprocess.check_output("ps aux | awk '{print $11}'", shell=True, text=True)
                processes = output.strip().split('\n')
                for process in processes:
                    process_name = os.path.basename(process.strip())
                    if process_name.lower() in self.signatures["processes"]:
                        malicious_processes.append(process_name)
            except:
                pass
        
        return malicious_processes
    
    def scan_registry(self):
        """扫描注册表（仅Windows）"""
        malicious_entries = []
        
        if not self.is_windows or winreg is None:
            return malicious_entries
        
        try:
            for entry in self.signatures["registry"]:
                try:
                    key_path, value_name = entry.rsplit('\\', 1)
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_READ)
                    winreg.QueryValueEx(key, value_name)
                    malicious_entries.append(entry)
                    winreg.CloseKey(key)
                except FileNotFoundError:
                    continue
                except:
                    continue
        except:
            pass
        
        return malicious_entries


class SystemCleaner:
    """自研系统清理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
        self.temp_dirs = self._get_temp_dirs()
    
    def _get_temp_dirs(self):
        """获取系统临时目录"""
        temp_dirs = []
        
        # 系统临时目录
        if self.is_windows:
            temp_dirs.append(os.environ.get('TEMP', 'C:\\Windows\\Temp'))
            temp_dirs.append(os.environ.get('TMP', 'C:\\Windows\\Temp'))
            # 用户临时目录
            user_temp = os.path.join(os.environ.get('USERPROFILE', 'C:\\Users\\Default'), 'AppData', 'Local', 'Temp')
            temp_dirs.append(user_temp)
        else:
            # 非Windows系统
            temp_dirs.append('/tmp')
            if 'HOME' in os.environ:
                temp_dirs.append(os.path.join(os.environ['HOME'], '.cache'))
        
        return list(set(temp_dirs))
    
    def _is_file_in_use(self, file_path):
        """检查文件是否被占用"""
        try:
            with open(file_path, 'a'):
                pass
            return False
        except:
            return True
    
    def _get_file_size(self, file_path):
        """获取文件大小"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0
    
    def clean_temp_files(self, confirm=True):
        """清理临时文件"""
        results = {
            'total_files': 0,
            'cleaned_files': 0,
            'failed_files': 0,
            'total_size': 0,
            'cleaned_size': 0,
            'logs': []
        }
        
        for temp_dir in self.temp_dirs:
            if not os.path.exists(temp_dir):
                results['logs'].append(f"跳过：{temp_dir}（目录不存在）")
                continue
            
            results['logs'].append(f"\n开始清理：{temp_dir}")
            
            try:
                for root, dirs, files in os.walk(temp_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        results['total_files'] += 1
                        file_size = self._get_file_size(file_path)
                        results['total_size'] += file_size
                        
                        try:
                            # 检查文件是否被占用
                            if self._is_file_in_use(file_path):
                                results['logs'].append(f"跳过：{file_path}（文件被占用）")
                                results['failed_files'] += 1
                                continue
                            
                            # 尝试删除文件
                            os.chmod(file_path, stat.S_IWRITE)  # 确保有写权限
                            os.unlink(file_path)
                            results['logs'].append(f"已删除：{file_path}")
                            results['cleaned_files'] += 1
                            results['cleaned_size'] += file_size
                        except Exception as e:
                            results['logs'].append(f"失败：{file_path} - {e}")
                            results['failed_files'] += 1
                    
                    # 尝试删除空目录
                    for dir_name in dirs:
                        dir_path = os.path.join(root, dir_name)
                        try:
                            os.rmdir(dir_path)
                            results['logs'].append(f"已删除目录：{dir_path}")
                        except:
                            pass
            except Exception as e:
                results['logs'].append(f"清理错误：{temp_dir} - {e}")
        
        return results
    
    def clean_browser_cache(self, browser=None):
        """清理浏览器缓存"""
        # 支持的浏览器
        browsers = {
            'chrome': [
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data\Default\Cache'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data\Default\Cookies')
            ],
            'edge': [
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data\Default\Cache'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data\Default\Cookies')
            ],
            'firefox': [
                os.path.join(os.environ.get('APPDATA', ''), r'Mozilla\Firefox\Profiles')
            ]
        }
        
        results = {
            'browser': browser,
            'cleaned': 0,
            'logs': []
        }
        
        if not browser:
            # 清理所有支持的浏览器
            for browser_name, paths in browsers.items():
                for path in paths:
                    if os.path.exists(path):
                        try:
                            if os.path.isdir(path):
                                shutil.rmtree(path)
                            else:
                                os.unlink(path)
                            results['cleaned'] += 1
                            results['logs'].append(f"已清理：{path}")
                        except Exception as e:
                            results['logs'].append(f"清理失败：{path} - {e}")
        else:
            # 清理指定浏览器
            if browser.lower() in browsers:
                for path in browsers[browser.lower()]:
                    if os.path.exists(path):
                        try:
                            if os.path.isdir(path):
                                shutil.rmtree(path)
                            else:
                                os.unlink(path)
                            results['cleaned'] += 1
                            results['logs'].append(f"已清理：{path}")
                        except Exception as e:
                            results['logs'].append(f"清理失败：{path} - {e}")
            else:
                results['logs'].append(f"不支持的浏览器：{browser}")
        
        return results


class ThirdPartyTools:
    """第三方工具管理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
        # 获取当前脚本所在目录，用于存放预制工具
        self.tools_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        
        # 确保工具目录存在
        if not os.path.exists(self.tools_dir):
            os.makedirs(self.tools_dir, exist_ok=True)
        
        # 工具配置 - 使用本地预制工具
        self.tools = {
            'process_explorer': {
                'name': 'Process Explorer',
                'local_path': os.path.join(self.tools_dir, 'procexp.exe'),
                'description': '微软官方进程管理工具',
                'expected_size': 0  # 可配置预期文件大小，用于验证
            },
            'geek_uninstaller': {
                'name': 'Geek Uninstaller',
                'local_path': os.path.join(self.tools_dir, 'geek.exe'),
                'description': '轻量高效的软件卸载工具',
                'expected_size': 0  # 可配置预期文件大小，用于验证
            }
        }
    
    def check_tool_exists(self, tool_name):
        """检查工具是否存在"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        tool = self.tools[tool_name]
        
        # 检查工具文件是否存在
        if os.path.exists(tool['local_path']):
            # 检查文件大小（可选）
            if tool['expected_size'] > 0:
                actual_size = os.path.getsize(tool['local_path'])
                if actual_size >= tool['expected_size']:
                    return True, f"{tool['name']} 已就绪"
                else:
                    return False, f"{tool['name']} 文件不完整，请重新放置到工具目录"
            return True, f"{tool['name']} 已就绪"
        else:
            # 特殊处理geek.7z文件
            if tool_name == 'geek_uninstaller':
                geek_7z_path = os.path.join(self.tools_dir, 'geek.7z')
                if os.path.exists(geek_7z_path):
                    return False, f"找到 {os.path.basename(geek_7z_path)}，但需要解压。请手动解压并将 {os.path.basename(tool['local_path'])} 放置到 {self.tools_dir} 目录"
            return False, f"{tool['name']} 未找到，请将 {os.path.basename(tool['local_path'])} 放置到 {self.tools_dir} 目录"
    
    def run_process_explorer(self):
        """运行Process Explorer"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        # 检查工具是否存在
        exists, msg = self.check_tool_exists('process_explorer')
        if not exists:
            return False, msg
        
        # 运行工具
        try:
            tool = self.tools['process_explorer']
            subprocess.Popen(tool['local_path'], shell=True)
            return True, f"已启动 {tool['name']}"
        except Exception as e:
            return False, f"启动 {self.tools['process_explorer']['name']} 失败: {e}"
    
    def run_geek_uninstaller(self):
        """运行Geek Uninstaller"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        # 检查工具是否存在
        exists, msg = self.check_tool_exists('geek_uninstaller')
        if not exists:
            return False, msg
        
        # 运行工具
        try:
            tool = self.tools['geek_uninstaller']
            subprocess.Popen(tool['local_path'], shell=True)
            return True, f"已启动 {tool['name']}"
        except Exception as e:
            return False, f"启动 {self.tools['geek_uninstaller']['name']} 失败: {e}"


class StartupManager:
    """自研启动项管理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
    
    def get_startup_items(self):
        """获取启动项列表"""
        startup_items = []
        
        if self.is_windows:
            # Windows系统启动项位置
            startup_locations = [
                # 注册表位置
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
                # 启动文件夹
                os.path.join(os.environ.get('APPDATA', ''), r'Microsoft\Windows\Start Menu\Programs\Startup'),
                os.path.join(os.environ.get('ALLUSERSPROFILE', ''), r'Microsoft\Windows\Start Menu\Programs\Startup')
            ]
            
            # 读取注册表启动项
            for hkey, path in startup_locations[:4]:
                if winreg is None:
                    continue
                try:
                    key = winreg.OpenKey(hkey, path, 0, winreg.KEY_READ)
                    try:
                        index = 0
                        while True:
                            name, value, _ = winreg.EnumValue(key, index)
                            startup_items.append((name, value, 'registry'))
                            index += 1
                    except OSError:
                        pass
                    winreg.CloseKey(key)
                except:
                    pass
            
            # 读取启动文件夹
            for folder in startup_locations[4:]:
                if os.path.exists(folder):
                    for item in os.listdir(folder):
                        item_path = os.path.join(folder, item)
                        startup_items.append((item, item_path, 'folder'))
        
        return startup_items
    
    def disable_startup_item(self, name, location):
        """禁用启动项"""
        try:
            if location == 'registry':
                # 注册表启动项，添加.disabled后缀
                pass
            elif location == 'folder':
                # 启动文件夹，重命名添加.disabled后缀
                new_path = location + '.disabled'
                os.rename(location, new_path)
                return True, f"已禁用：{os.path.basename(location)}"
            return False, "不支持的操作"
        except Exception as e:
            return False, f"禁用失败：{e}"


class AVScanner:
    """杀毒软件主类，封装所有功能"""
    
    def __init__(self, output_queue=None):
        self.is_windows = sys.platform.startswith('win')
        self.output_queue = output_queue  # 用于GUI输出的队列
        self.malware_scanner = MalwareScanner()
        self.system_cleaner = SystemCleaner()
        self.startup_manager = StartupManager()
        self.third_party_tools = ThirdPartyTools()
        # 尝试查找mpcmdrun.exe作为备选
        self.mpcmdrun_path = self._find_mpcmdrun() if self.is_windows else None
    
    def _log(self, message):
        """记录日志，支持GUI和命令行"""
        if self.output_queue:
            self.output_queue.put(message)
        else:
            print(message)
    
    def _find_mpcmdrun(self):
        """查找mpcmdrun.exe的路径"""
        possible_paths = [
            r'C:\Program Files\Windows Defender\MpCmdRun.exe',
            r'C:\Program Files (x86)\Windows Defender\MpCmdRun.exe',
            r'C:\ProgramData\Microsoft\Windows Defender\Platform\*\MpCmdRun.exe'
        ]
        
        for path in possible_paths:
            if '*' in path:
                # 处理通配符路径
                base_path = Path(path.rsplit('*', 1)[0])
                if base_path.exists():
                    # 找到最新版本的目录
                    try:
                        latest_version = sorted([d for d in base_path.iterdir() if d.is_dir()], reverse=True)[0]
                        mp_path = latest_version / 'MpCmdRun.exe'
                        if mp_path.exists():
                            return str(mp_path)
                    except IndexError:
                        continue
            else:
                if os.path.exists(path):
                    return path
        
        return None
    
    def is_admin(self):
        """检查是否以管理员权限运行"""
        if not self.is_windows:
            # 非Windows系统返回False
            return False
            
        try:
            # 更可靠的管理员权限检测
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except AttributeError:
            # 兼容不同Windows版本
            if winreg is not None:
                try:
                    # 尝试通过访问受限注册表项来检测
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", 0, winreg.KEY_READ)
                    winreg.CloseKey(key)
                    return True
                except PermissionError:
                    return False
                except:
                    return False
            return False
        except:
            return False
    
    def run_as_admin(self):
        """以管理员权限重新运行程序"""
        if not self.is_windows:
            return
            
        try:
            # 获取当前脚本的完整路径
            script_path = os.path.abspath(sys.argv[0])
            
            # 构建命令行参数
            params = ' '.join(sys.argv[1:])
            
            # 使用ShellExecuteW以管理员权限重新运行
            result = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, f'"{script_path}" {params}', None, 1
            )
            
            # 检查是否成功
            if result <= 32:
                self._log(f"错误：无法以管理员权限运行程序，错误码：{result}")
        except Exception as e:
            self._log(f"错误：提权过程中发生异常：{e}")
    
    def scan(self, scan_type="quick", path=None):
        """执行病毒扫描，优先使用Windows Defender，自研扫描为备选"""
        if self.is_windows and self.mpcmdrun_path:
            # 使用Windows Defender扫描
            self._log(f"\n=== 开始Windows Defender扫描 ===")
            self._log(f"扫描类型：{scan_type}")
            if path:
                self._log(f"扫描路径：{path}")
        
            # 构建扫描命令
            cmd = [self.mpcmdrun_path, "-Scan"]
        
            if scan_type == "quick":
                cmd.append("-ScanType 1")
            elif scan_type == "full":
                cmd.append("-ScanType 2")
            elif scan_type == "custom" and path:
                cmd.append(f"-ScanType 3")
                cmd.append(f"-File {path}")
            else:
                self._log("错误：无效的扫描类型或路径")
                return False
        
            # 添加额外参数以获取详细输出
            cmd.append("-Trace -Level 0x10")
        
            try:
                # 执行扫描命令并实时显示输出
                process = subprocess.Popen(
                    cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    text=True,
                    shell=True
                )
            
                while True:
                    output = process.stdout.readline()
                    if output == '' and process.poll() is not None:
                        break
                    if output:
                        self._log(output.strip())
            
                return_code = process.poll()
                if return_code == 0:
                    self._log("\n=== 扫描完成：未发现威胁 ===")
                    return True
                else:
                    self._log(f"\n=== 扫描完成：发现威胁，请查看以上输出 ===")
                    return False
                    
            except Exception as e:
                self._log(f"错误：Windows Defender扫描过程中发生异常：{e}")
                # 异常时回退到自研扫描
                self._log("回退到自研病毒扫描")
        
        # 自研病毒扫描作为备选
        self._log(f"\n=== 开始自研病毒扫描 ===")
        self._log(f"扫描类型：{scan_type}")
        
        results = {
            'malicious_files': [],
            'malicious_processes': [],
            'malicious_registry': []
        }
        
        if scan_type == "quick":
            # 快速扫描：系统关键区域
            self._log("快速扫描：扫描系统关键区域和运行进程")
            
            # 扫描运行中的进程
            results['malicious_processes'] = self.malware_scanner.scan_running_processes()
            if results['malicious_processes']:
                self._log(f"发现可疑进程：{', '.join(results['malicious_processes'])}")
            else:
                self._log("未发现可疑进程")
            
            # 扫描注册表
            results['malicious_registry'] = self.malware_scanner.scan_registry()
            if results['malicious_registry']:
                self._log(f"发现可疑注册表项：{', '.join(results['malicious_registry'])}")
            else:
                self._log("未发现可疑注册表项")
            
            # 扫描临时目录
            temp_dirs = self.system_cleaner._get_temp_dirs()
            for temp_dir in temp_dirs:
                self._log(f"扫描临时目录：{temp_dir}")
                malicious_files = self.malware_scanner.scan_directory(temp_dir, recursive=False)
                results['malicious_files'].extend(malicious_files)
        
        elif scan_type == "full":
            # 全盘扫描：扫描所有驱动器
            self._log("全盘扫描：扫描所有驱动器")
            
            if self.is_windows:
                # Windows系统获取所有驱动器
                try:
                    drives = [f"{chr(c)}:" for c in range(65, 91) if os.path.exists(f"{chr(c)}:")]
                except:
                    drives = ['C:']
            else:
                # 非Windows系统扫描根目录
                drives = ['/']
            
            for drive in drives:
                self._log(f"扫描驱动器：{drive}")
                malicious_files = self.malware_scanner.scan_directory(drive)
                results['malicious_files'].extend(malicious_files)
        
        elif scan_type == "custom" and path:
            # 自定义扫描：扫描指定路径
            self._log(f"自定义扫描：{path}")
            results['malicious_files'] = self.malware_scanner.scan_directory(path)
        
        else:
            self._log("错误：无效的扫描类型或路径")
            return False
        
        # 显示扫描结果
        if results['malicious_files']:
            self._log(f"\n=== 扫描结果 ===")
            self._log(f"发现 {len(results['malicious_files'])} 个可疑文件：")
            for file_path, msg in results['malicious_files']:
                self._log(f"  {file_path} - {msg}")
        else:
            self._log("\n=== 扫描完成：未发现威胁 ===")
        
        return True
    
    def clean_temp(self):
        """清理系统临时文件"""
        self._log(f"\n=== 准备清理临时文件 ===")
        self._log(f"清理目标：{', '.join(self.system_cleaner._get_temp_dirs())}")
        
        # 调用自研清理器
        results = self.system_cleaner.clean_temp_files(confirm=False)
        
        # 显示清理报告
        for log in results['logs']:
            self._log(log)
        
        self._log(f"\n=== 清理报告 ===")
        self._log(f"总文件数：{results['total_files']}")
        self._log(f"成功删除：{results['cleaned_files']} 个文件")
        self._log(f"释放空间：{results['cleaned_size'] / (1024 * 1024):.2f} MB")
        self._log(f"失败文件数：{results['failed_files']}")
        
        return True
    
    def run_all(self):
        """执行全部功能"""
        self._log("=== 执行全部功能 ===")
        
        # 先执行快速扫描
        scan_result = self.scan(scan_type="quick")
        
        # 再执行清理
        clean_result = self.clean_temp()
        
        return scan_result and clean_result
    
    def get_startup_items(self):
        """获取启动项列表"""
        return self.startup_manager.get_startup_items()
    
    def disable_startup_item(self, name, location):
        """禁用启动项"""
        return self.startup_manager.disable_startup_item(name, location)


class AVGUI:
    """杀毒软件GUI类"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("梁陈杀毒 4.0复活版")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # 创建输出队列和AVScanner实例
        self.output_queue = queue.Queue()
        self.av_scanner = AVScanner(self.output_queue)
        
        # 创建GUI组件
        self.create_widgets()
        
        # 启动输出更新线程
        self.running = True
        self.update_thread = threading.Thread(target=self.update_output, daemon=True)
        self.update_thread.start()
        
        # 检查管理员权限
        self.check_admin()
    
    def create_widgets(self):
        """创建GUI组件"""
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标题
        title_label = ttk.Label(main_frame, text="梁陈杀毒 4.0复活版", font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # 创建功能按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(pady=10)
        
        # 第一行：病毒扫描功能
        scan_frame = ttk.LabelFrame(button_frame, text="自研病毒扫描", padding="10")
        scan_frame.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NSEW)
        
        self.quick_scan_btn = ttk.Button(scan_frame, text="快速扫描", width=20, command=self.quick_scan)
        self.quick_scan_btn.pack(pady=5)
        
        self.full_scan_btn = ttk.Button(scan_frame, text="全盘扫描", width=20, command=self.full_scan)
        self.full_scan_btn.pack(pady=5)
        
        self.custom_scan_btn = ttk.Button(scan_frame, text="指定路径扫描", width=20, command=self.custom_scan)
        self.custom_scan_btn.pack(pady=5)
        
        # 第二行：系统清理功能
        clean_frame = ttk.LabelFrame(button_frame, text="自研系统清理", padding="10")
        clean_frame.grid(row=0, column=1, padx=10, pady=10, sticky=tk.NSEW)
        
        self.clean_temp_btn = ttk.Button(clean_frame, text="清理临时文件", width=20, command=self.clean_temp)
        self.clean_temp_btn.pack(pady=5)
        
        self.clean_browser_btn = ttk.Button(clean_frame, text="清理浏览器缓存", width=20, command=self.clean_browser)
        self.clean_browser_btn.pack(pady=5)
        
        # 第三行：系统管理功能
        manage_frame = ttk.LabelFrame(button_frame, text="系统管理", padding="10")
        manage_frame.grid(row=0, column=2, padx=10, pady=10, sticky=tk.NSEW)
        
        self.startup_btn = ttk.Button(manage_frame, text="启动项管理", width=20, command=self.startup_manage)
        self.startup_btn.pack(pady=5)
        
        self.process_btn = ttk.Button(manage_frame, text="进程管理", width=20, command=self.process_manage)
        self.process_btn.pack(pady=5)
        
        # 第四行：其他功能
        other_frame = ttk.LabelFrame(button_frame, text="其他功能", padding="10")
        other_frame.grid(row=1, column=0, padx=10, pady=10, sticky=tk.NSEW, columnspan=3)
        
        self.popup_block_btn = ttk.Button(other_frame, text="弹窗拦截", width=20, command=self.popup_block)
        self.popup_block_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        self.uninstall_btn = ttk.Button(other_frame, text="卸载软件", width=20, command=self.uninstall_software)
        self.uninstall_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        self.run_all_btn = ttk.Button(other_frame, text="执行全部功能", width=20, command=self.run_all)
        self.run_all_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        # 创建输出区域
        output_frame = ttk.LabelFrame(main_frame, text="操作日志", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # 创建滚动条和文本框
        self.output_text = tk.Text(output_frame, wrap=tk.WORD, state=tk.DISABLED)
        scrollbar = ttk.Scrollbar(output_frame, orient=tk.VERTICAL, command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # 创建状态栏
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def check_admin(self):
        """检查管理员权限"""
        if not self.av_scanner.is_admin() and self.av_scanner.is_windows:
            response = messagebox.askyesno("权限提示", "当前未以管理员权限运行，某些功能可能无法正常使用。是否立即以管理员权限重新运行？")
            if response:
                self.av_scanner.run_as_admin()
                self.root.quit()
                sys.exit(0)
    
    def update_output(self):
        """更新输出文本框"""
        while self.running:
            try:
                message = self.output_queue.get(timeout=0.5)
                self.output_text.config(state=tk.NORMAL)
                self.output_text.insert(tk.END, message + "\n")
                self.output_text.see(tk.END)
                self.output_text.config(state=tk.DISABLED)
            except queue.Empty:
                continue
    
    def set_status(self, status):
        """设置状态栏文本"""
        self.status_var.set(status)
    
    def disable_buttons(self):
        """禁用所有按钮"""
        for btn in [
            self.quick_scan_btn, self.full_scan_btn, self.custom_scan_btn,
            self.clean_temp_btn, self.clean_browser_btn, self.startup_btn,
            self.process_btn, self.popup_block_btn, self.uninstall_btn,
            self.run_all_btn
        ]:
            btn.config(state=tk.DISABLED)
    
    def enable_buttons(self):
        """启用所有按钮"""
        for btn in [
            self.quick_scan_btn, self.full_scan_btn, self.custom_scan_btn,
            self.clean_temp_btn, self.clean_browser_btn, self.startup_btn,
            self.process_btn, self.popup_block_btn, self.uninstall_btn,
            self.run_all_btn
        ]:
            btn.config(state=tk.NORMAL)
    
    def quick_scan(self):
        """快速扫描"""
        def scan_thread():
            self.set_status("正在执行快速扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="quick")
            self.set_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def full_scan(self):
        """全盘扫描"""
        def scan_thread():
            self.set_status("正在执行全盘扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="full")
            self.set_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def custom_scan(self):
        """指定路径扫描"""
        path = filedialog.askdirectory(title="选择要扫描的目录")
        if path:
            def scan_thread():
                self.set_status("正在执行指定路径扫描...")
                self.disable_buttons()
                self.av_scanner.scan(scan_type="custom", path=path)
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=scan_thread, daemon=True).start()
    
    def clean_temp(self):
        """清理临时文件"""
        response = messagebox.askyesno("清理确认", "此操作将删除系统临时目录中的文件，是否继续？")
        if response:
            def clean_thread():
                self.set_status("正在清理临时文件...")
                self.disable_buttons()
                self.av_scanner.clean_temp()
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=clean_thread, daemon=True).start()
    
    def clean_browser(self):
        """清理浏览器缓存"""
        response = messagebox.askyesno("清理确认", "此操作将清理浏览器缓存文件，是否继续？")
        if response:
            def clean_thread():
                self.set_status("正在清理浏览器缓存...")
                self.disable_buttons()
                results = self.av_scanner.system_cleaner.clean_browser_cache()
                for log in results['logs']:
                    self.av_scanner._log(log)
                self.av_scanner._log(f"浏览器缓存清理完成，共清理 {results['cleaned']} 项")
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=clean_thread, daemon=True).start()
    
    def run_all(self):
        """执行全部功能"""
        response = messagebox.askyesno("全部功能确认", "此操作将先执行快速扫描，然后清理临时文件，是否继续？")
        if response:
            def all_thread():
                self.set_status("正在执行全部功能...")
                self.disable_buttons()
                self.av_scanner.run_all()
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=all_thread, daemon=True).start()
    
    def popup_block(self):
        """弹窗拦截功能"""
        messagebox.showinfo("开发中", "弹窗拦截功能正在开发中，敬请期待！")
        self.av_scanner._log("弹窗拦截功能：开发中")
    
    def startup_manage(self):
        """启动项管理功能"""
        if not self.av_scanner.is_windows:
            messagebox.showerror("错误", "此功能仅支持Windows系统")
            return
            
        # 创建启动项管理窗口
        startup_window = tk.Toplevel(self.root)
        startup_window.title("启动项管理")
        startup_window.geometry("800x600")
        
        # 创建列表框
        list_frame = ttk.Frame(startup_window, padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建树视图
        columns = ("name", "path", "type")
        tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        tree.heading("name", text="名称")
        tree.heading("path", text="路径")
        tree.heading("type", text="类型")
        
        # 设置列宽
        tree.column("name", width=150)
        tree.column("path", width=500)
        tree.column("type", width=100)
        
        # 添加滚动条
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 加载启动项
        def load_startup_items():
            # 清空现有数据
            for item in tree.get_children():
                tree.delete(item)
            
            # 获取启动项
            startup_items = self.av_scanner.get_startup_items()
            for name, path, item_type in startup_items:
                tree.insert("", tk.END, values=(name, path, item_type))
        
        # 禁用选中的启动项
        def disable_selected():
            selected_item = tree.selection()
            if selected_item:
                item = tree.item(selected_item[0])
                name, path, item_type = item["values"]
                success, msg = self.av_scanner.disable_startup_item(name, path)
                if success:
                    messagebox.showinfo("成功", msg)
                    load_startup_items()
                else:
                    messagebox.showerror("错误", msg)
        
        # 创建按钮框架
        btn_frame = ttk.Frame(startup_window, padding="10")
        btn_frame.pack(fill=tk.X)
        
        refresh_btn = ttk.Button(btn_frame, text="刷新列表", command=load_startup_items)
        refresh_btn.pack(side=tk.LEFT, padx=5)
        
        disable_btn = ttk.Button(btn_frame, text="禁用选中项", command=disable_selected)
        disable_btn.pack(side=tk.LEFT, padx=5)
        
        # 初始加载
        load_startup_items()
    
    def process_manage(self):
        """运行第三方进程管理器 Process Explorer"""
        def process_thread():
            self.set_status("正在启动Process Explorer...")
            self.av_scanner._log("=== 启动Process Explorer ===")
            
            # 运行第三方工具
            success, msg = self.av_scanner.third_party_tools.run_process_explorer()
            if success:
                self.av_scanner._log(msg)
            else:
                messagebox.showerror("错误", msg)
                self.av_scanner._log(f"错误：{msg}")
            
            self.set_status("就绪")
        
        threading.Thread(target=process_thread, daemon=True).start()
    
    def uninstall_software(self):
        """运行第三方卸载工具 Geek Uninstaller"""
        def uninstall_thread():
            self.set_status("正在启动Geek Uninstaller...")
            self.av_scanner._log("=== 启动Geek Uninstaller ===")
            
            # 运行第三方工具
            success, msg = self.av_scanner.third_party_tools.run_geek_uninstaller()
            if success:
                self.av_scanner._log(msg)
            else:
                messagebox.showerror("错误", msg)
                self.av_scanner._log(f"错误：{msg}")
            
            self.set_status("就绪")
        
        threading.Thread(target=uninstall_thread, daemon=True).start()
    
    def on_closing(self):
        """窗口关闭事件处理"""
        self.running = False
        self.root.quit()
        sys.exit(0)


def main():
    """主函数"""
    try:
        # 创建主窗口
        root = tk.Tk()
        app = AVGUI(root)
        
        # 设置窗口关闭事件
        root.protocol("WM_DELETE_WINDOW", app.on_closing)
        
        # 运行主循环
        root.mainloop()
    except KeyboardInterrupt:
        print("程序已退出")
    except Exception as e:
        print(f"发生错误：{e}")
        input("按Enter键退出...")


if __name__ == "__main__":
    main()