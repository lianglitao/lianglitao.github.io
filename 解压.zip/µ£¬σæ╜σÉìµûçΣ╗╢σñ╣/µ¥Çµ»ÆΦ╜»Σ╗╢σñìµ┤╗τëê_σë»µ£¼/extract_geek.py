#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import sys

def main():
    """主函数"""
    tools_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
    geek_7z_path = os.path.join(tools_dir, 'geek.7z')
    
    if not os.path.exists(geek_7z_path):
        print(f"错误：未找到文件 {geek_7z_path}")
        return 1
    
    try:
        # 尝试使用Python内置库或外部命令解压
        print(f"正在解压: {geek_7z_path}")
        
        # 检查是否安装了py7zr库
        try:
            import py7zr
            
            # 使用py7zr库解压
            with py7zr.SevenZipFile(geek_7z_path, mode='r') as z:
                z.extractall(tools_dir)
            
            print(f"解压完成: {tools_dir}")
            
        except ImportError:
            # 尝试使用系统命令（如果可用）
            print("py7zr库未安装，尝试使用系统命令...")
            
            # 尝试各种可能的7z命令
            seven_zip_commands = ['7z', '7za', 'p7zip', '7zr']
            found_command = None
            
            for cmd in seven_zip_commands:
                try:
                    result = subprocess.run([cmd, '--help'], capture_output=True, text=True, check=True)
                    if result.returncode == 0:
                        found_command = cmd
                        break
                except (FileNotFoundError, subprocess.CalledProcessError):
                    continue
            
            if found_command:
                # 使用找到的7z命令解压
                print(f"使用命令: {found_command}")
                result = subprocess.run([found_command, 'x', geek_7z_path, f'-o{tools_dir}'], 
                                      capture_output=True, text=True, check=True)
                print(f"解压输出: {result.stdout}")
                print(f"解压完成: {tools_dir}")
            else:
                # 尝试使用unar（如果可用）
                try:
                    result = subprocess.run(['unar', '-o', tools_dir, geek_7z_path], 
                                          capture_output=True, text=True, check=True)
                    print(f"使用unar解压成功")
                    print(f"解压输出: {result.stdout}")
                except (FileNotFoundError, subprocess.CalledProcessError):
                    print("错误：无法找到合适的解压工具")
                    print("请手动解压geek.7z文件，或将geek.exe直接放入tools目录")
                    return 1
        
        # 检查解压结果
        extracted_files = os.listdir(tools_dir)
        geek_found = False
        for file in extracted_files:
            if file.lower() == 'geek.exe':
                print(f"✓ 成功找到geek.exe: {os.path.join(tools_dir, file)}")
                geek_found = True
            elif file.lower().endswith('.exe'):
                print(f"找到可执行文件: {file}")
        
        if not geek_found:
            print("⚠️  未找到geek.exe，请检查解压结果")
            print(f"解压后的文件列表: {extracted_files}")
            return 1
        
        print("\n🎉 所有操作完成！")
        print(f"工具已准备就绪: {tools_dir}")
        return 0
        
    except Exception as e:
        print(f"解压失败: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())