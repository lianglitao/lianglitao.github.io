#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import urllib.request
import zipfile
import shutil

def download_file(url, output_path):
    """下载文件"""
    print(f"正在下载: {url}")
    print(f"保存到: {output_path}")
    
    # 确保目录存在
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # 下载文件
    urllib.request.urlretrieve(url, output_path)
    print(f"下载完成: {output_path}")

def extract_zip(zip_path, extract_dir):
    """解压ZIP文件"""
    print(f"正在解压: {zip_path}")
    print(f"解压到: {extract_dir}")
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
    print(f"解压完成: {extract_dir}")

def main():
    """主函数"""
    tools_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
    
    # 创建tools目录
    os.makedirs(tools_dir, exist_ok=True)
    
    try:
        # 下载Process Explorer
        procexp_url = 'https://download.sysinternals.com/files/ProcessExplorer.zip'
        procexp_zip = os.path.join(tools_dir, 'ProcessExplorer.zip')
        download_file(procexp_url, procexp_zip)
        
        # 解压Process Explorer
        extract_zip(procexp_zip, tools_dir)
        
        # 重命名或移动文件（如果需要）
        extracted_files = os.listdir(tools_dir)
        for file in extracted_files:
            if file.lower() == 'procexp.exe':
                print(f"Process Explorer已准备好: {os.path.join(tools_dir, file)}")
        
        # 清理zip文件
        os.remove(procexp_zip)
        print(f"已清理临时文件: {procexp_zip}")
        
        print("\n所有工具下载完成！")
        print(f"工具已保存到: {tools_dir}")
        print("Process Explorer已成功下载")
        print("\n注意：Geek Uninstaller的下载链接已失效")
        print("请手动下载Geek Uninstaller并将geek.exe放入tools目录")
        print("下载地址：https://geekuninstaller.com/")
        
    except Exception as e:
        print(f"下载失败: {e}")

if __name__ == "__main__":
    main()