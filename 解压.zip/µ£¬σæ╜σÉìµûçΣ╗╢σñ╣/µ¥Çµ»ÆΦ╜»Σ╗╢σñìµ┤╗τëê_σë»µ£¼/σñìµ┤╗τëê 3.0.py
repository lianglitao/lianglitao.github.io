#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Windows杀毒软件 - GUI版
适用于Windows 10及以上版本，通过调用Windows Defender实现病毒扫描，并提供系统临时文件清理功能。
"""

import os
import sys
import subprocess
import shutil
import ctypes
import time
import stat
import threading
import queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# 仅在Windows系统上导入winreg
winreg = None
if sys.platform.startswith('win'):
    try:
        import winreg
    except ImportError:
        pass


class AVScanner:
    """杀毒软件主类，封装所有功能"""
    
    def __init__(self, output_queue=None):
        self.is_windows = sys.platform.startswith('win')
        self.mpcmdrun_path = self._find_mpcmdrun() if self.is_windows else None
        self.temp_dir = os.environ.get('TEMP', os.environ.get('TMP', 'C:\\Windows\\Temp'))
        self.output_queue = output_queue  # 用于GUI输出的队列
    
    def _log(self, message):
        """记录日志，支持GUI和命令行"""
        if self.output_queue:
            self.output_queue.put(message)
        else:
            print(message)
    
    def _find_mpcmdrun(self):
        """查找mpcmdrun.exe的路径"""
        possible_paths = [
            r'C:\Program Files\Windows Defender\MpCmdRun.exe',
            r'C:\Program Files (x86)\Windows Defender\MpCmdRun.exe',
            r'C:\ProgramData\Microsoft\Windows Defender\Platform\*\MpCmdRun.exe'
        ]
        
        for path in possible_paths:
            if '*' in path:
                # 处理通配符路径
                base_path = Path(path.rsplit('*', 1)[0])
                if base_path.exists():
                    # 找到最新版本的目录
                    try:
                        latest_version = sorted([d for d in base_path.iterdir() if d.is_dir()], reverse=True)[0]
                        mp_path = latest_version / 'MpCmdRun.exe'
                        if mp_path.exists():
                            return str(mp_path)
                    except IndexError:
                        continue
            else:
                if os.path.exists(path):
                    return path
        
        return None
    
    def is_admin(self):
        """检查是否以管理员权限运行"""
        if not self.is_windows:
            # 非Windows系统返回False
            return False
            
        try:
            # 更可靠的管理员权限检测
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except AttributeError:
            # 兼容不同Windows版本
            if winreg is not None:
                try:
                    # 尝试通过访问受限注册表项来检测
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", 0, winreg.KEY_READ)
                    winreg.CloseKey(key)
                    return True
                except PermissionError:
                    return False
                except:
                    return False
            return False
        except:
            return False
    
    def run_as_admin(self):
        """以管理员权限重新运行程序"""
        if not self.is_windows:
            return
            
        try:
            # 获取当前脚本的完整路径
            script_path = os.path.abspath(sys.argv[0])
            
            # 构建命令行参数
            params = ' '.join(sys.argv[1:])
            
            # 使用ShellExecuteW以管理员权限重新运行
            result = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, f'"{script_path}" {params}', None, 1
            )
            
            # 检查是否成功
            if result <= 32:
                self._log(f"错误：无法以管理员权限运行程序，错误码：{result}")
        except Exception as e:
            self._log(f"错误：提权过程中发生异常：{e}")
    
    def scan(self, scan_type="quick", path=None):
        """执行病毒扫描
        
        Args:
            scan_type: 扫描类型，可选值：quick, full, custom
            path: 自定义扫描路径，仅当scan_type为custom时有效
        """
        if not self.is_windows:
            self._log("错误：杀毒功能仅支持Windows系统")
            return False
            
        if not self.mpcmdrun_path:
            self._log("错误：未找到MpCmdRun.exe，请确保已安装Windows Defender")
            return False
        
        self._log(f"\n=== 开始病毒扫描 ===")
        self._log(f"扫描类型：{scan_type}")
        if path:
            self._log(f"扫描路径：{path}")
        
        # 构建扫描命令
        cmd = [self.mpcmdrun_path, "-Scan"]
        
        if scan_type == "quick":
            cmd.append("-ScanType 1")
        elif scan_type == "full":
            cmd.append("-ScanType 2")
        elif scan_type == "custom" and path:
            cmd.append(f"-ScanType 3")
            cmd.append(f"-File {path}")
        else:
            self._log("错误：无效的扫描类型或路径")
            return False
        
        # 添加额外参数以获取详细输出
        cmd.append("-Trace -Level 0x10")
        
        try:
            # 执行扫描命令并实时显示输出
            process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                text=True,
                shell=True
            )
            
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    self._log(output.strip())
            
            return_code = process.poll()
            if return_code == 0:
                self._log("\n=== 扫描完成：未发现威胁 ===")
                return True
            else:
                self._log(f"\n=== 扫描完成：发现威胁，请查看以上输出 ===")
                return False
                
        except Exception as e:
            self._log(f"错误：扫描过程中发生异常：{e}")
            return False
    
    def _is_file_in_use(self, file_path):
        """检查文件是否被占用"""
        try:
            # 尝试以写入模式打开文件，若成功则文件未被占用
            with open(file_path, 'a'):
                pass
            return False
        except:
            return True
    
    def _get_file_size(self, file_path):
        """获取文件大小"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0
    
    def clean_temp(self):
        """清理系统临时文件"""
        if not self.is_windows:
            self._log("错误：清理功能仅支持Windows系统")
            return False
            
        self._log(f"\n=== 准备清理临时文件 ===")
        self._log(f"清理目标：{self.temp_dir}")
        
        total_files = 0
        total_size = 0
        failed_files = 0
        
        try:
            # 遍历临时目录
            for root, dirs, files in os.walk(self.temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    total_files += 1
                    total_size += self._get_file_size(file_path)
                    
                    try:
                        # 检查文件是否被占用
                        if self._is_file_in_use(file_path):
                            self._log(f"跳过：{file_path}（文件被占用）")
                            failed_files += 1
                            continue
                        
                        # 尝试删除文件
                        os.chmod(file_path, stat.S_IWRITE)  # 确保有写权限
                        os.unlink(file_path)
                        self._log(f"已删除：{file_path}")
                    except Exception as e:
                        self._log(f"失败：{file_path} - {e}")
                        failed_files += 1
                
                # 尝试删除空目录
                for dir_name in dirs:
                    dir_path = os.path.join(root, dir_name)
                    try:
                        os.rmdir(dir_path)
                        self._log(f"已删除目录：{dir_path}")
                    except:
                        pass
            
            # 生成清理报告
            cleaned_files = total_files - failed_files
            cleaned_size = total_size - sum(self._get_file_size(os.path.join(root, file)) 
                                           for root, dirs, files in os.walk(self.temp_dir) 
                                           for file in files)
            
            self._log(f"\n=== 清理报告 ===")
            self._log(f"总文件数：{total_files}")
            self._log(f"成功删除：{cleaned_files} 个文件")
            self._log(f"释放空间：{cleaned_size / (1024 * 1024):.2f} MB")
            self._log(f"失败文件数：{failed_files}")
            
            return True
            
        except Exception as e:
            self._log(f"错误：清理过程中发生异常：{e}")
            return False
    
    def run_all(self):
        """执行全部功能（先扫描后清理）"""
        self._log("=== 执行全部功能 ===")
        
        # 先执行快速扫描
        scan_result = self.scan(scan_type="quick")
        
        # 再执行清理
        clean_result = self.clean_temp()
        
        return scan_result and clean_result


class AVGUI:
    """杀毒软件GUI类"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Windows杀毒软件")
        self.root.geometry("800x600")
        self.root.resizable(True, True)
        
        # 设置图标（可选）
        # self.root.iconbitmap("icon.ico")
        
        # 创建输出队列和AVScanner实例
        self.output_queue = queue.Queue()
        self.av_scanner = AVScanner(self.output_queue)
        
        # 创建GUI组件
        self.create_widgets()
        
        # 启动输出更新线程
        self.running = True
        self.update_thread = threading.Thread(target=self.update_output, daemon=True)
        self.update_thread.start()
        
        # 检查管理员权限
        self.check_admin()
    
    def create_widgets(self):
        """创建GUI组件"""
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标题
        title_label = ttk.Label(main_frame, text="梁陈杀毒3.0复活版", font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # 创建功能按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(pady=10)
        
        # 第一行：病毒扫描功能
        scan_frame = ttk.LabelFrame(button_frame, text="病毒扫描", padding="10")
        scan_frame.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NSEW)
        
        self.quick_scan_btn = ttk.Button(scan_frame, text="快速扫描", width=20, command=self.quick_scan)
        self.quick_scan_btn.pack(pady=5)
        
        self.full_scan_btn = ttk.Button(scan_frame, text="全盘扫描", width=20, command=self.full_scan)
        self.full_scan_btn.pack(pady=5)
        
        self.custom_scan_btn = ttk.Button(scan_frame, text="指定路径扫描", width=20, command=self.custom_scan)
        self.custom_scan_btn.pack(pady=5)
        
        # 第二行：系统清理功能
        clean_frame = ttk.LabelFrame(button_frame, text="系统清理", padding="10")
        clean_frame.grid(row=0, column=1, padx=10, pady=10, sticky=tk.NSEW)
        
        self.clean_temp_btn = ttk.Button(clean_frame, text="清理临时文件", width=20, command=self.clean_temp)
        self.clean_temp_btn.pack(pady=5)
        
        # 第三行：系统管理功能
        manage_frame = ttk.LabelFrame(button_frame, text="系统管理", padding="10")
        manage_frame.grid(row=0, column=2, padx=10, pady=10, sticky=tk.NSEW)
        
        self.startup_btn = ttk.Button(manage_frame, text="启动项管理", width=20, command=self.startup_manage)
        self.startup_btn.pack(pady=5)
        
        self.process_btn = ttk.Button(manage_frame, text="进程管理", width=20, command=self.process_manage)
        self.process_btn.pack(pady=5)
        
        # 第四行：其他功能
        other_frame = ttk.LabelFrame(button_frame, text="其他功能", padding="10")
        other_frame.grid(row=1, column=0, padx=10, pady=10, sticky=tk.NSEW, columnspan=3)
        
        self.popup_block_btn = ttk.Button(other_frame, text="弹窗拦截", width=20, command=self.popup_block)
        self.popup_block_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        self.uninstall_btn = ttk.Button(other_frame, text="卸载软件", width=20, command=self.uninstall_software)
        self.uninstall_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        self.run_all_btn = ttk.Button(other_frame, text="执行全部功能", width=20, command=self.run_all)
        self.run_all_btn.pack(pady=5, side=tk.LEFT, padx=10)
        
        # 创建输出区域
        output_frame = ttk.LabelFrame(main_frame, text="操作日志", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # 创建滚动条和文本框
        self.output_text = tk.Text(output_frame, wrap=tk.WORD, state=tk.DISABLED)
        scrollbar = ttk.Scrollbar(output_frame, orient=tk.VERTICAL, command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # 创建状态栏
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def check_admin(self):
        """检查管理员权限"""
        if not self.av_scanner.is_admin() and self.av_scanner.is_windows:
            response = messagebox.askyesno("权限提示", "当前未以管理员权限运行，某些功能可能无法正常使用。是否立即以管理员权限重新运行？")
            if response:
                self.av_scanner.run_as_admin()
                self.root.quit()
                sys.exit(0)
    
    def update_output(self):
        """更新输出文本框"""
        while self.running:
            try:
                message = self.output_queue.get(timeout=0.5)
                self.output_text.config(state=tk.NORMAL)
                self.output_text.insert(tk.END, message + "\n")
                self.output_text.see(tk.END)
                self.output_text.config(state=tk.DISABLED)
            except queue.Empty:
                continue
    
    def set_status(self, status):
        """设置状态栏文本"""
        self.status_var.set(status)
    
    def disable_buttons(self):
        """禁用所有按钮"""
        self.quick_scan_btn.config(state=tk.DISABLED)
        self.full_scan_btn.config(state=tk.DISABLED)
        self.custom_scan_btn.config(state=tk.DISABLED)
        self.clean_temp_btn.config(state=tk.DISABLED)
        self.startup_btn.config(state=tk.DISABLED)
        self.process_btn.config(state=tk.DISABLED)
        self.popup_block_btn.config(state=tk.DISABLED)
        self.uninstall_btn.config(state=tk.DISABLED)
        self.run_all_btn.config(state=tk.DISABLED)
    
    def enable_buttons(self):
        """启用所有按钮"""
        self.quick_scan_btn.config(state=tk.NORMAL)
        self.full_scan_btn.config(state=tk.NORMAL)
        self.custom_scan_btn.config(state=tk.NORMAL)
        self.clean_temp_btn.config(state=tk.NORMAL)
        self.startup_btn.config(state=tk.NORMAL)
        self.process_btn.config(state=tk.NORMAL)
        self.popup_block_btn.config(state=tk.NORMAL)
        self.uninstall_btn.config(state=tk.NORMAL)
        self.run_all_btn.config(state=tk.NORMAL)
    
    def quick_scan(self):
        """快速扫描"""
        def scan_thread():
            self.set_status("正在执行快速扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="quick")
            self.set_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def full_scan(self):
        """全盘扫描"""
        def scan_thread():
            self.set_status("正在执行全盘扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="full")
            self.set_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def custom_scan(self):
        """指定路径扫描"""
        path = filedialog.askdirectory(title="选择要扫描的目录")
        if path:
            def scan_thread():
                self.set_status("正在执行指定路径扫描...")
                self.disable_buttons()
                self.av_scanner.scan(scan_type="custom", path=path)
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=scan_thread, daemon=True).start()
    
    def clean_temp(self):
        """清理临时文件"""
        response = messagebox.askyesno("清理确认", "此操作将删除系统临时目录中的文件，是否继续？")
        if response:
            def clean_thread():
                self.set_status("正在清理临时文件...")
                self.disable_buttons()
                self.av_scanner.clean_temp()
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=clean_thread, daemon=True).start()
    
    def run_all(self):
        """执行全部功能"""
        response = messagebox.askyesno("全部功能确认", "此操作将先执行快速扫描，然后清理临时文件，是否继续？")
        if response:
            def all_thread():
                self.set_status("正在执行全部功能...")
                self.disable_buttons()
                self.av_scanner.run_all()
                self.set_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=all_thread, daemon=True).start()
    
    def popup_block(self):
        """弹窗拦截功能"""
        messagebox.showinfo("开发中", "弹窗拦截功能正在开发中，敬请期待！")
        self.av_scanner._log("弹窗拦截功能：开发中")
    
    def startup_manage(self):
        """启动项管理功能"""
        if not self.av_scanner.is_windows:
            messagebox.showerror("错误", "此功能仅支持Windows系统")
            return
            
        def startup_thread():
            self.set_status("正在打开启动项管理...")
            self.av_scanner._log("=== 打开启动项管理 ===")
            
            try:
                # 使用ms-settings:startupapps打开Windows 10/11的启动项设置
                subprocess.run(["start", "ms-settings:startupapps"], shell=True, check=True)
                self.av_scanner._log("已打开Windows启动项设置")
            except Exception as e:
                # 兼容旧版本Windows
                try:
                    subprocess.run(["taskmgr.exe"], shell=True, check=True)
                    self.av_scanner._log("已打开任务管理器，请手动查看启动项")
                except Exception as e:
                    messagebox.showerror("错误", f"无法打开启动项管理：{e}")
                    self.av_scanner._log(f"错误：无法打开启动项管理 - {e}")
            
            self.set_status("就绪")
        
        threading.Thread(target=startup_thread, daemon=True).start()
    
    def uninstall_software(self):
        """卸载软件功能"""
        if not self.av_scanner.is_windows:
            messagebox.showerror("错误", "此功能仅支持Windows系统")
            return
            
        def uninstall_thread():
            self.set_status("正在打开软件卸载...")
            self.av_scanner._log("=== 打开软件卸载 ===")
            
            try:
                # 尝试打开内置的程序和功能
                subprocess.run(["start", "appwiz.cpl"], shell=True, check=True)
                self.av_scanner._log("已打开程序和功能")
            except Exception as e:
                # 兼容Windows 10/11
                try:
                    subprocess.run(["start", "ms-settings:appsfeatures"], shell=True, check=True)
                    self.av_scanner._log("已打开应用和功能设置")
                except Exception as e:
                    messagebox.showerror("错误", f"无法打开软件卸载：{e}")
                    self.av_scanner._log(f"错误：无法打开软件卸载 - {e}")
            
            self.set_status("就绪")
        
        threading.Thread(target=uninstall_thread, daemon=True).start()
    
    def process_manage(self):
        """进程管理功能"""
        if not self.av_scanner.is_windows:
            messagebox.showerror("错误", "此功能仅支持Windows系统")
            return
            
        def process_thread():
            self.set_status("正在打开任务管理器...")
            self.av_scanner._log("=== 打开进程管理 ===")
            
            try:
                # 打开任务管理器
                subprocess.run(["taskmgr.exe"], shell=True, check=True)
                self.av_scanner._log("已打开任务管理器")
            except Exception as e:
                messagebox.showerror("错误", f"无法打开任务管理器：{e}")
                self.av_scanner._log(f"错误：无法打开任务管理器 - {e}")
            
            self.set_status("就绪")
        
        threading.Thread(target=process_thread, daemon=True).start()
    
    def on_closing(self):
        """窗口关闭事件处理"""
        self.running = False
        self.root.quit()
        sys.exit(0)


def main():
    """主函数"""
    try:
        # 创建主窗口
        root = tk.Tk()
        app = AVGUI(root)
        
        # 设置窗口关闭事件
        root.protocol("WM_DELETE_WINDOW", app.on_closing)
        
        # 运行主循环
        root.mainloop()
    except KeyboardInterrupt:
        print("程序已退出")
    except Exception as e:
        print(f"发生错误：{e}")
        input("按Enter键退出...")


if __name__ == "__main__":
    main()
