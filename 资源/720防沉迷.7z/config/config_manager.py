import json
import os

class ConfigManager:
    def __init__(self, config_file=None):
        # 使用用户的AppData目录保存配置文件，避免权限问题
        if config_file is None:
            if os.name == 'nt':  # Windows系统
                # 获取用户的AppData目录
                appdata_dir = os.environ.get('APPDATA', os.path.expanduser('~'))
                # 创建应用程序配置目录
                config_dir = os.path.join(appdata_dir, '720防沉迷')
                if not os.path.exists(config_dir):
                    os.makedirs(config_dir)
                self.config_file = os.path.join(config_dir, 'config.json')
            else:
                # 非Windows系统，使用应用程序所在目录
                current_dir = os.path.dirname(os.path.abspath(__file__))
                app_dir = os.path.dirname(current_dir)
                self.config_file = os.path.join(app_dir, 'config.json')
        else:
            self.config_file = config_file
        self.default_config = {
            'password': '',  # 默认密码为空，首次运行时需要设置
            'protected_apps': [],  # 受保护的应用程序列表
            'autostart': False  # 是否开机自启
        }
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置文件"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                # 确保所有必要的配置项都存在
                for key, value in self.default_config.items():
                    if key not in config:
                        config[key] = value
                return config
            except Exception as e:
                print(f"加载配置文件失败: {e}")
                return self.default_config
        else:
            # 配置文件不存在，使用默认配置
            return self.default_config
    
    def save_config(self):
        """保存配置文件"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False
    
    def get(self, key, default=None):
        """获取配置项"""
        return self.config.get(key, default)
    
    def set(self, key, value):
        """设置配置项"""
        self.config[key] = value
        return self.save_config()
    
    def add_protected_app(self, app_path):
        """添加受保护的应用程序"""
        if app_path not in self.config['protected_apps']:
            self.config['protected_apps'].append(app_path)
            return self.save_config()
        return True
    
    def remove_protected_app(self, app_path):
        """移除受保护的应用程序"""
        if app_path in self.config['protected_apps']:
            self.config['protected_apps'].remove(app_path)
            return self.save_config()
        return True
    
    def get_protected_apps(self):
        """获取受保护的应用程序列表"""
        return self.config['protected_apps']
    
    def set_password(self, password):
        """设置密码"""
        return self.set('password', password)
    
    def get_password(self):
        """获取密码"""
        return self.get('password', '')
    
    def set_autostart(self, autostart):
        """设置开机自启"""
        return self.set('autostart', autostart)
    
    def get_autostart(self):
        """获取开机自启设置"""
        return self.get('autostart', False)
