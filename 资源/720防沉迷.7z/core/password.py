from config.config_manager import ConfigManager

class PasswordManager:
    def __init__(self):
        self.config_manager = ConfigManager()
    
    def verify_password(self, password):
        """验证密码是否正确"""
        stored_password = self.config_manager.get_password()
        return password == stored_password
    
    def set_password(self, password):
        """设置密码"""
        return self.config_manager.set_password(password)
    
    def change_password(self, old_password, new_password):
        """修改密码"""
        # 验证旧密码是否正确
        if not self.verify_password(old_password):
            return False
        # 设置新密码
        return self.set_password(new_password)
    
    def has_password_set(self):
        """检查是否已经设置了密码"""
        stored_password = self.config_manager.get_password()
        return stored_password != ''
    
    def reset_password(self):
        """重置密码（清空密码）"""
        return self.config_manager.set_password('')
