import os
import sys
from config.config_manager import ConfigManager

class AutoStartManager:
    def __init__(self):
        self.config_manager = ConfigManager()
        self.startup_folder = self._get_startup_folder()
        self.app_name = "720防沉迷"
        self.shortcut_name = f"{self.app_name}.lnk"
        self.shortcut_path = os.path.join(self.startup_folder, self.shortcut_name)
    
    def _get_startup_folder(self):
        """获取Windows启动目录路径"""
        if os.name == 'nt':  # 仅在Windows系统中运行
            try:
                # 获取当前用户的启动目录
                import winreg
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                                     r'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders')
                startup_folder = winreg.QueryValueEx(key, 'Startup')[0]
                winreg.CloseKey(key)
                return startup_folder
            except Exception as e:
                print(f"获取启动目录失败: {e}")
                # 返回默认路径
                return os.path.join(os.environ.get('APPDATA', ''), 
                                   r'Microsoft\Windows\Start Menu\Programs\Startup')
        else:
            # 非Windows系统返回空字符串
            return ''
    
    def _create_shortcut(self, target_path, shortcut_path):
        """创建快捷方式"""
        if os.name == 'nt':
            try:
                import win32com.client
                shell = win32com.client.Dispatch('WScript.Shell')
                shortcut = shell.CreateShortCut(shortcut_path)
                shortcut.TargetPath = target_path
                shortcut.WorkingDirectory = os.path.dirname(target_path)
                shortcut.Save()
                return True
            except Exception as e:
                print(f"创建快捷方式失败: {e}")
                return False
        return False
    
    def set_autostart(self, enable=True):
        """设置开机自启"""
        if os.name != 'nt':
            print("仅支持Windows系统")
            return False
        
        if enable:
            # 获取当前可执行文件路径
            if getattr(sys, 'frozen', False):
                # 打包后的可执行文件
                exe_path = sys.executable
            else:
                # 脚本文件
                exe_path = os.path.abspath(__file__)
            
            # 创建快捷方式
            success = self._create_shortcut(exe_path, self.shortcut_path)
            if success:
                self.config_manager.set_autostart(True)
            return success
        else:
            # 取消自启动
            if os.path.exists(self.shortcut_path):
                try:
                    os.remove(self.shortcut_path)
                    self.config_manager.set_autostart(False)
                    return True
                except Exception as e:
                    print(f"删除快捷方式失败: {e}")
                    return False
            return True
    
    def is_autostart_enabled(self):
        """检查是否已设置开机自启"""
        if os.name != 'nt':
            return False
        return os.path.exists(self.shortcut_path)
    
    def get_autostart_status(self):
        """获取自启动状态"""
        return {
            "enabled": self.is_autostart_enabled(),
            "startup_folder": self.startup_folder,
            "shortcut_path": self.shortcut_path
        }
