from datetime import datetime

class TimeManager:
    def __init__(self):
        # 定义允许的时间段
        # 早上8:00-9:00
        self.morning_start = 8
        self.morning_end = 9
        # 晚上8:00-9:00
        self.evening_start = 20
        self.evening_end = 21
    
    def is_in_allowed_time(self):
        """检查当前时间是否在允许的时间段内"""
        now = datetime.now()
        current_hour = now.hour
        
        # 检查是否在早上允许的时间段
        if self.morning_start <= current_hour < self.morning_end:
            return True
        
        # 检查是否在晚上允许的时间段
        if self.evening_start <= current_hour < self.evening_end:
            return True
        
        return False
    
    def get_current_time(self):
        """获取当前时间"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def get_allowed_times(self):
        """获取允许的时间段"""
        return {
            "morning": f"{self.morning_start}:00 - {self.morning_end}:00",
            "evening": f"{self.evening_start}:00 - {self.evening_end}:00"
        }
