import os
import time
import ctypes
from ctypes import wintypes
from config.config_manager import ConfigManager
from core.time_manager import TimeManager
from core.password import PasswordManager
from ui.password_window import PasswordWindow
import tkinter as tk

class AppMonitor:
    def __init__(self):
        self.config_manager = ConfigManager()
        self.time_manager = TimeManager()
        self.password_manager = PasswordManager()
        self.running = False
        self.root = None  # 主线程的Tkinter根窗口
        self.previous_processes = set()  # 上一次的进程列表
        self.system_processes = self._get_system_processes()  # 系统进程列表
        self.verified_apps = []  # 刚刚验证通过的应用程序列表（临时白名单）
    
    def set_root_window(self, root):
        """设置主线程的Tkinter根窗口"""
        self.root = root
    
    def get_desktop_shortcuts(self):
        """获取桌面上的所有快捷方式"""
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        shortcuts = []
        
        if os.path.exists(desktop_path):
            for item in os.listdir(desktop_path):
                item_path = os.path.join(desktop_path, item)
                if os.path.isfile(item_path) and item.endswith(".lnk"):
                    shortcuts.append(item_path)
        
        return shortcuts
    
    def is_protected_app(self, app_path):
        """检查应用程序是否在保护列表中"""
        # 实时获取最新的保护列表，确保修改后立刻生效
        protected_apps = self.config_manager.get_protected_apps()
        
        # 打印调试信息，查看保护列表和应用程序路径
        print(f"保护列表: {protected_apps}")
        print(f"检查应用: {app_path}")
        
        # 检查应用程序路径是否在保护列表中
        # 忽略大小写和路径分隔符差异
        app_path_lower = app_path.lower().replace('/', '\\')
        for protected_app in protected_apps:
            protected_app_lower = protected_app.lower().replace('/', '\\')
            if app_path_lower == protected_app_lower:
                print(f"应用 {app_path} 在保护列表中")
                return True
        
        print(f"应用 {app_path} 不在保护列表中")
        return False
    
    def need_password(self):
        """检查是否需要密码验证"""
        # 检查是否在允许的时间段内
        if self.time_manager.is_in_allowed_time():
            return False
        
        # 检查是否设置了密码
        if not self.password_manager.has_password_set():
            return False
        
        return True
    
    def start_monitoring(self):
        """开始监控应用程序启动"""
        self.running = True
        print("开始监控应用程序启动...")
        
        # 开始监控进程创建
        while self.running:
            try:
                self._monitor_process_creation()
                time.sleep(1)
            except Exception as e:
                print(f"监控错误: {e}")
                time.sleep(1)
    
    def stop_monitoring(self):
        """停止监控"""
        self.running = False
        print("停止监控应用程序启动")
        # 根窗口由主线程管理，不在这里销毁
        # if self.root:
        #     self.root.destroy()
        #     self.root = None
    
    def _get_system_processes(self):
        """获取系统进程列表"""
        # 常见的系统进程名称
        return {
            'svchost.exe', 'explorer.exe', 'winlogon.exe', 'csrss.exe',
            'lsass.exe', 'services.exe', 'smss.exe', 'wininit.exe',
            'System', 'System Idle Process', 'conhost.exe', 'dwm.exe',
            'taskhostw.exe', 'RuntimeBroker.exe', 'SearchIndexer.exe',
            'backgroundTaskHost.exe', 'sihost.exe', 'shellExperienceHost.exe',
            'MoNotificationUx.exe', 'SystemSettings.exe', 'MsMpEng.exe',
            'WidgetBoard.exe', 'AggregatorHost.exe', 'MpDefenderCoreService.exe',
            'WidgetService.exe', 'SecurityHealthService.exe', 'SearchHost.exe',
            'MicrosoftStartFeedProvider.exe', 'StartMenuExperienceHost.exe',
            'dllhost.exe', 'WerFault.exe', 'audiodg.exe', 'spoolsv.exe',
            'taskeng.exe', 'taskhost.exe', 'svchost.exe', 'fontdrvhost.exe',
            'LsaIso.exe', 'msdtc.exe', 'smartscreen.exe', 'TabTip.exe'
        }
    
    def _is_system_process(self, process_name):
        """检查是否为系统进程"""
        return process_name.lower() in [p.lower() for p in self.system_processes]
    
    def _is_system_path(self, exe_path):
        """检查是否为系统路径"""
        system_paths = [
            'C:\\Windows\\',
            'C:\\ProgramData\\Microsoft\\',
            'C:\\Program Files\\WindowsApps\\Microsoft'
        ]
        return any(exe_path.startswith(path) for path in system_paths)
    
    def _monitor_process_creation(self):
        """监控进程创建（Windows API实现）"""
        try:
            import psutil
            # 获取当前运行的进程
            current_processes = set()
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    proc_info = proc.info
                    process_name = proc_info.get('name', '')
                    process_exe = proc_info.get('exe', '')
                    current_processes.add((proc_info['pid'], process_name, process_exe))
                except:
                    pass
            
            # 检测新启动的进程
            new_processes = current_processes - self.previous_processes
            if new_processes:
                for pid, name, exe in new_processes:
                    if exe and (exe.endswith('.exe') or exe.endswith('.pyw')):
                        # 检查是否为系统进程或系统路径
                        if not self._is_system_process(name) and not self._is_system_path(exe):
                            print(f"检测到新进程: {name} (PID: {pid}) - {exe}")
                            # 检查是否需要阻止
                            if self._should_block_process(exe):
                                print(f"需要阻止进程: {name} (PID: {pid}) - {exe}")
                                self._block_process(pid, name, exe)
                    # 系统进程或非可执行文件，跳过
                    else:
                        continue
            
            # 更新进程列表
            self.previous_processes = current_processes
            
        except ImportError:
            print("psutil库未安装，无法监控进程")
        except Exception as e:
            print(f"监控进程错误: {e}")
    
    def _should_block_process(self, exe_path):
        """检查是否应该阻止进程"""
        # 检查是否在临时白名单中
        if exe_path in self.verified_apps:
            print(f"应用 {exe_path} 在临时白名单中，跳过阻止")
            return False
        
        # 检查是否在允许的时间段内
        if self.time_manager.is_in_allowed_time():
            return False
        
        # 检查是否设置了密码
        if not self.password_manager.has_password_set():
            return False
        
        # 检查是否为受保护的应用程序
        if self.is_protected_app(exe_path):
            return True
        
        # 只监控自定义保护列表中的应用程序
        # 不再默认监控所有Program Files目录下的应用
        return False
    
    def _block_process(self, pid, name, exe):
        """阻止进程"""
        print(f"尝试阻止进程: {name} (PID: {pid}) - {exe}")
        
        # 首先终止进程，避免应用在密码验证期间继续运行
        self._terminate_process(pid, name)
        
        # 弹出密码验证窗口
        if self.root:
            # 创建一个变量来保存进程信息，确保回调函数能够访问到
            process_info = {'pid': pid, 'name': name, 'exe': exe}
            
            # 使用主线程的after方法来显示密码窗口，避免闪屏
            def show_password_window():
                def on_verify(success):
                    if success:
                        # 密码验证成功，重新启动应用
                        print(f"密码验证成功，重新启动应用: {process_info['name']}")
                        self._restart_application(process_info['exe'])
                    else:
                        # 密码验证失败，保持进程终止状态
                        print(f"密码验证失败，保持进程终止状态: {process_info['name']}")
                
                password_window = PasswordWindow(self.root, title="应用访问验证", callback=on_verify)
                password_window.show()
            
            # 在主线程中显示密码窗口
            self.root.after(0, show_password_window)
        else:
            # 没有根窗口，保持进程终止状态
            print(f"没有根窗口，保持进程终止状态: {name} (PID: {pid})")
    
    def _terminate_process(self, pid, name):
        """终止进程"""
        try:
            import psutil
            # 检查进程是否存在
            if psutil.pid_exists(pid):
                proc = psutil.Process(pid)
                # 尝试终止进程
                proc.terminate()
                # 等待进程终止
                try:
                    proc.wait(timeout=3)
                    print(f"已成功终止进程: {name} (PID: {pid})")
                except psutil.TimeoutExpired:
                    # 超时，尝试强制终止
                    proc.kill()
                    print(f"已强制终止进程: {name} (PID: {pid})")
            else:
                print(f"进程不存在: {name} (PID: {pid})")
        except Exception as e:
            print(f"终止进程失败: {e}")
    
    def _restart_application(self, exe_path):
        """重新启动应用程序"""
        try:
            import subprocess
            print(f"重新启动应用: {exe_path}")
            
            # 将应用添加到临时白名单，避免再次被拦截
            self.verified_apps.append(exe_path)
            # 设置一个定时器，3秒后从白名单中移除（足够应用启动）
            if self.root:
                self.root.after(3000, lambda: self._remove_from_verified(exe_path))
            
            # 启动应用程序
            subprocess.Popen([exe_path])
            print(f"应用启动成功: {exe_path}")
            print(f"临时白名单: {self.verified_apps}")
        except Exception as e:
            print(f"启动应用失败: {e}")
    
    def _remove_from_verified(self, exe_path):
        """从临时白名单中移除应用程序"""
        if exe_path in self.verified_apps:
            self.verified_apps.remove(exe_path)
            print(f"从临时白名单中移除应用: {exe_path}")
            print(f"临时白名单: {self.verified_apps}")
    
    def check_app_launch(self, app_path):
        """检查应用程序启动"""
        if self.is_protected_app(app_path):
            if self.need_password():
                # 需要密码验证
                return False, "需要密码验证"
            else:
                # 无需密码验证
                return True, "在允许的时间段内"
        else:
            # 不在保护列表中
            return True, "不在保护列表中"
    
    def verify_app_launch(self, app_path):
        """验证应用程序启动，弹出密码窗口"""
        result, message = self.check_app_launch(app_path)
        if not result:
            # 需要密码验证
            print(f"应用 {app_path} 需要密码验证")
            # 弹出密码窗口
            if self.root:
                def on_verify(success):
                    if success:
                        print("密码验证成功，允许启动应用")
                    else:
                        print("密码验证失败，阻止启动应用")
                
                password_window = PasswordWindow(self.root, title="应用访问验证", callback=on_verify)
                password_window.show()
                # 运行Tkinter事件循环
                self.root.update()
        return result
