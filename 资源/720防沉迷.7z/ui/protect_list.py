import tkinter as tk
from tkinter import messagebox, filedialog
from config.config_manager import ConfigManager
from ui.password_window import PasswordWindow

class ProtectListWindow:
    def __init__(self, parent=None):
        self.parent = parent
        self.window = None
        self.config_manager = ConfigManager()
        self.app_listbox = None
    
    def show(self):
        """显示保护列表管理窗口"""
        # 创建窗口
        self.window = tk.Toplevel(self.parent) if self.parent else tk.Tk()
        self.window.title("720防沉迷 - 保护列表")
        self.window.geometry("500x400")
        self.window.resizable(False, False)
        
        # 设置窗口为模态
        if self.parent:
            self.window.transient(self.parent)
            self.window.grab_set()
        
        # 居中显示
        self._center_window()
        
        # 创建界面元素
        self._create_widgets()
        
        # 显示窗口
        if not self.parent:
            self.window.mainloop()
    
    def _center_window(self):
        """居中显示窗口"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f"{width}x{height}+{x}+{y}")
    
    def _create_widgets(self):
        """创建界面元素"""
        # 创建主框架
        main_frame = tk.Frame(self.window, padx=20, pady=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = tk.Label(main_frame, text="受保护的应用程序列表", font=("Arial", 12, "bold"))
        title_label.pack(pady=(0, 10))
        
        # 应用列表框
        list_frame = tk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.app_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set)
        self.app_listbox.pack(fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.app_listbox.yview)
        
        # 加载应用列表
        self._load_app_list()
        
        # 按钮框架
        button_frame = tk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 添加按钮
        add_button = tk.Button(button_frame, text="添加应用", command=self._add_app)
        add_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # 删除按钮
        delete_button = tk.Button(button_frame, text="删除应用", command=self._delete_app)
        delete_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # 清空按钮
        clear_button = tk.Button(button_frame, text="清空列表", command=self._clear_list)
        clear_button.pack(side=tk.LEFT)
        
        # 提示信息
        tip_label = tk.Label(main_frame, text="提示: 此列表仅在未启用'保护桌面上的所有应用'时生效", fg="gray")
        tip_label.pack(pady=(10, 0))
    
    def _load_app_list(self):
        """加载应用列表"""
        # 清空列表
        self.app_listbox.delete(0, tk.END)
        
        # 加载受保护的应用程序
        protected_apps = self.config_manager.get_protected_apps()
        for app_path in protected_apps:
            # 显示应用名称（从路径中提取）
            app_name = app_path.split("\\")[-1] if "\\" in app_path else app_path.split("/")[-1]
            self.app_listbox.insert(tk.END, app_name)
    
    def _add_app(self):
        """添加应用程序"""
        # 打开文件选择对话框
        file_path = filedialog.askopenfilename(
            title="选择应用程序",
            filetypes=[("快捷方式", "*.lnk"), ("可执行文件", "*.exe"), ("所有文件", "*.*")]
        )
        
        if file_path:
            # 添加到保护列表
            success = self.config_manager.add_protected_app(file_path)
            if success:
                # 重新加载列表
                self._load_app_list()
                messagebox.showinfo("成功", "应用程序添加成功！")
            else:
                messagebox.showerror("错误", "应用程序添加失败！")
    
    def _delete_app(self):
        """删除应用程序"""
        # 获取选中的索引
        selected_index = self.app_listbox.curselection()
        if not selected_index:
            messagebox.showinfo("提示", "请选择要删除的应用程序")
            return
        
        # 弹出密码验证窗口
        def on_verify(success):
            if success:
                # 密码验证成功，删除应用
                self._do_delete_app(selected_index[0])
        
        password_window = PasswordWindow(self.window, title="删除应用验证", callback=on_verify)
        password_window.show()
    
    def _do_delete_app(self, index):
        """执行删除应用程序操作"""
        # 获取保护列表
        protected_apps = self.config_manager.get_protected_apps()
        # 删除选中的应用
        app_path = protected_apps[index]
        success = self.config_manager.remove_protected_app(app_path)
        
        if success:
            # 重新加载列表
            self._load_app_list()
            messagebox.showinfo("成功", "应用程序删除成功！")
        else:
            messagebox.showerror("错误", "应用程序删除失败！")
    
    def _clear_list(self):
        """清空列表"""
        # 确认清空
        if messagebox.askyesno("确认", "确定要清空保护列表吗？"):
            # 弹出密码验证窗口
            def on_verify(success):
                if success:
                    # 密码验证成功，清空列表
                    self._do_clear_list()
            
            password_window = PasswordWindow(self.window, title="清空列表验证", callback=on_verify)
            password_window.show()
    
    def _do_clear_list(self):
        """执行清空列表操作"""
        # 清空保护列表
        protected_apps = self.config_manager.get_protected_apps()
        for app_path in protected_apps:
            self.config_manager.remove_protected_app(app_path)
        
        # 重新加载列表
        self._load_app_list()
        messagebox.showinfo("成功", "保护列表已清空！")
