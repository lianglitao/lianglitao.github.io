import tkinter as tk
from tkinter import messagebox, ttk
import os
import sys
from core.password import PasswordManager
from core.autostart import AutoStartManager
from core.time_manager import TimeManager
from config.config_manager import ConfigManager
from ui.password_window import PasswordWindow

class SettingsWindow:
    def __init__(self, parent=None):
        self.parent = parent
        self.window = None
        self.password_manager = PasswordManager()
        self.autostart_manager = AutoStartManager()
        self.time_manager = TimeManager()
        self.config_manager = ConfigManager()
        
        # 变量
        self.old_password_var = None
        self.new_password_var = None
        self.confirm_password_var = None
        self.autostart_var = None
        self.protect_all_var = None
    
    def show(self):
        """显示设置窗口"""
        # 创建窗口
        self.window = tk.Toplevel(self.parent) if self.parent else tk.Tk()
        self.window.title("720防沉迷 - 设置")
        self.window.geometry("400x400")
        self.window.resizable(False, False)
        
        # 设置窗口为模态
        if self.parent:
            self.window.transient(self.parent)
            self.window.grab_set()
        
        # 居中显示
        self._center_window()
        
        # 创建界面元素
        self._create_widgets()
        
        # 显示窗口
        if not self.parent:
            self.window.mainloop()
    
    def _center_window(self):
        """居中显示窗口"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f"{width}x{height}+{x}+{y}")
    
    def _create_widgets(self):
        """创建界面元素"""
        # 创建主框架
        main_frame = tk.Frame(self.window, padx=20, pady=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标签页
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # 密码设置标签页
        password_frame = tk.Frame(notebook)
        notebook.add(password_frame, text="密码设置")
        self._create_password_tab(password_frame)
        
        # 系统设置标签页
        system_frame = tk.Frame(notebook)
        notebook.add(system_frame, text="系统设置")
        self._create_system_tab(system_frame)
        
        # 关于标签页
        about_frame = tk.Frame(notebook)
        notebook.add(about_frame, text="关于")
        self._create_about_tab(about_frame)
    
    def _create_password_tab(self, frame):
        """创建密码设置标签页"""
        # 旧密码
        old_password_label = tk.Label(frame, text="旧密码:")
        old_password_label.grid(row=0, column=0, sticky=tk.W, pady=(20, 10), padx=(20, 10))
        
        self.old_password_var = tk.StringVar()
        old_password_entry = tk.Entry(frame, textvariable=self.old_password_var, show="*")
        old_password_entry.grid(row=0, column=1, sticky=tk.EW, pady=(20, 10), padx=(0, 20))
        
        # 新密码
        new_password_label = tk.Label(frame, text="新密码:")
        new_password_label.grid(row=1, column=0, sticky=tk.W, pady=(0, 10), padx=(20, 10))
        
        self.new_password_var = tk.StringVar()
        new_password_entry = tk.Entry(frame, textvariable=self.new_password_var, show="*")
        new_password_entry.grid(row=1, column=1, sticky=tk.EW, pady=(0, 10), padx=(0, 20))
        
        # 确认新密码
        confirm_password_label = tk.Label(frame, text="确认新密码:")
        confirm_password_label.grid(row=2, column=0, sticky=tk.W, pady=(0, 20), padx=(20, 10))
        
        self.confirm_password_var = tk.StringVar()
        confirm_password_entry = tk.Entry(frame, textvariable=self.confirm_password_var, show="*")
        confirm_password_entry.grid(row=2, column=1, sticky=tk.EW, pady=(0, 20), padx=(0, 20))
        
        # 修改密码按钮
        change_password_button = tk.Button(frame, text="修改密码", command=self._change_password)
        change_password_button.grid(row=3, column=0, columnspan=2, pady=(0, 20))
        
        # 清除配置按钮
        clear_config_button = tk.Button(frame, text="清除配置", command=self._clear_config, fg="red")
        clear_config_button.grid(row=4, column=0, columnspan=2, pady=(0, 20))
        
        # 提示信息
        tip_label = tk.Label(frame, text="提示: 密码将明文存储在配置文件中", fg="gray")
        tip_label.grid(row=5, column=0, columnspan=2, pady=(0, 20))
    
    def _create_system_tab(self, frame):
        """创建系统设置标签页"""
        # 开机自启
        self.autostart_var = tk.BooleanVar(value=self.autostart_manager.is_autostart_enabled())
        autostart_checkbutton = tk.Checkbutton(frame, text="开机自启", variable=self.autostart_var, 
                                              command=self._toggle_autostart)
        autostart_checkbutton.pack(pady=(20, 10), padx=20, anchor=tk.W)
        

        
        # 允许的时间段
        allowed_times = self.time_manager.get_allowed_times()
        time_label = tk.Label(frame, text="允许的时间段:")
        time_label.pack(pady=(20, 5), padx=20, anchor=tk.W)
        
        morning_time_label = tk.Label(frame, text=f"早上: {allowed_times['morning']}")
        morning_time_label.pack(pady=(0, 5), padx=40, anchor=tk.W)
        
        evening_time_label = tk.Label(frame, text=f"晚上: {allowed_times['evening']}")
        evening_time_label.pack(pady=(0, 20), padx=40, anchor=tk.W)
    
    def _create_about_tab(self, frame):
        """创建关于标签页"""
        # 应用名称
        app_name_label = tk.Label(frame, text="720防沉迷", font=("Arial", 16, "bold"))
        app_name_label.pack(pady=(20, 10))
        
        # 版本
        version_label = tk.Label(frame, text="版本: 1.0.0")
        version_label.pack(pady=(0, 10))
        
        # 描述
        description_label = tk.Label(frame, text="一款简易的防沉迷应用，帮助您合理管理使用时间。")
        description_label.pack(pady=(0, 20))
        
        # 功能说明
        features_label = tk.Label(frame, text="主要功能:")
        features_label.pack(pady=(0, 5), anchor=tk.W, padx=20)
        
        feature1_label = tk.Label(frame, text="• 应用程序保护")
        feature1_label.pack(pady=(0, 5), anchor=tk.W, padx=40)
        
        feature2_label = tk.Label(frame, text="• 智能时间管理")
        feature2_label.pack(pady=(0, 5), anchor=tk.W, padx=40)
        
        feature3_label = tk.Label(frame, text="• 开机自启")
        feature3_label.pack(pady=(0, 5), anchor=tk.W, padx=40)
        
        feature4_label = tk.Label(frame, text="• 密码管理")
        feature4_label.pack(pady=(0, 5), anchor=tk.W, padx=40)
    
    def _change_password(self):
        """修改密码"""
        old_password = self.old_password_var.get()
        new_password = self.new_password_var.get()
        confirm_password = self.confirm_password_var.get()
        
        # 检查新密码和确认密码是否一致
        if new_password != confirm_password:
            messagebox.showerror("错误", "新密码和确认密码不一致！")
            return
        
        # 检查密码长度
        if len(new_password) < 4:
            messagebox.showerror("错误", "密码长度至少为4位！")
            return
        
        # 修改密码
        if self.password_manager.has_password_set():
            # 已有密码，需要验证旧密码
            if not self.password_manager.change_password(old_password, new_password):
                messagebox.showerror("错误", "旧密码错误！")
                return
        else:
            # 首次设置密码
            self.password_manager.set_password(new_password)
        
        messagebox.showinfo("成功", "密码修改成功！")
        # 清空输入框
        self.old_password_var.set("")
        self.new_password_var.set("")
        self.confirm_password_var.set("")
    
    def _toggle_autostart(self):
        """切换开机自启状态"""
        enable = self.autostart_var.get()
        success = self.autostart_manager.set_autostart(enable)
        if not success:
            messagebox.showerror("错误", "设置开机自启失败！")
            # 恢复原状态
            self.autostart_var.set(not enable)
    
    def _clear_config(self):
        """清除配置"""
        # 弹出密码验证窗口
        def on_verify(success):
            if success:
                # 密码验证成功，清除配置
                self._do_clear_config()
        
        password_window = PasswordWindow(self.window, title="清除配置验证", callback=on_verify)
        password_window.show()
    
    def _do_clear_config(self):
        """执行清除配置操作"""
        try:
            # 关闭开机自启
            autostart_manager = AutoStartManager()
            autostart_manager.set_autostart(False)
            
            # 清除配置文件
            config_file = self.config_manager.config_file
            if os.path.exists(config_file):
                os.remove(config_file)
                print(f"配置文件已清除: {config_file}")
            
            # 提示用户并让用户选择操作
            result = messagebox.askquestion(
                "配置已清除", 
                "配置已清除。\n\n重新启动后需要重新设置密码和保护列表。\n\n是否重新启动应用程序？",
                icon='question',
                default='yes'
            )
            
            if result == 'yes':
                # 重新启动应用程序
                python = sys.executable
                os.execl(python, python, *sys.argv)
            else:
                # 关闭应用程序
                if self.parent:
                    # 如果有父窗口，关闭父窗口
                    self.parent.destroy()
                else:
                    # 否则关闭当前窗口
                    self.window.destroy()
                sys.exit(0)
        except Exception as e:
            print(f"清除配置失败: {e}")
            messagebox.showerror("错误", "清除配置失败，请手动删除配置文件。")
    

