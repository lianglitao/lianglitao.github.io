import tkinter as tk
from tkinter import messagebox
from core.password import PasswordManager

class PasswordWindow:
    def __init__(self, parent=None, title="密码验证", callback=None):
        self.parent = parent
        self.title = title
        self.callback = callback
        self.password_manager = PasswordManager()
        self.window = None
        self.password_var = None
    
    def show(self):
        """显示密码输入窗口"""
        # 创建窗口
        self.window = tk.Toplevel(self.parent) if self.parent else tk.Tk()
        self.window.title(self.title)
        self.window.geometry("300x150")
        self.window.resizable(False, False)
        
        # 居中显示
        self._center_window()
        
        # 创建界面元素
        self._create_widgets()
        
        # 绑定事件
        self.window.protocol("WM_DELETE_WINDOW", self._on_close)
        
        # 设置窗口为模态
        if self.parent:
            self.window.transient(self.parent)
            self.window.grab_set()
            # 运行主循环，等待用户输入
            self.parent.wait_window(self.window)
        
        # 显示窗口
        if not self.parent:
            self.window.mainloop()
    
    def _center_window(self):
        """居中显示窗口"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f"{width}x{height}+{x}+{y}")
    
    def _create_widgets(self):
        """创建界面元素"""
        # 创建主框架
        frame = tk.Frame(self.window, padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # 密码标签
        password_label = tk.Label(frame, text="请输入密码:")
        password_label.pack(pady=(0, 10))
        
        # 密码输入框
        self.password_var = tk.StringVar()
        password_entry = tk.Entry(frame, textvariable=self.password_var, show="*")
        password_entry.pack(fill=tk.X, pady=(0, 20))
        password_entry.focus_set()
        
        # 绑定回车键
        password_entry.bind("<Return>", lambda e: self._verify_password())
        
        # 按钮框架
        button_frame = tk.Frame(frame)
        button_frame.pack(fill=tk.X)
        
        # 确定按钮
        confirm_button = tk.Button(button_frame, text="确定", command=self._verify_password, width=10)
        confirm_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # 取消按钮
        cancel_button = tk.Button(button_frame, text="取消", command=self._on_close, width=10)
        cancel_button.pack(side=tk.RIGHT)
    
    def _verify_password(self):
        """验证密码"""
        password = self.password_var.get()
        if self.password_manager.verify_password(password):
            # 密码正确
            if self.callback:
                self.callback(True)
            self._on_close()
        else:
            # 密码错误
            messagebox.showerror("错误", "密码错误，请重新输入！")
            self.password_var.set("")
    
    def _on_close(self):
        """关闭窗口"""
        if self.callback:
            self.callback(False)
        if self.window:
            self.window.destroy()
