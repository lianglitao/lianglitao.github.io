#!/usr/bin/env python3
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWebEngineCore import QWebEngineUrlRequestInterceptor
from PyQt5.QtCore import QUrl
from security_manager import SecurityManager

class RequestInterceptor(QWebEngineUrlRequestInterceptor):
    def __init__(self):
        super().__init__()
        self.security_manager = SecurityManager()
    
    def interceptRequest(self, info):
        url = info.requestUrl().toString()
        
        # 检查是否在白名单中
        if not self.security_manager.is_allowed(url):
            info.block(True)
            print(f"Blocked: {url}")
        else:
            print(f"Allowed: {url}")

class WebView(QWebEngineView):
    def __init__(self):
        super().__init__()
        
        # 连接页面加载信号
        self.page().profile().setHttpUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        
        # 拦截网络请求
        interceptor = RequestInterceptor()
        self.page().profile().setRequestInterceptor(interceptor)
    
    def load(self, url):
        # 检查URL是否在白名单中
        security_manager = SecurityManager()
        url_str = url.toString() if isinstance(url, QUrl) else url
        if not security_manager.is_allowed(url_str):
            # 加载安全警告页面
            self.setHtml(f"""
            <html>
            <head><title>安全警告</title></head>
            <body style="background-color: #f44336; color: white; text-align: center; padding: 100px;">
                <h1>⚠️ 安全警告</h1>
                <p>您访问的网站不在白名单中，已被720安全浏览器拦截。</p>
                <p>网址: {url_str}</p>
            </body>
            </html>
            """)
        else:
            super().load(url)