#!/usr/bin/env python3
"""
720安全浏览器启动脚本
Python版本，在真实环境中运行
"""
import os
import sys
import subprocess
import platform

def main():
    # 获取脚本所在目录的绝对路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 切换到脚本所在目录
    os.chdir(script_dir)
    print(f"当前工作目录: {os.getcwd()}")
    
    # 构建直接运行命令（使用系统Python）
    if platform.system() == 'Darwin':  # macOS
        python_cmd = 'python3'
        main_file = os.path.join('main.py')
        
        # 构建完整的命令
        cmd = f'"{python_cmd}" "{main_file}"'
        print(f"执行命令: {cmd}")
        
        # 执行命令
        subprocess.run(cmd, shell=True, executable='/bin/bash')
    else:
        print("错误: 此脚本仅支持macOS系统")
        sys.exit(1)

if __name__ == "__main__":
    main()

"""
使用说明：
1. 确保系统已安装PyQt5和PyQtWebEngine：
   pip3 install PyQt5 PyQtWebEngine

2. 直接运行此脚本：
   python3 启动浏览器.py

3. 安全功能：
   - 基于字典.txt文件的白名单访问控制
   - 只允许访问字典.txt中列出的网站
   - 其他网站将被拦截并显示安全警告
"""
