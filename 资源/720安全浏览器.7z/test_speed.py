#!/usr/bin/env python3
"""
测试白名单检查速度
"""
import time
import sys
import os

# 添加当前目录到系统路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from security_manager import SecurityManager

# 测试URL列表
test_urls = [
    "https://www.baidu.com",
    "https://www.google.com",
    "https://www.taobao.com",
    "https://www.jd.com",
    "https://www.github.com",
    "https://www.stackoverflow.com",
    "https://www.bilibili.com",
    "https://www.zhihu.com",
    "https://www.163.com",
    "https://www.sina.com.cn",
    "https://www.sohu.com",
    "https://www.youku.com",
    "https://www.tudou.com",
    "https://www.qq.com",
    "https://www.weibo.com",
    "https://www.csdn.net",
    "https://www.cnblogs.com",
    "https://www.v2ex.com",
    "https://www.github.com",
    "https://www.amazon.com"
]

def test_speed():
    print("=== 测试白名单检查速度 ===")
    
    # 初始化SecurityManager
    sm = SecurityManager()
    
    # 测试单次检查时间
    print("\n1. 测试单次检查时间:")
    for url in test_urls[:5]:
        start_time = time.time()
        result = sm.is_allowed(url)
        end_time = time.time()
        elapsed = (end_time - start_time) * 1000  # 转换为毫秒
        print(f"  {url}: {'允许' if result else '拒绝'} - {elapsed:.4f}ms")
    
    # 测试批量检查时间
    print("\n2. 测试批量检查时间:")
    start_time = time.time()
    for _ in range(1000):
        for url in test_urls:
            sm.is_allowed(url)
    end_time = time.time()
    total_elapsed = (end_time - start_time) * 1000  # 转换为毫秒
    avg_elapsed = total_elapsed / (1000 * len(test_urls))
    print(f"  1000次循环，共{len(test_urls)}个URL:")
    print(f"  总时间: {total_elapsed:.2f}ms")
    print(f"  平均每次检查: {avg_elapsed:.4f}ms")
    
    # 测试边缘情况
    print("\n3. 测试边缘情况:")
    # 超长URL
    long_url = "https://www." + "a" * 1000 + ".com"
    start_time = time.time()
    result = sm.is_allowed(long_url)
    end_time = time.time()
    elapsed = (end_time - start_time) * 1000
    print(f"  超长URL (1000字符): {'允许' if result else '拒绝'} - {elapsed:.4f}ms")
    
    # 不存在的域名
    nonexistent_url = "https://www.this-domain-does-not-exist-123456.com"
    start_time = time.time()
    result = sm.is_allowed(nonexistent_url)
    end_time = time.time()
    elapsed = (end_time - start_time) * 1000
    print(f"  不存在的域名: {'允许' if result else '拒绝'} - {elapsed:.4f}ms")

if __name__ == "__main__":
    test_speed()