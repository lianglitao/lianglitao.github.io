#!/usr/bin/env python3
import sys
import os

# 设置Qt平台插件路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
qt_plugins_path = os.path.join(os.path.dirname(__file__), 'venv', 'lib', 'python3.14', 'site-packages', 'PyQt5', 'Qt5', 'plugins')
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = qt_plugins_path

from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QLineEdit, QPushButton
from PyQt5.QtCore import QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView

class SimpleBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("测试浏览器")
        self.setGeometry(100, 100, 1024, 768)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        nav_layout = QHBoxLayout()
        
        self.url_bar = QLineEdit()
        self.url_bar.setText("https://www.baidu.com")
        
        go_button = QPushButton("Go")
        
        nav_layout.addWidget(self.url_bar)
        nav_layout.addWidget(go_button)
        
        self.web_view = QWebEngineView()
        
        main_layout.addLayout(nav_layout)
        main_layout.addWidget(self.web_view)
        
        go_button.clicked.connect(self.load_url)
        
        # 加载百度
        self.load_url()
    
    def load_url(self):
        url = self.url_bar.text()
        if not url.startswith('http'):
            url = 'http://' + url
        print(f"Loading: {url}")
        self.web_view.load(QUrl(url))

if __name__ == "__main__":
    sys.argv.append("--no-sandbox")
    app = QApplication(sys.argv)
    window = SimpleBrowser()
    window.show()
    sys.exit(app.exec_())