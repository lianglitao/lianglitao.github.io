#!/usr/bin/env python3
from PyQt5.QtWidgets import QTabWidget, QTabBar, QPushButton, QInputDialog
from PyQt5.QtCore import pyqtSignal, QUrl
from web_view import WebView

class TabWidget(QTabWidget):
    url_changed = pyqtSignal(QUrl)
    title_changed = pyqtSignal(str)
    load_started = pyqtSignal()
    load_progress = pyqtSignal(int)
    load_finished = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTabsClosable(True)
        self.setMovable(True)
        
        # 创建新建标签页按钮
        self.new_tab_button = QPushButton("+")
        self.new_tab_button.setFixedSize(30, 30)
        self.new_tab_button.clicked.connect(self.new_tab)
        
        # 创建第一个标签页
        self.new_tab()
        
        # 添加到标签栏
        self.tabBar().setTabButton(self.tabBar().count() - 1, QTabBar.RightSide, self.new_tab_button)
        
        # 连接信号槽
        self.tabCloseRequested.connect(self.close_tab)
        self.currentChanged.connect(self._current_tab_changed)
    
    @property
    def current_web_view(self):
        if self.count() > 0:
            return self.currentWidget()
        return None
    
    def new_tab(self):
        web_view = WebView()
        index = self.addTab(web_view, "新标签页")
        self.setCurrentIndex(index)
        
        # 连接web_view信号
        web_view.urlChanged.connect(self.url_changed)
        web_view.titleChanged.connect(self._update_tab_title)
        web_view.loadStarted.connect(self.load_started)
        web_view.loadProgress.connect(self.load_progress)
        web_view.loadFinished.connect(self.load_finished)
        
        # 加载默认页面
        web_view.load(QUrl("https://www.baidu.com"))
    
    def close_tab(self, index):
        if self.count() > 1:
            self.widget(index).deleteLater()
            self.removeTab(index)
    
    def _update_tab_title(self, title):
        if title:
            self.setTabText(self.currentIndex(), title[:20] + "..." if len(title) > 20 else title)
            self.title_changed.emit(title)
    
    def _current_tab_changed(self, index):
        if index >= 0:
            web_view = self.widget(index)
            if web_view:
                self.url_changed.emit(web_view.url())
                if web_view.title():
                    self.title_changed.emit(web_view.title())