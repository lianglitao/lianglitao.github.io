#!/usr/bin/env python3
import sys
import os

# 添加当前目录到系统路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 动态设置Qt平台插件路径
try:
    import PyQt5
    pyqt5_path = os.path.dirname(PyQt5.__file__)
    qt_plugins_path = os.path.join(pyqt5_path, 'Qt5', 'plugins')
    if os.path.exists(qt_plugins_path):
        os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = qt_plugins_path
        print(f"设置Qt插件路径: {qt_plugins_path}")
    else:
        print(f"警告: 未找到Qt插件路径: {qt_plugins_path}")
except Exception as e:
    print(f"设置Qt插件路径时出错: {e}")

from PyQt5.QtWidgets import QApplication
from browser_window import BrowserWindow

if __name__ == "__main__":
    # 禁用QtWebEngine的sandbox以解决macOS上的权限问题
    sys.argv.append("--no-sandbox")
    app = QApplication(sys.argv)
    window = BrowserWindow()
    window.show()
    sys.exit(app.exec_())