#!/usr/bin/env python3
from PyQt5.QtWidgets import (
    QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QLineEdit, 
    QPushButton, QStatusBar, QProgressBar, QLabel
)
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QIcon
from tab_widget import TabWidget

class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("720 安全浏览器")
        self.setGeometry(100, 100, 1024, 768)
        
        # 窗口最大化
        self.showMaximized()
        
        # 加载样式表
        self._load_stylesheet()
        
        # 创建中心窗口部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建主布局
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 创建导航栏布局
        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(5, 5, 5, 5)
        nav_layout.setSpacing(5)
        
        # 导航按钮
        self.back_button = QPushButton("←")
        self.forward_button = QPushButton("→")
        self.refresh_button = QPushButton("⟳")
        self.stop_button = QPushButton("■")
        
        # 地址栏
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("输入网址...")
        
        # 添加导航栏组件
        nav_layout.addWidget(self.back_button)
        nav_layout.addWidget(self.forward_button)
        nav_layout.addWidget(self.refresh_button)
        nav_layout.addWidget(self.stop_button)
        nav_layout.addWidget(self.url_bar, 1)
        
        # 创建标签页部件
        self.tab_widget = TabWidget(self)
        
        # 创建状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # 状态栏组件
        self.security_label = QLabel("安全")
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.hide()
        
        self.status_bar.addWidget(self.security_label)
        self.status_bar.addWidget(self.progress_bar)
        
        # 添加到主布局
        main_layout.addLayout(nav_layout)
        main_layout.addWidget(self.tab_widget)
        
        # 连接信号槽
        self._connect_signals()
    
    def _connect_signals(self):
        # 导航按钮信号
        self.back_button.clicked.connect(self.tab_widget.current_web_view.back)
        self.forward_button.clicked.connect(self.tab_widget.current_web_view.forward)
        self.refresh_button.clicked.connect(self.tab_widget.current_web_view.reload)
        self.stop_button.clicked.connect(self.tab_widget.current_web_view.stop)
        
        # 地址栏信号
        self.url_bar.returnPressed.connect(self._load_url)
        
        # 标签页信号
        self.tab_widget.url_changed.connect(self._update_url_bar)
        self.tab_widget.title_changed.connect(self._update_title)
        self.tab_widget.load_started.connect(self._show_progress)
        self.tab_widget.load_progress.connect(self._update_progress)
        self.tab_widget.load_finished.connect(self._hide_progress)
    
    def _load_url(self):
        url = self.url_bar.text()
        if not url.startswith('http'):
            url = 'http://' + url
        self.tab_widget.current_web_view.load(QUrl(url))
    
    def _update_url_bar(self, url):
        self.url_bar.setText(url.toString())
    
    def _update_title(self, title):
        self.setWindowTitle(f"{title} - 720 安全浏览器")
    
    def _show_progress(self):
        self.progress_bar.show()
        self.progress_bar.setValue(0)
    
    def _update_progress(self, progress):
        self.progress_bar.setValue(progress)
    
    def _hide_progress(self):
        self.progress_bar.hide()
    
    def _load_stylesheet(self):
        import os
        stylesheet_path = os.path.join(os.path.dirname(__file__), 'resources', 'styles.qss')
        if os.path.exists(stylesheet_path):
            with open(stylesheet_path, 'r', encoding='utf-8') as f:
                stylesheet = f.read()
                self.setStyleSheet(stylesheet)