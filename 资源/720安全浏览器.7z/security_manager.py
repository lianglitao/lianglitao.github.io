#!/usr/bin/env python3
import os

class SecurityManager:
    def __init__(self):
        self.whitelist_domains = []
        self._load_whitelist()
    
    def _load_whitelist(self):
        # 加载字典.txt白名单
        whitelist_path = os.path.join(os.path.dirname(__file__), '字典.txt')
        if os.path.exists(whitelist_path):
            with open(whitelist_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        self.whitelist_domains.append(line)
        
        # 按域名长度降序排序，优先匹配长域名
        self.whitelist_domains.sort(key=lambda x: len(x), reverse=True)
        print(f"加载白名单域名 {len(self.whitelist_domains)} 个")
    
    def is_allowed(self, url):
        """检查URL是否在白名单中"""
        # 快速匹配：优先检查长域名，减少匹配次数
        for domain in self.whitelist_domains:
            if domain in url:
                return True
        return False