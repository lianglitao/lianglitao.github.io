import tkinter as tk
from tkinter import ttk, messagebox
import os
import webbrowser
import requests
import time

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("720中心")
        self.geometry("800x600")
        self.resizable(True, True)
        
        # 设置窗口图标（如果有）
        # self.iconbitmap("icon.ico")
        
        # 创建主框架
        self.main_frame = ttk.Frame(self, padding="20")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标题
        self.title_label = ttk.Label(
            self.main_frame, 
            text="720中心", 
            font=("SimHei", 24, "bold")
        )
        self.title_label.pack(pady=20)
        
        # 创建产品列表框架
        self.products_frame = ttk.LabelFrame(self.main_frame, text="720系列产品", padding="10")
        self.products_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # 本地备用产品列表
        self.local_products = [
            "720极速浏览器",
            "720安全浏览器",
            "720压缩软件",
            "720 3D打印模拟器",
            "720防沉迷游戏",
            "720安全卫士",
            "720中心",
            "记账应用（ipad同）"
        ]
        
        # 尝试从GitHub爬取产品列表
        self.products = self.get_products_from_github()
        
        # 创建产品列表
        self.product_listbox = tk.Listbox(
            self.products_frame, 
            font=("SimHei", 12),
            selectmode=tk.SINGLE,
            height=max(6, len(self.products))
        )
        for product in self.products:
            self.product_listbox.insert(tk.END, product)
        self.product_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建功能按钮
        self.create_buttons()
    
    def get_products_from_github(self):
        """从GitHub爬取产品列表，如果失败则使用本地备用"""
        # 先返回本地备用，然后在后台尝试爬取
        products = self.local_products.copy()
        
        # 在后台线程中尝试爬取GitHub内容
        def fetch_github_content():
            url = "https://api.github.com/repos/lianglitao/lianglitao.github.io/contents/%E8%B5%84%E6%BA%90"
            try:
                # 设置超时时间为5秒
                response = requests.get(url, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    github_products = []
                    for item in data:
                        if item.get("type") == "file":
                            # 提取文件名（不含扩展名）作为产品名称
                            filename = item.get("name", "")
                            if filename:
                                product_name = os.path.splitext(filename)[0]
                                github_products.append(product_name)
                    
                    if github_products:
                        # 更新产品列表
                        self.products = github_products
                        self.update_product_listbox()
            except Exception as e:
                # 网络异常，使用本地备用
                # 弹窗提示用户
                self.after(0, lambda: messagebox.showinfo(
                    "网络提示", 
                    "当前网络环境可能无法获取最新软件列表，\n正在使用本地备用列表。\n\n请检查网络连接后重试。"
                ))
        
        # 使用tkinter的after方法在后台执行
        self.after(100, fetch_github_content)
        
        return products
    
    def update_product_listbox(self):
        """更新产品列表框"""
        # 清空列表
        self.product_listbox.delete(0, tk.END)
        # 添加新产品
        for product in self.products:
            self.product_listbox.insert(tk.END, product)
        # 调整列表高度
        self.product_listbox.config(height=max(6, len(self.products)))
    
    def create_buttons(self):
        """创建功能按钮框架"""
        self.buttons_frame = ttk.Frame(self.main_frame)
        self.buttons_frame.pack(fill=tk.X, pady=20)
        
        # 创建下载与更新按钮
        self.download_btn = ttk.Button(
            self.buttons_frame, 
            text="下载与更新", 
            command=self.download_update
        )
        self.download_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # 创建卸载按钮
        self.uninstall_btn = ttk.Button(
            self.buttons_frame, 
            text="卸载", 
            command=self.uninstall
        )
        self.uninstall_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # 创建关于按钮
        self.about_btn = ttk.Button(
            self.buttons_frame, 
            text="关于", 
            command=self.about
        )
        self.about_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
    
    def download_update(self):
        """下载与更新功能"""
        url = "https://github.com/lianglitao/lianglitao.github.io/tree/main/%E8%B5%84%E6%BA%90"
        messagebox.showinfo(
            "下载与更新", 
            "正在打开下载页面，请自行处理网络加速问题。"
        )
        webbrowser.open(url)
    
    def uninstall(self):
        """卸载功能"""
        selected_index = self.product_listbox.curselection()
        if not selected_index:
            messagebox.showwarning("提示", "请先选择要卸载的产品")
            return
        
        selected_product = self.product_listbox.get(selected_index[0])
        
        # 提示用户输入安装路径
        path_dialog = tk.Toplevel(self)
        path_dialog.title("输入安装路径")
        path_dialog.geometry("500x200")
        path_dialog.resizable(False, False)
        
        # 居中显示
        x = self.winfo_x() + (self.winfo_width() // 2) - 250
        y = self.winfo_y() + (self.winfo_height() // 2) - 100
        path_dialog.geometry(f"500x200+{x}+{y}")
        
        # 创建路径输入框架
        path_frame = ttk.Frame(path_dialog, padding="20")
        path_frame.pack(fill=tk.BOTH, expand=True)
        
        # 路径标签
        path_label = ttk.Label(path_frame, text=f"{selected_product}的安装路径:")
        path_label.pack(pady=10)
        
        # 路径输入框
        path_var = tk.StringVar()
        path_entry = ttk.Entry(path_frame, textvariable=path_var, width=50)
        path_entry.pack(pady=10, fill=tk.X)
        
        # 按钮框架
        btn_frame = ttk.Frame(path_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        # 确认按钮
        def confirm_uninstall():
            path = path_var.get().strip()
            if not path:
                messagebox.showwarning("提示", "请输入安装路径")
                return
            
            if not os.path.exists(path):
                messagebox.showerror("错误", "指定的路径不存在")
                return
            
            # 二次确认
            confirm = messagebox.askyesno(
                "确认卸载", 
                f"确定要卸载{selected_product}吗？\n\n注意：卸载操作可能会导致数据丢失，请确保已备份重要数据。"
            )
            
            if confirm:
                try:
                    # 实际卸载操作：删除指定路径
                    import shutil
                    shutil.rmtree(path)
                    messagebox.showinfo("成功", f"{selected_product}卸载成功")
                except Exception as e:
                    messagebox.showerror("错误", f"卸载失败：{str(e)}")
            
            path_dialog.destroy()
        
        confirm_btn = ttk.Button(btn_frame, text="确认", command=confirm_uninstall)
        confirm_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # 取消按钮
        cancel_btn = ttk.Button(btn_frame, text="取消", command=path_dialog.destroy)
        cancel_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
    
    def about(self):
        """关于功能"""
        messagebox.showinfo(
            "关于", 
            "720中心 v1.0\n\n用于统一管理720系列产品的应用程序。\n\n© 2026 720团队"
        )

if __name__ == "__main__":
    app = Application()
    app.mainloop()