#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QDateEdit, QPushButton, QMessageBox, QLineEdit)
from PyQt5.QtCore import Qt, QDate
from anti_addiction_config import AntiAddictionConfig


class BirthdayDialog(QDialog):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.setWindowTitle('设置生日')
        self.setFixedSize(400, 300)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title_label = QLabel('欢迎！请设置您的生日')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin-bottom: 20px;')
        layout.addWidget(title_label)
        
        date_label = QLabel('出生日期：')
        layout.addWidget(date_label)
        
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate().addYears(-18))
        self.date_edit.setMaximumDate(QDate.currentDate())
        layout.addWidget(self.date_edit)
        
        info_label = QLabel('提示：未成年人（18岁以下）需要设置家长密码，\n只能在中午12:00-13:00玩游戏')
        info_label.setAlignment(Qt.AlignCenter)
        info_label.setStyleSheet('color: #666; margin-top: 20px;')
        layout.addWidget(info_label)
        
        button_layout = QHBoxLayout()
        confirm_button = QPushButton('确认')
        confirm_button.clicked.connect(self.confirm_birthday)
        confirm_button.setStyleSheet('padding: 10px 20px;')
        button_layout.addWidget(confirm_button)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def confirm_birthday(self):
        birthday = self.date_edit.date().toString('yyyy-MM-dd')
        if self.config.set_birthday(birthday):
            QMessageBox.information(self, '成功', '生日设置成功！')
            self.accept()
        else:
            QMessageBox.critical(self, '错误', '保存生日失败！')


class ParentPasswordDialog(QDialog):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.setWindowTitle('设置家长密码')
        self.setFixedSize(400, 300)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title_label = QLabel('设置家长密码')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin-bottom: 20px;')
        layout.addWidget(title_label)
        
        password_label = QLabel('请输入家长密码：')
        layout.addWidget(password_label)
        
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText('请输入密码')
        layout.addWidget(self.password_edit)
        
        confirm_label = QLabel('确认家长密码：')
        layout.addWidget(confirm_label)
        
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.Password)
        self.confirm_edit.setPlaceholderText('请再次输入密码')
        layout.addWidget(self.confirm_edit)
        
        info_label = QLabel('提示：家长密码用于在非游戏时间解锁游戏')
        info_label.setAlignment(Qt.AlignCenter)
        info_label.setStyleSheet('color: #666; margin-top: 20px;')
        layout.addWidget(info_label)
        
        button_layout = QHBoxLayout()
        confirm_button = QPushButton('确认')
        confirm_button.clicked.connect(self.confirm_password)
        confirm_button.setStyleSheet('padding: 10px 20px;')
        button_layout.addWidget(confirm_button)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def confirm_password(self):
        password = self.password_edit.text()
        confirm = self.confirm_edit.text()
        
        if not password:
            QMessageBox.warning(self, '警告', '请输入密码！')
            return
        
        if len(password) < 6:
            QMessageBox.warning(self, '警告', '密码长度至少6位！')
            return
        
        if password != confirm:
            QMessageBox.warning(self, '警告', '两次输入的密码不一致！')
            return
        
        if self.config.set_parent_password(password):
            QMessageBox.information(self, '成功', '家长密码设置成功！')
            self.accept()
        else:
            QMessageBox.critical(self, '错误', '保存密码失败！')


class VerifyPasswordDialog(QDialog):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.verified = False
        self.setWindowTitle('验证家长密码')
        self.setFixedSize(400, 200)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title_label = QLabel('验证家长密码')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin-bottom: 20px;')
        layout.addWidget(title_label)
        
        password_label = QLabel('请输入家长密码：')
        layout.addWidget(password_label)
        
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText('请输入密码')
        layout.addWidget(self.password_edit)
        
        button_layout = QHBoxLayout()
        confirm_button = QPushButton('确认')
        confirm_button.clicked.connect(self.verify_password)
        confirm_button.setStyleSheet('padding: 10px 20px;')
        button_layout.addWidget(confirm_button)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def verify_password(self):
        password = self.password_edit.text()
        
        if not password:
            QMessageBox.warning(self, '警告', '请输入密码！')
            return
        
        if self.config.verify_parent_password(password):
            self.verified = True
            QMessageBox.information(self, '成功', '密码验证成功！')
            self.accept()
        else:
            QMessageBox.warning(self, '错误', '密码错误！')
            self.password_edit.clear()
