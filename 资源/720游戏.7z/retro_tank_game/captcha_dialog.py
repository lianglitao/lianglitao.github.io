#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont


class CaptchaDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.verified = False
        self.current_captcha = None
        self.setWindowTitle('人机验证')
        self.setFixedSize(400, 300)
        self.init_ui()
        self.generate_captcha()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title_label = QLabel('人机验证')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet('font-size: 20px; font-weight: bold; margin-bottom: 20px;')
        layout.addWidget(title_label)
        
        info_label = QLabel('请完成以下验证以继续：')
        info_label.setAlignment(Qt.AlignCenter)
        info_label.setStyleSheet('font-size: 14px; margin-bottom: 20px;')
        layout.addWidget(info_label)
        
        self.captcha_label = QLabel()
        self.captcha_label.setAlignment(Qt.AlignCenter)
        self.captcha_label.setStyleSheet('font-size: 24px; font-weight: bold; padding: 20px; background-color: #f0f0f0; border-radius: 10px; margin-bottom: 20px;')
        layout.addWidget(self.captcha_label)
        
        answer_label = QLabel('请输入答案：')
        layout.addWidget(answer_label)
        
        self.answer_edit = QLineEdit()
        self.answer_edit.setPlaceholderText('请输入答案')
        self.answer_edit.setStyleSheet('padding: 10px; font-size: 16px;')
        layout.addWidget(self.answer_edit)
        
        button_layout = QHBoxLayout()
        
        refresh_button = QPushButton('刷新')
        refresh_button.clicked.connect(self.generate_captcha)
        refresh_button.setStyleSheet('padding: 10px 20px;')
        button_layout.addWidget(refresh_button)
        
        confirm_button = QPushButton('确认')
        confirm_button.clicked.connect(self.verify_captcha)
        confirm_button.setStyleSheet('padding: 10px 20px; background-color: #4CAF50; color: white;')
        button_layout.addWidget(confirm_button)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def generate_captcha(self):
        num1 = random.randint(1, 20)
        num2 = random.randint(1, 20)
        operator = random.choice(['+', '-', '×'])
        
        if operator == '+':
            self.current_captcha = num1 + num2
            captcha_text = f'{num1} + {num2} = ?'
        elif operator == '-':
            if num1 < num2:
                num1, num2 = num2, num1
            self.current_captcha = num1 - num2
            captcha_text = f'{num1} - {num2} = ?'
        else:
            self.current_captcha = num1 * num2
            captcha_text = f'{num1} × {num2} = ?'
        
        self.captcha_label.setText(captcha_text)
        self.answer_edit.clear()
    
    def verify_captcha(self):
        answer = self.answer_edit.text().strip()
        
        if not answer:
            QMessageBox.warning(self, '警告', '请输入答案！')
            return
        
        try:
            answer_num = int(answer)
            if answer_num == self.current_captcha:
                self.verified = True
                QMessageBox.information(self, '成功', '验证通过！')
                self.accept()
            else:
                QMessageBox.warning(self, '错误', '答案错误，请重新验证！')
                self.generate_captcha()
        except ValueError:
            QMessageBox.warning(self, '错误', '请输入数字！')
            self.answer_edit.clear()
