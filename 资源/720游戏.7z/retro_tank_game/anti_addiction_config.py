#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
from datetime import datetime


class AntiAddictionConfig:
    def __init__(self):
        self.config_file = 'anti_addiction_config.json'
        self.config = self.load_config()
    
    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"加载配置文件失败: {e}")
                return {}
        return {}
    
    def save_config(self):
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False
    
    def is_first_run(self):
        return 'birthday' not in self.config
    
    def set_birthday(self, birthday):
        self.config['birthday'] = birthday
        return self.save_config()
    
    def get_birthday(self):
        return self.config.get('birthday', None)
    
    def get_age(self):
        birthday = self.get_birthday()
        if not birthday:
            return None
        
        try:
            birth_date = datetime.strptime(birthday, '%Y-%m-%d')
            today = datetime.now()
            age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
            return age
        except Exception as e:
            print(f"计算年龄失败: {e}")
            return None
    
    def is_under_18(self):
        age = self.get_age()
        if age is None:
            return False
        return age < 18
    
    def has_parent_password(self):
        return 'parent_password' in self.config
    
    def set_parent_password(self, password):
        self.config['parent_password'] = password
        return self.save_config()
    
    def verify_parent_password(self, password):
        return self.config.get('parent_password') == password
    
    def is_allowed_time(self):
        if not self.is_under_18():
            return True
        
        current_time = datetime.now()
        hour = current_time.hour
        minute = current_time.minute
        
        return hour == 12 and 0 <= minute < 60
    
    def get_remaining_time(self):
        if not self.is_under_18():
            return None
        
        current_time = datetime.now()
        if current_time.hour < 12:
            next_allowed = current_time.replace(hour=12, minute=0, second=0, microsecond=0)
            remaining = (next_allowed - current_time).total_seconds()
            return int(remaining)
        elif current_time.hour == 12:
            end_time = current_time.replace(hour=13, minute=0, second=0, microsecond=0)
            remaining = (end_time - current_time).total_seconds()
            return int(remaining)
        else:
            next_allowed = current_time.replace(hour=12, minute=0, second=0, microsecond=0)
            next_allowed = next_allowed.replace(day=next_allowed.day + 1)
            remaining = (next_allowed - current_time).total_seconds()
            return int(remaining)
