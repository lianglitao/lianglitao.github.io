#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#模拟cd坦克游戏源代码：
import sys
import os

# 设置环境变量以禁用sandbox（macOS需要）
os.environ['QTWEBENGINE_DISABLE_SANDBOX'] = '1'

from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QDialog
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QKeySequence

from anti_addiction_config import AntiAddictionConfig
from anti_addiction_dialogs import BirthdayDialog, ParentPasswordDialog, VerifyPasswordDialog
from captcha_dialog import CaptchaDialog


class FullScreenBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # 初始化防沉迷配置
        self.config = AntiAddictionConfig()
        
        # 执行防沉迷检查
        if not self.check_anti_addiction():
            return
        
        # 设置窗口标题
        self.setWindowTitle('Retro Tank Game')
        
        # 创建WebEngine视图
        self.web_view = QWebEngineView()
        self.setCentralWidget(self.web_view)
        
        # 获取simple-version.html的绝对路径
        current_dir = os.path.dirname(os.path.abspath(__file__))
        html_path = os.path.join(current_dir, 'simple-version.html')
        
        # 打印调试信息
        print(f"当前目录: {current_dir}")
        print(f"HTML文件路径: {html_path}")
        print(f"HTML文件是否存在: {os.path.exists(html_path)}")
        
        # 读取HTML文件内容
        try:
            with open(html_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
            print(f"HTML文件读取成功，内容长度: {len(html_content)}")
            
            # 直接加载HTML内容
            self.web_view.setHtml(html_content)
        except Exception as e:
            print(f"读取HTML文件失败: {e}")
        
        # 设置窗口大小并显示
        self.resize(1024, 768)
        self.show()
        
        # 禁用滚动条
        self.web_view.setContextMenuPolicy(Qt.NoContextMenu)
        
        # 注入JavaScript来禁用滚动
        self.web_view.page().loadFinished.connect(self.on_load_finished)
    
    def check_anti_addiction(self):
        """执行防沉迷检查"""
        # 首次运行，需要设置生日
        if self.config.is_first_run():
            dialog = BirthdayDialog(self.config)
            if dialog.exec_() != QDialog.Accepted:
                return False
        
        # 检查是否为未成年人
        if self.config.is_under_18():
            # 如果未成年人还没有设置家长密码，需要设置
            if not self.config.has_parent_password():
                dialog = ParentPasswordDialog(self.config)
                if dialog.exec_() != QDialog.Accepted:
                    return False
            
            # 检查是否在允许的游戏时间
            if not self.config.is_allowed_time():
                remaining = self.config.get_remaining_time()
                hours = remaining // 3600
                minutes = (remaining % 3600) // 60
                
                reply = QMessageBox.question(
                    self, 
                    '时间限制',
                    f'当前不在游戏时间！未成年人只能在中午12:00-13:00玩游戏。\n\n距离下次可玩游戏还有：{hours}小时{minutes}分钟\n\n是否使用家长密码解锁？',
                    QMessageBox.Yes | QMessageBox.No
                )
                
                if reply == QMessageBox.Yes:
                    dialog = VerifyPasswordDialog(self.config)
                    if dialog.exec_() != QDialog.Accepted or not dialog.verified:
                        return False
                else:
                    return False
        
        # 人机验证
        dialog = CaptchaDialog()
        if dialog.exec_() != QDialog.Accepted or not dialog.verified:
            return False
        
        return True
    
    def on_load_finished(self, success):
        """页面加载完成后的回调"""
        print(f"页面加载完成: {'成功' if success else '失败'}")
        
        # 禁用滚动的JavaScript代码
        js_code = """
        document.body.style.overflow = 'hidden';
        document.documentElement.style.overflow = 'hidden';
        window.addEventListener('scroll', function(e) {
            window.scrollTo(0, 0);
        });
        console.log('滚动已禁用');
        """
        self.web_view.page().runJavaScript(js_code, lambda result: print(f"JavaScript执行结果: {result}"))
        
        # 检查页面内容
        check_js = """
        console.log('页面标题:', document.title);
        console.log('body内容长度:', document.body.innerHTML.length);
        document.body.innerHTML.length;
        """
        self.web_view.page().runJavaScript(check_js, lambda result: print(f"页面内容长度: {result}"))
    
    def keyPressEvent(self, event):
        """处理键盘事件，防止某些按键触发滚动"""
        # 阻止空格键和方向键触发滚动
        if event.key() in [Qt.Key_Space, Qt.Key_Up, Qt.Key_Down, Qt.Key_Left, Qt.Key_Right]:
            pass
        else:
            super().keyPressEvent(event)


def main():
    # 创建应用程序实例
    app = QApplication(sys.argv)
    
    # 创建并显示主窗口
    window = FullScreenBrowser()
    
    # 如果窗口没有显示，说明防沉迷检查失败
    if not window.isVisible():
        sys.exit(0)
    
    # 运行应用程序
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
