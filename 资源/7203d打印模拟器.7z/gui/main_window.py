from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QFileDialog, QLabel, QProgressBar, QStatusBar,
    QAction, QMenuBar, QToolBar
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
import sys
import os

from core.simulator import Simulator
from gui.parameter_panel import ParameterPanel
from gui.visualization import ModelVisualizer

class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.simulator = Simulator()
        self.init_ui()
    
    def init_ui(self):
        """初始化界面"""
        # 设置窗口标题和大小
        self.setWindowTitle("7203d打印模拟器")
        self.setGeometry(100, 100, 1200, 800)
        
        # 创建菜单栏
        self.create_menu_bar()
        
        # 创建工具栏
        self.create_tool_bar()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 创建左侧模型预览区
        self.visualizer = ModelVisualizer()
        main_layout.addWidget(self.visualizer, 2)
        
        # 创建右侧控制面板
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        main_layout.addWidget(right_panel, 1)
        
        # 创建标签页
        tab_widget = QTabWidget()
        right_layout.addWidget(tab_widget)
        
        # 创建参数设置面板
        self.parameter_panel = ParameterPanel()
        tab_widget.addTab(self.parameter_panel, "参数设置")
        
        # 创建模拟结果面板
        self.result_panel = QWidget()
        result_layout = QVBoxLayout(self.result_panel)
        
        # 打印时间估算
        self.time_label = QLabel("打印时间: --")
        result_layout.addWidget(self.time_label)
        
        # 材料用量估算
        self.material_label = QLabel("材料用量: --")
        result_layout.addWidget(self.material_label)
        
        # 层信息
        self.layer_label = QLabel("层数: --")
        result_layout.addWidget(self.layer_label)
        
        # 模拟进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        result_layout.addWidget(self.progress_bar)
        
        tab_widget.addTab(self.result_panel, "模拟结果")
        
        # 创建操作按钮
        button_layout = QHBoxLayout()
        
        self.load_button = QPushButton("加载模型")
        self.load_button.clicked.connect(self.load_model)
        button_layout.addWidget(self.load_button)
        
        self.slice_button = QPushButton("切片")
        self.slice_button.clicked.connect(self.slice_model)
        self.slice_button.setEnabled(False)
        button_layout.addWidget(self.slice_button)
        
        self.simulate_button = QPushButton("模拟打印")
        self.simulate_button.clicked.connect(self.simulate_print)
        self.simulate_button.setEnabled(False)
        button_layout.addWidget(self.simulate_button)
        
        right_layout.addLayout(button_layout)
        
        # 创建状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪")
    
    def create_menu_bar(self):
        """创建菜单栏"""
        menu_bar = QMenuBar()
        self.setMenuBar(menu_bar)
        
        # 文件菜单
        file_menu = menu_bar.addMenu("文件")
        
        load_action = QAction("加载模型", self)
        load_action.triggered.connect(self.load_model)
        file_menu.addAction(load_action)
        
        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # 模拟菜单
        simulate_menu = menu_bar.addMenu("模拟")
        
        slice_action = QAction("切片", self)
        slice_action.triggered.connect(self.slice_model)
        simulate_menu.addAction(slice_action)
        
        simulate_action = QAction("模拟打印", self)
        simulate_action.triggered.connect(self.simulate_print)
        simulate_menu.addAction(simulate_action)
    
    def create_tool_bar(self):
        """创建工具栏"""
        tool_bar = QToolBar("工具栏")
        self.addToolBar(tool_bar)
        
        load_action = QAction("加载模型", self)
        load_action.triggered.connect(self.load_model)
        tool_bar.addAction(load_action)
        
        slice_action = QAction("切片", self)
        slice_action.triggered.connect(self.slice_model)
        tool_bar.addAction(slice_action)
        
        simulate_action = QAction("模拟打印", self)
        simulate_action.triggered.connect(self.simulate_print)
        tool_bar.addAction(simulate_action)
    
    def load_model(self):
        """加载模型"""
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getOpenFileName(
            self, "加载3D模型", "", "3D模型文件 (*.stl *.obj)", options=options
        )
        
        if file_path:
            try:
                self.status_bar.showMessage("正在加载模型...")
                model = self.simulator.load_model(file_path)
                self.visualizer.update_model(model)
                self.status_bar.showMessage(f"成功加载模型: {os.path.basename(file_path)}")
                self.slice_button.setEnabled(True)
            except Exception as e:
                self.status_bar.showMessage(f"加载模型失败: {str(e)}")
    
    def slice_model(self):
        """切片模型"""
        try:
            self.status_bar.showMessage("正在切片...")
            layer_height = self.parameter_panel.get_layer_height()
            self.simulator.slice(layer_height)
            
            # 生成路径
            line_width = self.parameter_panel.get_line_width()
            infill_density = self.parameter_panel.get_infill_density()
            infill_angle = self.parameter_panel.get_infill_angle()
            self.simulator.generate_paths(line_width, infill_density, infill_angle)
            
            self.status_bar.showMessage("切片完成")
            self.simulate_button.setEnabled(True)
        except Exception as e:
            self.status_bar.showMessage(f"切片失败: {str(e)}")
    
    def simulate_print(self):
        """模拟打印"""
        try:
            self.status_bar.showMessage("正在模拟打印...")
            
            # 获取打印参数
            print_speed = self.parameter_panel.get_print_speed()
            travel_speed = self.parameter_panel.get_travel_speed()
            nozzle_temp = self.parameter_panel.get_nozzle_temp()
            bed_temp = self.parameter_panel.get_bed_temp()
            
            # 运行模拟
            self.simulator.simulate(print_speed, travel_speed, nozzle_temp, bed_temp)
            
            # 更新结果显示
            time_estimate = self.simulator.get_print_time_estimate()
            self.time_label.setText(f"打印时间: {time_estimate['formatted_time']}")
            
            material_estimate = self.simulator.get_material_estimate()
            self.material_label.setText(f"材料用量: {material_estimate['length_m']:.2f}m ({material_estimate['weight_g']:.2f}g)")
            
            layer_count = self.simulator.simulation_data['layer_count']
            self.layer_label.setText(f"层数: {layer_count}")
            
            # 更新进度条
            self.progress_bar.setValue(100)
            
            self.status_bar.showMessage("模拟完成")
        except Exception as e:
            self.status_bar.showMessage(f"模拟失败: {str(e)}")
