from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# 设置Matplotlib中文字体
plt.rcParams['font.sans-serif'] = ['Heiti SC', 'Arial Unicode MS']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

class ModelVisualizer(QWidget):
    """3D模型可视化组件"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.model = None
    
    def init_ui(self):
        """初始化界面"""
        # 创建布局
        layout = QVBoxLayout(self)
        
        # 创建matplotlib图形
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        
        # 添加到布局
        layout.addWidget(self.canvas)
        
        # 创建3D轴
        self.ax = self.figure.add_subplot(111, projection='3d')
        self.ax.set_title('3D模型预览')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        
        # 更新画布
        self.canvas.draw()
    
    def update_model(self, model):
        """
        更新显示的模型
        
        Args:
            model (trimesh.Trimesh): 3D模型对象
        """
        self.model = model
        self._plot_model()
    
    def _plot_model(self):
        """绘制3D模型"""
        if not self.model:
            return
        
        # 清除当前图形
        self.ax.clear()
        self.ax.set_title('3D模型预览')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        
        try:
            # 获取模型的顶点和面
            vertices = self.model.vertices
            faces = self.model.faces
            
            # 绘制模型
            self.ax.plot_trisurf(
                vertices[:, 0],
                vertices[:, 1],
                vertices[:, 2],
                triangles=faces,
                cmap='viridis',
                alpha=0.7
            )
            
            # 调整视角
            self.ax.view_init(30, 45)
            
            # 自动调整坐标轴范围
            self.ax.auto_scale_xyz(
                vertices[:, 0],
                vertices[:, 1],
                vertices[:, 2]
            )
            
            # 保持坐标轴比例一致
            self.ax.set_box_aspect([1, 1, 1])
            
            # 更新画布
            self.canvas.draw()
        except Exception as e:
            print(f"绘制模型失败: {str(e)}")
    
    def visualize_paths(self, path_result):
        """
        可视化打印路径
        
        Args:
            path_result (dict): 路径生成结果
        """
        if not self.model or not path_result:
            return
        
        # 清除当前图形
        self.ax.clear()
        self.ax.set_title('打印路径可视化')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        
        try:
            # 绘制模型（半透明）
            vertices = self.model.vertices
            faces = self.model.faces
            self.ax.plot_trisurf(
                vertices[:, 0],
                vertices[:, 1],
                vertices[:, 2],
                triangles=faces,
                color='gray',
                alpha=0.3
            )
            
            # 绘制路径
            for layer_index, layer_paths in path_result['layer_paths'].items():
                # 绘制轮廓路径
                for contour in layer_paths['contours']:
                    contour = np.array(contour)
                    if len(contour) > 1:
                        # 添加Z坐标（使用层索引作为近似Z值）
                        z = np.full(len(contour), layer_index * 0.2)  # 假设层厚为0.2
                        self.ax.plot(contour[:, 0], contour[:, 1], z, 'r-', linewidth=1)
                
                # 绘制填充路径
                for infill in layer_paths['infill']:
                    infill = np.array(infill)
                    if len(infill) > 1:
                        # 添加Z坐标
                        z = np.full(len(infill), layer_index * 0.2)
                        self.ax.plot(infill[:, 0], infill[:, 1], z, 'g-', linewidth=0.5)
            
            # 调整视角
            self.ax.view_init(30, 45)
            
            # 保持坐标轴比例一致
            self.ax.set_box_aspect([1, 1, 1])
            
            # 更新画布
            self.canvas.draw()
        except Exception as e:
            print(f"绘制路径失败: {str(e)}")
    
    def visualize_layer(self, slice_result, layer_index):
        """
        可视化指定层
        
        Args:
            slice_result (dict): 切片结果
            layer_index (int): 层索引
        """
        if not slice_result or layer_index not in slice_result['layers']:
            return
        
        # 清除当前图形
        self.ax.clear()
        self.ax.set_title(f'层 {layer_index} 可视化')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        
        try:
            # 获取层信息
            layer_info = slice_result['layers'][layer_index]
            z = layer_info['z']
            polygons = layer_info['polygons']
            
            # 绘制层轮廓
            for polygon in polygons:
                polygon = np.array(polygon)
                if len(polygon) > 1:
                    # 添加Z坐标
                    z_coords = np.full(len(polygon), z)
                    self.ax.plot(polygon[:, 0], polygon[:, 1], z_coords, 'r-', linewidth=2)
                    
                    # 填充多边形
                    self.ax.fill(polygon[:, 0], polygon[:, 1], z_coords, 'r', alpha=0.5)
            
            # 调整视角
            self.ax.view_init(90, 0)  # 俯视图
            
            # 保持坐标轴比例一致
            self.ax.set_box_aspect([1, 1, 0.1])  # Z轴比例缩小，因为是俯视图
            
            # 更新画布
            self.canvas.draw()
        except Exception as e:
            print(f"绘制层失败: {str(e)}")
