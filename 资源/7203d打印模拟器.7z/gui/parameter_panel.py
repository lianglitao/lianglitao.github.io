from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QDoubleSpinBox,
    QSpinBox, QGroupBox, QFormLayout
)
from PyQt5.QtCore import Qt

class ParameterPanel(QWidget):
    """参数设置面板"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        """初始化界面"""
        # 创建主布局
        main_layout = QVBoxLayout(self)
        
        # 创建切片参数组
        slice_group = QGroupBox("切片参数")
        slice_layout = QFormLayout(slice_group)
        
        # 层厚
        self.layer_height_spin = QDoubleSpinBox()
        self.layer_height_spin.setRange(0.05, 1.0)
        self.layer_height_spin.setSingleStep(0.05)
        self.layer_height_spin.setValue(0.2)
        slice_layout.addRow("层厚 (mm):", self.layer_height_spin)
        
        # 线宽
        self.line_width_spin = QDoubleSpinBox()
        self.line_width_spin.setRange(0.2, 1.0)
        self.line_width_spin.setSingleStep(0.05)
        self.line_width_spin.setValue(0.4)
        slice_layout.addRow("线宽 (mm):", self.line_width_spin)
        
        # 填充参数
        infill_group = QGroupBox("填充参数")
        infill_layout = QFormLayout(infill_group)
        
        # 填充密度
        self.infill_density_spin = QDoubleSpinBox()
        self.infill_density_spin.setRange(0.05, 1.0)
        self.infill_density_spin.setSingleStep(0.05)
        self.infill_density_spin.setValue(0.2)
        infill_layout.addRow("填充密度:", self.infill_density_spin)
        
        # 填充角度
        self.infill_angle_spin = QSpinBox()
        self.infill_angle_spin.setRange(0, 90)
        self.infill_angle_spin.setSingleStep(5)
        self.infill_angle_spin.setValue(45)
        infill_layout.addRow("填充角度 (°):", self.infill_angle_spin)
        
        # 打印参数
        print_group = QGroupBox("打印参数")
        print_layout = QFormLayout(print_group)
        
        # 打印速度
        self.print_speed_spin = QDoubleSpinBox()
        self.print_speed_spin.setRange(10, 200)
        self.print_speed_spin.setSingleStep(10)
        self.print_speed_spin.setValue(60)
        print_layout.addRow("打印速度 (mm/s):", self.print_speed_spin)
        
        # 移动速度
        self.travel_speed_spin = QDoubleSpinBox()
        self.travel_speed_spin.setRange(50, 300)
        self.travel_speed_spin.setSingleStep(10)
        self.travel_speed_spin.setValue(120)
        print_layout.addRow("移动速度 (mm/s):", self.travel_speed_spin)
        
        # 温度参数
        temp_group = QGroupBox("温度参数")
        temp_layout = QFormLayout(temp_group)
        
        # 喷嘴温度
        self.nozzle_temp_spin = QSpinBox()
        self.nozzle_temp_spin.setRange(180, 280)
        self.nozzle_temp_spin.setSingleStep(5)
        self.nozzle_temp_spin.setValue(200)
        temp_layout.addRow("喷嘴温度 (°C):", self.nozzle_temp_spin)
        
        # 热床温度
        self.bed_temp_spin = QSpinBox()
        self.bed_temp_spin.setRange(0, 120)
        self.bed_temp_spin.setSingleStep(5)
        self.bed_temp_spin.setValue(60)
        temp_layout.addRow("热床温度 (°C):", self.bed_temp_spin)
        
        # 添加所有组到主布局
        main_layout.addWidget(slice_group)
        main_layout.addWidget(infill_group)
        main_layout.addWidget(print_group)
        main_layout.addWidget(temp_group)
        
        # 添加拉伸空间
        main_layout.addStretch()
    
    def get_layer_height(self):
        """获取层厚"""
        return self.layer_height_spin.value()
    
    def get_line_width(self):
        """获取线宽"""
        return self.line_width_spin.value()
    
    def get_infill_density(self):
        """获取填充密度"""
        return self.infill_density_spin.value()
    
    def get_infill_angle(self):
        """获取填充角度"""
        return self.infill_angle_spin.value()
    
    def get_print_speed(self):
        """获取打印速度"""
        return self.print_speed_spin.value()
    
    def get_travel_speed(self):
        """获取移动速度"""
        return self.travel_speed_spin.value()
    
    def get_nozzle_temp(self):
        """获取喷嘴温度"""
        return self.nozzle_temp_spin.value()
    
    def get_bed_temp(self):
        """获取热床温度"""
        return self.bed_temp_spin.value()
