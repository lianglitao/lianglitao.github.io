#!/bin/bash

# 切换到脚本所在目录
cd "$(dirname "$0")"

echo "启动7203d打印模拟器..."

# 运行应用程序
python3 main.py
