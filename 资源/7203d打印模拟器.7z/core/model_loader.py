import trimesh
import os

class ModelLoader:
    """模型加载器，支持STL和OBJ格式"""
    
    def __init__(self):
        pass
    
    def load_model(self, file_path):
        """
        加载3D模型文件
        
        Args:
            file_path (str): 模型文件路径
            
        Returns:
            trimesh.Trimesh: 加载的3D模型对象
            
        Raises:
            ValueError: 不支持的文件格式
            FileNotFoundError: 文件不存在
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        # 获取文件扩展名
        ext = os.path.splitext(file_path)[1].lower()
        
        # 检查文件格式是否支持
        if ext not in ['.stl', '.obj']:
            raise ValueError(f"不支持的文件格式: {ext}，仅支持STL和OBJ格式")
        
        try:
            # 使用trimesh加载模型
            model = trimesh.load(file_path)
            return model
        except Exception as e:
            raise Exception(f"加载模型失败: {str(e)}")
    
    def get_model_info(self, model):
        """
        获取模型信息
        
        Args:
            model (trimesh.Trimesh): 3D模型对象
            
        Returns:
            dict: 模型信息字典
        """
        info = {
            'vertices': len(model.vertices),
            'faces': len(model.faces),
            'volume': model.volume,
            'bounds': model.bounds,
            'extents': model.extents
        }
        return info
