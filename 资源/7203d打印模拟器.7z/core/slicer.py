import trimesh
import numpy as np

class Slicer:
    """3D模型切片器"""
    
    def __init__(self):
        pass
    
    def slice_model(self, model, layer_height=0.2):
        """
        对3D模型进行切片
        
        Args:
            model (trimesh.Trimesh): 3D模型对象
            layer_height (float): 层厚，默认0.2mm
            
        Returns:
            dict: 切片结果字典，包含每层的轮廓
        """
        # 获取模型的Z轴范围
        z_min, z_max = model.bounds[0][2], model.bounds[1][2]
        
        # 计算总层数
        layer_count = int(np.ceil((z_max - z_min) / layer_height))
        
        # 生成每层的Z坐标
        z_heights = np.linspace(z_min, z_max, layer_count)
        
        # 存储切片结果
        slices = {}
        
        for i, z in enumerate(z_heights):
            # 使用trimesh的切片功能
            slice_result = model.section(plane_origin=[0, 0, z], 
                                       plane_normal=[0, 0, 1])
            
            if slice_result:
                # 获取切片轮廓
                polygons = []
                # 遍历所有实体
                for entity in slice_result.entities:
                    # 获取实体的顶点索引
                    if hasattr(entity, 'points'):
                        # 获取多边形顶点
                        vertices = slice_result.vertices[entity.points]
                        polygons.append(vertices.tolist())
                
                slices[i] = {
                    'z': z,
                    'layer_index': i,
                    'polygons': polygons
                }
        
        return {
            'layers': slices,
            'layer_count': layer_count,
            'layer_height': layer_height,
            'z_range': (z_min, z_max)
        }
    
    def get_layer_info(self, slice_result, layer_index):
        """
        获取指定层的信息
        
        Args:
            slice_result (dict): 切片结果
            layer_index (int): 层索引
            
        Returns:
            dict: 层信息
        """
        if layer_index in slice_result['layers']:
            return slice_result['layers'][layer_index]
        return None
