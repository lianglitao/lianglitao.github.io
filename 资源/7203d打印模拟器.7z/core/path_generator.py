import numpy as np
from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union

class PathGenerator:
    """打印路径生成器"""
    
    def __init__(self):
        pass
    
    def generate_paths(self, slice_result, line_width=0.4, infill_density=0.2, infill_angle=45):
        """
        为切片结果生成打印路径
        
        Args:
            slice_result (dict): 切片结果
            line_width (float): 线宽，默认0.4mm
            infill_density (float): 填充密度，默认0.2（20%）
            infill_angle (float): 填充角度，默认45度
            
        Returns:
            dict: 包含每层路径的字典
        """
        paths = {}
        
        for layer_index, layer_info in slice_result['layers'].items():
            polygons = layer_info['polygons']
            layer_paths = {
                'contours': [],
                'infill': [],
                'travel': []
            }
            
            # 生成轮廓路径
            for polygon in polygons:
                if len(polygon) >= 3:
                    # 生成外轮廓路径
                    contour_path = self._generate_contour(polygon, line_width)
                    layer_paths['contours'].append(contour_path)
                    
                    # 生成填充路径
                    infill_paths = self._generate_infill(polygon, line_width, infill_density, infill_angle)
                    layer_paths['infill'].extend(infill_paths)
            
            # 优化路径顺序
            optimized_paths = self._optimize_path_order(layer_paths)
            paths[layer_index] = optimized_paths
        
        return {
            'layer_paths': paths,
            'line_width': line_width,
            'infill_density': infill_density,
            'infill_angle': infill_angle
        }
    
    def _generate_contour(self, polygon, line_width):
        """
        生成轮廓路径
        
        Args:
            polygon (list): 多边形顶点列表
            line_width (float): 线宽
            
        Returns:
            list: 轮廓路径点列表
        """
        # 简单返回多边形顶点作为轮廓路径
        # 实际应用中可能需要偏移轮廓以考虑线宽
        return polygon
    
    def _generate_infill(self, polygon, line_width, infill_density, infill_angle):
        """
        生成填充路径
        
        Args:
            polygon (list): 多边形顶点列表
            line_width (float): 线宽
            infill_density (float): 填充密度
            infill_angle (float): 填充角度
            
        Returns:
            list: 填充路径列表
        """
        try:
            # 创建多边形对象
            poly = Polygon(polygon)
            
            # 计算填充线间距
            line_spacing = line_width / infill_density
            
            # 获取多边形边界
            min_x, min_y, max_x, max_y = poly.bounds
            
            # 计算填充线长度
            diagonal_length = np.sqrt((max_x - min_x)**2 + (max_y - min_y)**2)
            
            # 生成填充线
            infill_lines = []
            angle_rad = np.radians(infill_angle)
            
            # 计算填充线的起点和终点
            start_x = min_x - diagonal_length
            start_y = min_y - diagonal_length
            end_x = max_x + diagonal_length
            end_y = max_y + diagonal_length
            
            # 生成平行填充线
            y_offset = 0
            while y_offset < diagonal_length * 2:
                # 计算当前填充线的起点和终点
                x1 = start_x
                y1 = start_y + y_offset
                x2 = end_x
                y2 = y1 + (end_x - start_x) * np.tan(angle_rad)
                
                # 创建填充线
                line = LineString([(x1, y1), (x2, y2)])
                
                # 计算与多边形的交集
                intersection = poly.intersection(line)
                if not intersection.is_empty:
                    if hasattr(intersection, 'geoms'):
                        for geom in intersection.geoms:
                            if isinstance(geom, LineString):
                                coords = list(geom.coords)
                                infill_lines.append(coords)
                    elif isinstance(intersection, LineString):
                        coords = list(intersection.coords)
                        infill_lines.append(coords)
                
                # 移动到下一条填充线
                y_offset += line_spacing * np.cos(angle_rad)
            
            return infill_lines
        except Exception as e:
            return []
    
    def _optimize_path_order(self, layer_paths):
        """
        优化路径顺序以减少移动距离
        
        Args:
            layer_paths (dict): 层路径字典
            
        Returns:
            dict: 优化后的层路径字典
        """
        # 简单返回原路径
        # 实际应用中可能需要更复杂的路径优化算法
        return layer_paths
