import numpy as np
from core.model_loader import ModelLoader
from core.slicer import Slicer
from core.path_generator import PathGenerator

class Simulator:
    """3D打印模拟器核心"""
    
    def __init__(self):
        self.model_loader = ModelLoader()
        self.slicer = Slicer()
        self.path_generator = PathGenerator()
        self.model = None
        self.slice_result = None
        self.path_result = None
        self.simulation_data = None
    
    def load_model(self, file_path):
        """
        加载3D模型
        
        Args:
            file_path (str): 模型文件路径
        """
        self.model = self.model_loader.load_model(file_path)
        return self.model
    
    def slice(self, layer_height=0.2):
        """
        对模型进行切片
        
        Args:
            layer_height (float): 层厚
        """
        if not self.model:
            raise Exception("请先加载模型")
        
        self.slice_result = self.slicer.slice_model(self.model, layer_height)
        return self.slice_result
    
    def generate_paths(self, line_width=0.4, infill_density=0.2, infill_angle=45):
        """
        生成打印路径
        
        Args:
            line_width (float): 线宽
            infill_density (float): 填充密度
            infill_angle (float): 填充角度
        """
        if not self.slice_result:
            raise Exception("请先对模型进行切片")
        
        self.path_result = self.path_generator.generate_paths(
            self.slice_result, line_width, infill_density, infill_angle
        )
        return self.path_result
    
    def simulate(self, print_speed=60, travel_speed=120, nozzle_temp=200, bed_temp=60):
        """
        模拟打印过程
        
        Args:
            print_speed (float): 打印速度，mm/s
            travel_speed (float): 移动速度，mm/s
            nozzle_temp (float): 喷嘴温度，℃
            bed_temp (float): 热床温度，℃
        """
        if not self.path_result:
            raise Exception("请先生成打印路径")
        
        # 计算总打印时间和材料用量
        total_time = 0
        total_material = 0
        layer_times = {}
        
        for layer_index, layer_paths in self.path_result['layer_paths'].items():
            layer_time = 0
            layer_material = 0
            
            # 计算轮廓路径时间和材料
            for contour in layer_paths['contours']:
                length = self._calculate_path_length(contour)
                layer_time += length / print_speed
                layer_material += length
            
            # 计算填充路径时间和材料
            for infill in layer_paths['infill']:
                length = self._calculate_path_length(infill)
                layer_time += length / print_speed
                layer_material += length
            
            # 计算移动路径时间（简化计算）
            travel_time = self._estimate_travel_time(layer_paths)
            layer_time += travel_time
            
            layer_times[layer_index] = layer_time
            total_time += layer_time
            total_material += layer_material
        
        # 生成模拟数据
        self.simulation_data = {
            'total_time': total_time,
            'total_material': total_material,
            'layer_times': layer_times,
            'print_speed': print_speed,
            'travel_speed': travel_speed,
            'nozzle_temp': nozzle_temp,
            'bed_temp': bed_temp,
            'layer_count': len(self.path_result['layer_paths'])
        }
        
        return self.simulation_data
    
    def _calculate_path_length(self, path):
        """
        计算路径长度
        
        Args:
            path (list): 路径点列表
            
        Returns:
            float: 路径长度
        """
        length = 0
        for i in range(1, len(path)):
            prev_point = np.array(path[i-1])
            curr_point = np.array(path[i])
            length += np.linalg.norm(curr_point - prev_point)
        return length
    
    def _estimate_travel_time(self, layer_paths):
        """
        估算移动时间
        
        Args:
            layer_paths (dict): 层路径字典
            
        Returns:
            float: 估算的移动时间
        """
        # 简化估算：假设每个路径之间有一次移动，移动距离为线宽的10倍
        total_paths = len(layer_paths['contours']) + len(layer_paths['infill'])
        avg_travel_distance = 10 * self.path_result['line_width']
        return total_paths * avg_travel_distance / 120  # 使用默认移动速度
    
    def get_print_time_estimate(self):
        """
        获取打印时间估算
        
        Returns:
            dict: 打印时间估算信息
        """
        if not self.simulation_data:
            raise Exception("请先运行模拟")
        
        total_time = self.simulation_data['total_time']
        hours = int(total_time // 3600)
        minutes = int((total_time % 3600) // 60)
        seconds = int(total_time % 60)
        
        return {
            'total_seconds': total_time,
            'formatted_time': f"{hours}h {minutes}m {seconds}s",
            'layer_times': self.simulation_data['layer_times']
        }
    
    def get_material_estimate(self, filament_diameter=1.75):
        """
        获取材料用量估算
        
        Args:
            filament_diameter (float):  filament直径，mm
            
        Returns:
            dict: 材料用量估算信息
        """
        if not self.simulation_data:
            raise Exception("请先运行模拟")
        
        total_length = self.simulation_data['total_material']
        # 计算体积
        radius = filament_diameter / 2
        volume = total_length * (np.pi * radius ** 2)
        
        # 估算重量（假设密度为1.25g/cm³）
        density = 1.25  # g/cm³
        weight = volume * density / 1000  # 转换为g
        
        return {
            'length_mm': total_length,
            'length_m': total_length / 1000,
            'volume_cm3': volume / 1000,
            'weight_g': weight
        }
    
    def simulate_error(self, error_type, layer_index):
        """
        模拟打印异常情况
        
        Args:
            error_type (str): 异常类型
            layer_index (int): 发生异常的层索引
            
        Returns:
            dict: 异常信息
        """
        error_messages = {
            'clog': "喷嘴堵塞",
            'warping': "翘边",
            'stringing': "拉丝",
            'under_extrusion': "挤出不足",
            'over_extrusion': "挤出过度"
        }
        
        if error_type not in error_messages:
            raise ValueError(f"不支持的异常类型: {error_type}")
        
        return {
            'error_type': error_type,
            'error_message': error_messages[error_type],
            'layer_index': layer_index,
            'suggestion': self._get_error_suggestion(error_type)
        }
    
    def _get_error_suggestion(self, error_type):
        """
        获取异常处理建议
        
        Args:
            error_type (str): 异常类型
            
        Returns:
            str: 处理建议
        """
        suggestions = {
            'clog': "检查喷嘴是否堵塞，尝试提高温度或清理喷嘴",
            'warping': "提高热床温度，使用底板 adhesive，或增加边缘裙边",
            'stringing': "降低温度，增加回抽距离，或调整打印速度",
            'under_extrusion': "检查 filament 进料是否顺畅，提高温度，或调整挤出倍率",
            'over_extrusion': "调整挤出倍率，降低温度，或检查喷嘴直径"
        }
        
        return suggestions.get(error_type, "请检查打印机设置")
