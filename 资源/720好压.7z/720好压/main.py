#!/usr/bin/env python3
import subprocess
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

class CompressionTool:
    def __init__(self, root):
        self.root = root
        self.root.title("720好压")
        self.root.geometry("800x500")
        self.root.resizable(True, True)
        # 手动指定7z完整路径（从你的终端输出复制）
        self.sevenzip_path = "/opt/homebrew/bin/7z"
        self.create_main_menu()

    def create_main_menu(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        main_frame = ttk.Frame(self.root, padding="40")
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main_frame, text="720好压", font=("Arial", 24)).pack(pady=30)
        ttk.Label(main_frame, text="macOS专用压缩软件", font=("Arial", 14)).pack(pady=10)

        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=40)

        compress_button = ttk.Button(
            button_frame, 
            text="压缩文件", 
            command=self.open_compress_module, 
            width=20
        )
        compress_button.pack(side=tk.LEFT, padx=20, expand=True)

        extract_button = ttk.Button(
            button_frame, 
            text="解压文件", 
            command=self.open_extract_module, 
            width=20
        )
        extract_button.pack(side=tk.RIGHT, padx=20, expand=True)

        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X, pady=20)

        ttk.Button(bottom_frame, text="帮助", command=self.show_help, width=12).pack(side=tk.LEFT, padx=10)
        ttk.Button(bottom_frame, text="退出", command=self.root.quit, width=12).pack(side=tk.RIGHT, padx=10)

    def open_compress_module(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        compress_frame = ttk.Frame(self.root, padding="30")
        compress_frame.pack(fill=tk.BOTH, expand=True)

        header_frame = ttk.Frame(compress_frame)
        header_frame.pack(fill=tk.X, pady=10)

        ttk.Button(header_frame, text="返回主菜单", command=self.create_main_menu).pack(side=tk.LEFT)
        ttk.Label(header_frame, text="压缩文件", font=("Arial", 16)).pack(side=tk.TOP, pady=10)

        ttk.Label(compress_frame, text="选择要压缩的文件或文件夹:").pack(anchor=tk.W, pady=10)

        file_frame = ttk.Frame(compress_frame)
        file_frame.pack(fill=tk.X, pady=5)

        self.compress_file_var = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.compress_file_var, width=60).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(file_frame, text="添加文件", command=self.add_compress_files).pack(side=tk.RIGHT, padx=5)
        ttk.Button(file_frame, text="添加文件夹", command=self.add_compress_folder).pack(side=tk.RIGHT, padx=5)

        ttk.Label(compress_frame, text="选择压缩格式:").pack(anchor=tk.W, pady=10)

        format_frame = ttk.Frame(compress_frame)
        format_frame.pack(fill=tk.X, pady=5)

        self.compress_format_var = tk.StringVar(value="7z")
        formats = ["7z", "zip", "tar", "gzip", "bzip2", "xz"]
        for fmt in formats:
            btn = ttk.Radiobutton(
                format_frame, 
                text=fmt.upper(), 
                value=fmt, 
                variable=self.compress_format_var,
                width=8
            )
            btn.pack(side=tk.LEFT, padx=10)

        option_frame = ttk.LabelFrame(compress_frame, text="压缩选项", padding="10")
        option_frame.pack(fill=tk.X, pady=15)

        level_frame = ttk.Frame(option_frame)
        level_frame.pack(fill=tk.X, pady=5)

        ttk.Label(level_frame, text="压缩级别:").pack(side=tk.LEFT, padx=10)
        self.compress_level_var = tk.IntVar(value=5)

        level_scale = ttk.Scale(
            level_frame, 
            from_=0, 
            to=9, 
            orient=tk.HORIZONTAL, 
            variable=self.compress_level_var, 
            length=300
        )
        level_scale.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        self.level_label = ttk.Label(level_frame, text=str(self.compress_level_var.get()))
        self.level_label.pack(side=tk.LEFT, padx=10)

        level_scale.bind("<Motion>", lambda e: self.level_label.config(text=str(int(self.compress_level_var.get()))))

        password_frame = ttk.Frame(option_frame)
        password_frame.pack(fill=tk.X, pady=5)

        ttk.Label(password_frame, text="密码保护:").pack(side=tk.LEFT, padx=10)
        self.compress_password_var = tk.StringVar()
        ttk.Entry(password_frame, textvariable=self.compress_password_var, show="*", width=40).pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)

        ttk.Label(compress_frame, text="输出路径:").pack(anchor=tk.W, pady=10)

        output_frame = ttk.Frame(compress_frame)
        output_frame.pack(fill=tk.X, pady=5)

        self.compress_output_var = tk.StringVar()
        ttk.Entry(output_frame, textvariable=self.compress_output_var, width=60).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(output_frame, text="选择", command=self.select_compress_output).pack(side=tk.RIGHT, padx=5)

        button_frame = ttk.Frame(compress_frame)
        button_frame.pack(fill=tk.X, pady=20)

        ttk.Button(button_frame, text="开始压缩", command=self.start_compress, width=15).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="清空列表", command=self.clear_compress_files).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="返回", command=self.create_main_menu, width=15).pack(side=tk.RIGHT, padx=10)

        self.compress_status_var = tk.StringVar(value="就绪")
        ttk.Label(compress_frame, textvariable=self.compress_status_var, relief=tk.SUNKEN, anchor=tk.W).pack(fill=tk.X, pady=10)

    def open_extract_module(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        extract_frame = ttk.Frame(self.root, padding="30")
        extract_frame.pack(fill=tk.BOTH, expand=True)

        header_frame = ttk.Frame(extract_frame)
        header_frame.pack(fill=tk.X, pady=10)

        ttk.Button(header_frame, text="返回主菜单", command=self.create_main_menu).pack(side=tk.LEFT)
        ttk.Label(header_frame, text="解压文件", font=("Arial", 16)).pack(side=tk.TOP, pady=10)

        ttk.Label(extract_frame, text="选择要解压的文件:").pack(anchor=tk.W, pady=10)

        file_frame = ttk.Frame(extract_frame)
        file_frame.pack(fill=tk.X, pady=5)

        self.extract_file_var = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.extract_file_var, width=60).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(file_frame, text="选择文件", command=self.select_extract_file).pack(side=tk.RIGHT, padx=5)

        option_frame = ttk.LabelFrame(extract_frame, text="解压选项", padding="10")
        option_frame.pack(fill=tk.X, pady=15)

        password_frame = ttk.Frame(option_frame)
        password_frame.pack(fill=tk.X, pady=5)

        ttk.Label(password_frame, text="密码:").pack(side=tk.LEFT, padx=10)
        self.extract_password_var = tk.StringVar()
        ttk.Entry(password_frame, textvariable=self.extract_password_var, show="*", width=40).pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)

        ttk.Label(extract_frame, text="解压到:").pack(anchor=tk.W, pady=10)

        output_frame = ttk.Frame(extract_frame)
        output_frame.pack(fill=tk.X, pady=5)

        self.extract_output_var = tk.StringVar()
        ttk.Entry(output_frame, textvariable=self.extract_output_var, width=60).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(output_frame, text="选择目录", command=self.select_extract_output).pack(side=tk.RIGHT, padx=5)

        button_frame = ttk.Frame(extract_frame)
        button_frame.pack(fill=tk.X, pady=20)

        ttk.Button(button_frame, text="开始解压", command=self.start_extract, width=15).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="预览内容", command=self.preview_archive).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="返回", command=self.create_main_menu, width=15).pack(side=tk.RIGHT, padx=10)

        self.extract_status_var = tk.StringVar(value="就绪")
        ttk.Label(extract_frame, textvariable=self.extract_status_var, relief=tk.SUNKEN, anchor=tk.W).pack(fill=tk.X, pady=10)

    def add_compress_files(self):
        file_paths = filedialog.askopenfilenames(title="选择要压缩的文件")
        if file_paths:
            current_files = self.compress_file_var.get()
            new_files = " ".join(file_paths)
            if current_files:
                self.compress_file_var.set(current_files + " " + new_files)
            else:
                self.compress_file_var.set(new_files)

    def add_compress_folder(self):
        folder_path = filedialog.askdirectory(title="选择要压缩的文件夹")
        if folder_path:
            current_files = self.compress_file_var.get()
            if current_files:
                self.compress_file_var.set(current_files + " " + folder_path)
            else:
                self.compress_file_var.set(folder_path)

    def select_compress_output(self):
        output_path = filedialog.asksaveasfilename(
            title="保存压缩文件", 
            defaultextension="." + self.compress_format_var.get()
        )
        if output_path:
            self.compress_output_var.set(output_path)

    def clear_compress_files(self):
        self.compress_file_var.set("")

    def select_extract_file(self):
        file_path = filedialog.askopenfilename(title="选择要解压的文件")
        if file_path:
            self.extract_file_var.set(file_path)
            base_name = os.path.splitext(os.path.basename(file_path))[0]
            output_dir = os.path.join(os.path.dirname(file_path), base_name)
            self.extract_output_var.set(output_dir)

    def select_extract_output(self):
        output_path = filedialog.askdirectory(title="选择解压目标目录")
        if output_path:
            self.extract_output_var.set(output_path)

    def start_compress(self):
        input_paths = self.compress_file_var.get()
        output_path = self.compress_output_var.get()
        compression_format = self.compress_format_var.get()
        level = self.compress_level_var.get()
        password = self.compress_password_var.get()

        if not input_paths:
            messagebox.showerror("错误", "请添加要压缩的文件或文件夹")
            return

        if not output_path:
            messagebox.showerror("错误", "请选择输出路径")
            return

        self.compress_status_var.set("正在压缩...")
        self.root.update()

        try:
            # 改用指定的完整7z路径
            cmd = [self.sevenzip_path, "a", f"-t{compression_format}", f"-mx={level}", output_path]
            if password:
                cmd.insert(3, "-p" + password)
            cmd.extend(input_paths.split())
            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                self.compress_status_var.set("压缩成功")
                messagebox.showinfo("成功", f"文件已成功压缩到: {output_path}")
            else:
                self.compress_status_var.set("压缩失败")
                messagebox.showerror("错误", f"压缩失败：{result.stderr}")
        except Exception as e:
            self.compress_status_var.set("压缩失败")
            messagebox.showerror("错误", f"发生错误: {str(e)}")

    def start_extract(self):
        input_path = self.extract_file_var.get()
        output_path = self.extract_output_var.get()
        password = self.extract_password_var.get()

        if not input_path:
            messagebox.showerror("错误", "请选择要解压的文件")
            return

        if not output_path:
            messagebox.showerror("错误", "请选择解压目标路径")
            return

        self.extract_status_var.set("正在解压...")
        self.root.update()

        try:
            # 改用指定的完整7z路径
            cmd = [self.sevenzip_path, "x", input_path, f"-o{output_path}", "-y"]
            if password:
                cmd.insert(3, "-p" + password)
            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                self.extract_status_var.set("解压成功")
                messagebox.showinfo("成功", f"文件已成功解压到: {output_path}")
            else:
                self.extract_status_var.set("解压失败")
                messagebox.showerror("错误", f"解压失败：{result.stderr}")
        except Exception as e:
            self.extract_status_var.set("解压失败")
            messagebox.showerror("错误", f"发生错误: {str(e)}")

    def preview_archive(self):
        input_path = self.extract_file_var.get()
        if not input_path:
            messagebox.showerror("错误", "请选择要预览的文件")
            return

        try:
            # 改用指定的完整7z路径
            cmd = [self.sevenzip_path, "l", input_path]
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                preview_window = tk.Toplevel(self.root)
                preview_window.title("压缩包内容预览")
                preview_window.geometry("800x600")
                text = tk.Text(preview_window, wrap=tk.WORD)
                text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
                text.insert(tk.END, result.stdout)
                text.config(state=tk.DISABLED)
                scrollbar = ttk.Scrollbar(text, command=text.yview)
                scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                text.config(yscrollcommand=scrollbar.set)
                ttk.Button(preview_window, text="关闭", command=preview_window.destroy).pack(pady=10)
            else:
                messagebox.showerror("错误", f"预览失败：{result.stderr}")
        except Exception as e:
            messagebox.showerror("错误", f"发生错误: {str(e)}")

    def show_help(self):
        help_text = """720好压使用帮助

1. 主菜单:
   - 压缩文件: 进入压缩模块
   - 解压文件: 进入解压模块

2. 压缩模块:
   - 添加文件: 选择要压缩的文件
   - 添加文件夹: 选择要压缩的文件夹
   - 选择压缩格式: 使用卡片式按钮选择
   - 压缩级别: 使用滑块调整(0-9)
   - 密码保护: 可选设置
   - 开始压缩: 执行压缩操作

3. 解压模块:
   - 选择文件: 选择要解压的压缩文件
   - 密码: 输入压缩文件的密码
   - 解压到: 选择解压目标目录
   - 预览内容: 查看压缩包内文件列表
   - 开始解压: 执行解压操作

4. 支持的格式:
   - 压缩: 7z, zip, tar, gzip, bzip2, xz
   - 解压: 7z, zip, rar, tar, gzip, bzip2, xz

当前7z路径：/opt/homebrew/bin/7z
"""
        messagebox.showinfo("使用帮助", help_text)

if __name__ == "__main__":
    root = tk.Tk()
    app = CompressionTool(root)
    root.mainloop()
