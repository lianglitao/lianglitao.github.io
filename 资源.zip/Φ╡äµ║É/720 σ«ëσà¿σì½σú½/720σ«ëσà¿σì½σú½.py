#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
720安全卫士 - 现代化杀毒软件
自研核心功能，界面美观直观
"""

import os
import sys
import subprocess
import shutil
import ctypes
import time
import stat
import threading
import queue
import hashlib
import re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# 仅在Windows系统上导入winreg
winreg = None
if sys.platform.startswith('win'):
    try:
        import winreg
    except ImportError:
        pass


# MalwareScanner类已移除，仅使用Windows Defender作为扫描引擎


class SystemCleaner:
    """自研系统清理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
        self.temp_dirs = self._get_temp_dirs()
    
    def _get_temp_dirs(self):
        """获取系统临时目录"""
        temp_dirs = []
        
        # 系统临时目录
        if self.is_windows:
            temp_dirs.append(os.environ.get('TEMP', 'C:\\Windows\\Temp'))
            temp_dirs.append(os.environ.get('TMP', 'C:\\Windows\\Temp'))
            # 用户临时目录
            user_temp = os.path.join(os.environ.get('USERPROFILE', 'C:\\Users\\Default'), 'AppData', 'Local', 'Temp')
            temp_dirs.append(user_temp)
        else:
            # 非Windows系统
            temp_dirs.append('/tmp')
            if 'HOME' in os.environ:
                temp_dirs.append(os.path.join(os.environ['HOME'], '.cache'))
        
        return list(set(temp_dirs))
    
    def _is_file_in_use(self, file_path):
        """检查文件是否被占用"""
        try:
            with open(file_path, 'a'):
                pass
            return False
        except:
            return True
    
    def _get_file_size(self, file_path):
        """获取文件大小"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0
    
    def clean_temp_files(self, confirm=True):
        """清理临时文件"""
        results = {
            'total_files': 0,
            'cleaned_files': 0,
            'failed_files': 0,
            'total_size': 0,
            'cleaned_size': 0,
            'logs': []
        }
        
        for temp_dir in self.temp_dirs:
            if not os.path.exists(temp_dir):
                results['logs'].append(f"跳过：{temp_dir}（目录不存在）")
                continue
            
            results['logs'].append(f"\n开始清理：{temp_dir}")
            
            try:
                for root, dirs, files in os.walk(temp_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        results['total_files'] += 1
                        file_size = self._get_file_size(file_path)
                        results['total_size'] += file_size
                        
                        try:
                            # 检查文件是否被占用
                            if self._is_file_in_use(file_path):
                                results['logs'].append(f"跳过：{file_path}（文件被占用）")
                                results['failed_files'] += 1
                                continue
                            
                            # 尝试删除文件
                            os.chmod(file_path, stat.S_IWRITE)  # 确保有写权限
                            os.unlink(file_path)
                            results['logs'].append(f"已删除：{file_path}")
                            results['cleaned_files'] += 1
                            results['cleaned_size'] += file_size
                        except Exception as e:
                            results['logs'].append(f"失败：{file_path} - {e}")
                            results['failed_files'] += 1
                    
                    # 尝试删除空目录
                    for dir_name in dirs:
                        dir_path = os.path.join(root, dir_name)
                        try:
                            os.rmdir(dir_path)
                            results['logs'].append(f"已删除目录：{dir_path}")
                        except:
                            pass
            except Exception as e:
                results['logs'].append(f"清理错误：{temp_dir} - {e}")
        
        return results
    
    def clean_browser_cache(self, browser=None):
        """清理浏览器缓存"""
        # 支持的浏览器
        browsers = {
            'chrome': [
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data\Default\Cache'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data\Default\Cookies')
            ],
            'edge': [
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data\Default\Cache'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data\Default\Cookies')
            ],
            'firefox': [
                os.path.join(os.environ.get('APPDATA', ''), r'Mozilla\Firefox\Profiles')
            ]
        }
        
        results = {
            'browser': browser,
            'cleaned': 0,
            'logs': []
        }
        
        if not browser:
            # 清理所有支持的浏览器
            for browser_name, paths in browsers.items():
                for path in paths:
                    if os.path.exists(path):
                        try:
                            if os.path.isdir(path):
                                shutil.rmtree(path)
                            else:
                                os.unlink(path)
                            results['cleaned'] += 1
                            results['logs'].append(f"已清理：{path}")
                        except Exception as e:
                            results['logs'].append(f"清理失败：{path} - {e}")
        else:
            # 清理指定浏览器
            if browser.lower() in browsers:
                for path in browsers[browser.lower()]:
                    if os.path.exists(path):
                        try:
                            if os.path.isdir(path):
                                shutil.rmtree(path)
                            else:
                                os.unlink(path)
                            results['cleaned'] += 1
                            results['logs'].append(f"已清理：{path}")
                        except Exception as e:
                            results['logs'].append(f"清理失败：{path} - {e}")
            else:
                results['logs'].append(f"不支持的浏览器：{browser}")
        
        return results


class ThirdPartyTools:
    """第三方工具管理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
        # 获取当前脚本所在目录，用于存放预制工具
        self.tools_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        
        # 确保工具目录存在
        if not os.path.exists(self.tools_dir):
            os.makedirs(self.tools_dir, exist_ok=True)
        
        # 工具配置 - 使用本地预制工具
        self.tools = {
            'process_explorer': {
                'name': 'Process Explorer',
                'local_path': os.path.join(self.tools_dir, 'procexp.exe'),
                'description': '微软官方进程管理工具',
                'expected_size': 0  # 可配置预期文件大小，用于验证
            },
            'geek_uninstaller': {
                'name': 'Geek Uninstaller',
                'local_path': os.path.join(self.tools_dir, 'geek.exe'),
                'description': '轻量高效的软件卸载工具',
                'expected_size': 0  # 可配置预期文件大小，用于验证
            }
        }
    
    def check_tool_exists(self, tool_name):
        """检查工具是否存在"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        tool = self.tools[tool_name]
        
        # 检查工具文件是否存在
        if os.path.exists(tool['local_path']):
            # 检查文件大小（可选）
            if tool['expected_size'] > 0:
                actual_size = os.path.getsize(tool['local_path'])
                if actual_size >= tool['expected_size']:
                    return True, f"{tool['name']} 已就绪"
                else:
                    return False, f"{tool['name']} 文件不完整，请重新放置到工具目录"
            return True, f"{tool['name']} 已就绪"
        else:
            # 特殊处理geek.7z文件
            if tool_name == 'geek_uninstaller':
                geek_7z_path = os.path.join(self.tools_dir, 'geek.7z')
                if os.path.exists(geek_7z_path):
                    return False, f"找到 {os.path.basename(geek_7z_path)}，但需要解压。请手动解压并将 {os.path.basename(tool['local_path'])} 放置到 {self.tools_dir} 目录"
            return False, f"{tool['name']} 未找到，请将 {os.path.basename(tool['local_path'])} 放置到 {self.tools_dir} 目录"
    
    def run_process_explorer(self):
        """运行Process Explorer"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        # 检查工具是否存在
        exists, msg = self.check_tool_exists('process_explorer')
        if not exists:
            return False, msg
        
        # 运行工具
        try:
            tool = self.tools['process_explorer']
            subprocess.Popen(tool['local_path'], shell=True)
            return True, f"已启动 {tool['name']}"
        except Exception as e:
            return False, f"启动 {self.tools['process_explorer']['name']} 失败: {e}"
    
    def run_geek_uninstaller(self):
        """运行Geek Uninstaller"""
        if not self.is_windows:
            return False, "此功能仅支持Windows系统"
        
        # 检查工具是否存在
        exists, msg = self.check_tool_exists('geek_uninstaller')
        if not exists:
            return False, msg
        
        # 运行工具
        try:
            tool = self.tools['geek_uninstaller']
            subprocess.Popen(tool['local_path'], shell=True)
            return True, f"已启动 {tool['name']}"
        except Exception as e:
            return False, f"启动 {self.tools['geek_uninstaller']['name']} 失败: {e}"


class StartupManager:
    """自研启动项管理器"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
    
    def get_startup_items(self):
        """获取启动项列表"""
        startup_items = []
        
        if self.is_windows:
            # Windows系统启动项位置
            startup_locations = [
                # 注册表位置
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
                # 启动文件夹
                os.path.join(os.environ.get('APPDATA', ''), r'Microsoft\Windows\Start Menu\Programs\Startup'),
                os.path.join(os.environ.get('ALLUSERSPROFILE', ''), r'Microsoft\Windows\Start Menu\Programs\Startup')
            ]
            
            # 读取注册表启动项
            for hkey, path in startup_locations[:4]:
                if winreg is None:
                    continue
                try:
                    key = winreg.OpenKey(hkey, path, 0, winreg.KEY_READ)
                    try:
                        index = 0
                        while True:
                            name, value, _ = winreg.EnumValue(key, index)
                            startup_items.append((name, value, 'registry'))
                            index += 1
                    except OSError:
                        pass
                    winreg.CloseKey(key)
                except:
                    pass
            
            # 读取启动文件夹
            for folder in startup_locations[4:]:
                if os.path.exists(folder):
                    for item in os.listdir(folder):
                        item_path = os.path.join(folder, item)
                        startup_items.append((item, item_path, 'folder'))
        
        return startup_items
    
    def disable_startup_item(self, name, location):
        """禁用启动项"""
        try:
            if location == 'registry':
                # 注册表启动项，添加.disabled后缀
                pass
            elif location == 'folder':
                # 启动文件夹，重命名添加.disabled后缀
                new_path = location + '.disabled'
                os.rename(location, new_path)
                return True, f"已禁用：{os.path.basename(location)}"
            return False, "不支持的操作"
        except Exception as e:
            return False, f"禁用失败：{e}"


class AVScanner:
    """杀毒软件主类，封装所有功能"""
    
    def __init__(self, output_queue=None, progress_callback=None):
        self.is_windows = sys.platform.startswith('win')
        self.output_queue = output_queue  # 用于GUI输出的队列
        self.progress_callback = progress_callback  # 用于进度更新的回调
        self.system_cleaner = SystemCleaner()
        self.startup_manager = StartupManager()
        self.third_party_tools = ThirdPartyTools()
        # 尝试查找mpcmdrun.exe
        self.mpcmdrun_path = self._find_mpcmdrun() if self.is_windows else None
    
    def _log(self, message):
        """记录日志，支持GUI和命令行"""
        if self.output_queue:
            self.output_queue.put(message)
        else:
            print(message)
    
    def _update_progress(self, progress, message=None):
        """更新进度"""
        if self.progress_callback:
            self.progress_callback(progress, message)
    
    def _find_mpcmdrun(self):
        """查找mpcmdrun.exe的路径"""
        possible_paths = [
            r'C:\Program Files\Windows Defender\MpCmdRun.exe',
            r'C:\Program Files (x86)\Windows Defender\MpCmdRun.exe',
            r'C:\ProgramData\Microsoft\Windows Defender\Platform\*\MpCmdRun.exe'
        ]
        
        for path in possible_paths:
            if '*' in path:
                # 处理通配符路径
                base_path = Path(path.rsplit('*', 1)[0])
                if base_path.exists():
                    # 找到最新版本的目录
                    try:
                        latest_version = sorted([d for d in base_path.iterdir() if d.is_dir()], reverse=True)[0]
                        mp_path = latest_version / 'MpCmdRun.exe'
                        if mp_path.exists():
                            return str(mp_path)
                    except IndexError:
                        continue
            else:
                if os.path.exists(path):
                    return path
        
        return None
    
    def is_admin(self):
        """检查是否以管理员权限运行"""
        if not self.is_windows:
            # 非Windows系统返回False
            return False
            
        try:
            # 更可靠的管理员权限检测
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except AttributeError:
            # 兼容不同Windows版本
            if winreg is not None:
                try:
                    # 尝试通过访问受限注册表项来检测
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", 0, winreg.KEY_READ)
                    winreg.CloseKey(key)
                    return True
                except PermissionError:
                    return False
                except:
                    return False
            return False
        except:
            return False
    
    def run_as_admin(self):
        """以管理员权限重新运行程序"""
        if not self.is_windows:
            return
            
        try:
            # 获取当前脚本的完整路径
            script_path = os.path.abspath(sys.argv[0])
            
            # 构建命令行参数
            params = ' '.join(sys.argv[1:])
            
            # 使用ShellExecuteW以管理员权限重新运行
            result = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, f'"{script_path}" {params}', None, 1
            )
            
            # 检查是否成功
            if result <= 32:
                self._log(f"错误：无法以管理员权限运行程序，错误码：{result}")
        except Exception as e:
            self._log(f"错误：提权过程中发生异常：{e}")
    
    def scan(self, scan_type="quick", path=None):
        """执行病毒扫描，仅使用Windows Defender"""
        if not self.is_windows:
            self._log("错误：此功能仅支持Windows系统")
            return False
        
        if not self.mpcmdrun_path:
            self._log("错误：未找到Windows Defender的MpCmdRun.exe")
            return False
        
        # 使用Windows Defender扫描
        self._log(f"\n=== 开始Windows Defender扫描 ===")
        self._log(f"扫描类型：{scan_type}")
        if path:
            self._log(f"扫描路径：{path}")
    
        # 构建扫描命令
        cmd = [self.mpcmdrun_path, "-Scan"]
    
        if scan_type == "quick":
            cmd.append("-ScanType 1")
        elif scan_type == "full":
            cmd.append("-ScanType 2")
        elif scan_type == "custom" and path:
            cmd.append(f"-ScanType 3")
            cmd.append(f"-File {path}")
        else:
            self._log("错误：无效的扫描类型或路径")
            return False
    
        # 添加额外参数以获取详细输出
        cmd.append("-Trace -Level 0x10")
    
        try:
            # 执行扫描命令并实时显示输出
            process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                text=True,
                shell=True
            )
        
            # 更新进度
            self._update_progress(10, "正在初始化扫描...")
        
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    self._log(output.strip())
                    # 简单的进度更新
                    if "扫描完成" in output:
                        self._update_progress(90, "扫描即将完成...")
        
            return_code = process.poll()
            self._update_progress(100, "扫描完成")
            if return_code == 0:
                self._log("\n=== 扫描完成：未发现威胁 ===")
                return True
            else:
                self._log(f"\n=== 扫描完成：发现威胁，请查看以上输出 ===")
                return False
                
        except Exception as e:
            self._log(f"错误：Windows Defender扫描过程中发生异常：{e}")
            return False
    
    def clean_temp(self):
        """清理系统临时文件"""
        self._log(f"\n=== 准备清理临时文件 ===")
        self._log(f"清理目标：{', '.join(self.system_cleaner._get_temp_dirs())}")
        
        # 调用自研清理器
        self._update_progress(10, "正在初始化清理...")
        results = self.system_cleaner.clean_temp_files(confirm=False)
        
        # 显示清理报告
        self._update_progress(50, "正在清理文件...")
        for log in results['logs']:
            self._log(log)
        
        self._update_progress(100, "清理完成")
        self._log(f"\n=== 清理报告 ===")
        self._log(f"总文件数：{results['total_files']}")
        self._log(f"成功删除：{results['cleaned_files']} 个文件")
        self._log(f"释放空间：{results['cleaned_size'] / (1024 * 1024):.2f} MB")
        self._log(f"失败文件数：{results['failed_files']}")
        
        return True
    
    def run_all(self):
        """执行全部功能"""
        self._log("=== 执行全部功能 ===")
        
        # 先执行快速扫描
        scan_result = self.scan(scan_type="quick")
        
        # 再执行清理
        clean_result = self.clean_temp()
        
        return scan_result and clean_result
    
    def get_startup_items(self):
        """获取启动项列表"""
        return self.startup_manager.get_startup_items()
    
    def disable_startup_item(self, name, location):
        """禁用启动项"""
        return self.startup_manager.disable_startup_item(name, location)


class AVGUI:
    """杀毒软件GUI类"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("720安全卫士")
        # 设置正常全屏（窗口最大化）
        self.root.state('zoomed')
        
        # 创建输出队列和AVScanner实例
        self.output_queue = queue.Queue()
        self.av_scanner = AVScanner(self.output_queue, self.update_progress)
        
        # 检查管理员权限（直接提权，不显示提示）
        self.check_admin()
        
        # 创建GUI组件
        self.create_widgets()
        
        # 启动输出更新线程
        self.running = True
        self.update_thread = threading.Thread(target=self.update_output, daemon=True)
        self.update_thread.start()
        
        # 初始化状态
        self.current_status = "就绪"
        self.update_status(self.current_status)
    
    def create_widgets(self):
        """创建GUI组件"""
        # 设置绿色主题
        style = ttk.Style()
        style.theme_use('clam')  # 使用clam主题作为基础
        
        # 重置所有样式
        style.configure('TButton', 
                       background='#4CAF50', 
                       foreground='white',
                       font=('微软雅黑', 10),
                       padding=6)
        style.map('TButton', 
                 background=[('active', '#45a049')])
        
        style.configure('TLabel', 
                       font=('微软雅黑', 10),
                       background='#f0f8f0',
                       relief='flat')
        
        style.configure('TFrame', 
                       background='#f0f8f0',
                       relief='flat')
        
        style.configure('TLabelframe', 
                       background='#f0f8f0',
                       labelforeground='#4CAF50',
                       font=('微软雅黑', 10, 'bold'),
                       relief='groove')
        
        style.configure('TLabelframe.Label', 
                       background='#f0f8f0',
                       relief='flat')
        
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建顶部状态栏
        status_frame = ttk.Frame(main_frame, padding="5")
        status_frame.pack(fill=tk.X, pady=5)
        
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        status_label = ttk.Label(status_frame, text="状态: ", font=('微软雅黑', 10, 'bold'))
        status_label.pack(side=tk.LEFT, padx=5)
        
        self.status_display = ttk.Label(status_frame, textvariable=self.status_var, font=('微软雅黑', 10))
        self.status_display.pack(side=tk.LEFT, padx=5)
        
        # 系统状态指示器
        self.status_indicator = tk.Canvas(status_frame, width=10, height=10, bg="green", relief="raised")
        self.status_indicator.pack(side=tk.LEFT, padx=5)
        
        # 创建主内容区
        content_frame = ttk.Frame(main_frame)
        content_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 左侧功能区
        left_frame = ttk.Frame(content_frame, width=200)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # 创建导航按钮
        self.nav_buttons = {
            "home": ttk.Button(left_frame, text="主页", width=15, command=self.show_home),
            "scan": ttk.Button(left_frame, text="病毒扫描", width=15, command=self.show_scan),
            "clean": ttk.Button(left_frame, text="系统清理", width=15, command=self.show_clean),
            "manage": ttk.Button(left_frame, text="系统管理", width=15, command=self.show_manage),
            "uninstall": ttk.Button(left_frame, text="软件卸载", width=15, command=self.show_uninstall)
        }
        
        for i, (key, button) in enumerate(self.nav_buttons.items()):
            button.pack(pady=5, padx=10)
        
        # 右侧内容区
        self.right_frame = ttk.Frame(content_frame)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)
        
        # 显示主页
        self.show_home()
        
        # 创建底部输出区域
        output_frame = ttk.LabelFrame(main_frame, text="操作日志", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=False, pady=5, ipady=50)
        
        # 创建滚动条和文本框
        self.output_text = tk.Text(output_frame, wrap=tk.WORD, state=tk.DISABLED, height=10,
                                  background='#f0f8f0', foreground='#333333', font=('微软雅黑', 9))
        scrollbar = ttk.Scrollbar(output_frame, orient=tk.VERTICAL, command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # 创建进度条
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(main_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, pady=5)
        
        self.progress_label = ttk.Label(main_frame, text="", font=('微软雅黑', 9))
        self.progress_label.pack(anchor=tk.W, padx=10)
    
    def show_home(self):
        """显示主页"""
        self.clear_right_frame()
        
        # 创建主页内容
        home_frame = ttk.Frame(self.right_frame)
        home_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(home_frame, text="720安全卫士", font=('微软雅黑', 24, 'bold'))
        title_label.pack(pady=20)
        
        # 系统状态卡片
        status_card = ttk.LabelFrame(home_frame, text="系统状态", padding="20")
        status_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 状态信息
        status_info = ttk.Label(status_card, text="您的系统当前状态良好，未发现威胁。", font=('微软雅黑', 12))
        status_info.pack(pady=10)
        
        # 快速操作卡片
        quick_card = ttk.LabelFrame(home_frame, text="快速操作", padding="20")
        quick_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 快速操作按钮
        quick_frame = ttk.Frame(quick_card)
        quick_frame.pack(fill=tk.X, pady=10)
        
        self.quick_scan_btn = ttk.Button(quick_frame, text="快速扫描", width=20, command=self.quick_scan)
        self.quick_scan_btn.pack(side=tk.LEFT, padx=10)
        
        self.quick_clean_btn = ttk.Button(quick_frame, text="清理垃圾", width=20, command=self.clean_temp)
        self.quick_clean_btn.pack(side=tk.LEFT, padx=10)
        
        self.quick_all_btn = ttk.Button(quick_frame, text="全面体检", width=20, command=self.run_all)
        self.quick_all_btn.pack(side=tk.LEFT, padx=10)
        
        # 功能介绍卡片
        feature_card = ttk.LabelFrame(home_frame, text="功能介绍", padding="20")
        feature_card.pack(fill=tk.BOTH, expand=True, pady=10, padx=20)
        
        features = [
            "• 病毒扫描：快速扫描、全盘扫描、自定义扫描",
            "• 系统清理：清理临时文件、浏览器缓存",
            "• 系统管理：启动项管理、进程管理",
            "• 软件卸载：快速卸载不需要的软件"
        ]
        
        for feature in features:
            feature_label = ttk.Label(feature_card, text=feature, font=('微软雅黑', 10))
            feature_label.pack(anchor=tk.W, pady=5)
    
    def show_scan(self):
        """显示病毒扫描页面"""
        self.clear_right_frame()
        
        # 创建扫描页面内容
        scan_frame = ttk.Frame(self.right_frame)
        scan_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(scan_frame, text="病毒扫描", font=('微软雅黑', 18, 'bold'))
        title_label.pack(pady=20)
        
        # 扫描选项卡片
        scan_card = ttk.LabelFrame(scan_frame, text="扫描选项", padding="20")
        scan_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 扫描选项按钮
        scan_buttons_frame = ttk.Frame(scan_card)
        scan_buttons_frame.pack(fill=tk.X, pady=10)
        
        self.quick_scan_btn = ttk.Button(scan_buttons_frame, text="快速扫描", width=20, command=self.quick_scan)
        self.quick_scan_btn.pack(side=tk.LEFT, padx=10)
        
        self.full_scan_btn = ttk.Button(scan_buttons_frame, text="全盘扫描", width=20, command=self.full_scan)
        self.full_scan_btn.pack(side=tk.LEFT, padx=10)
        
        self.custom_scan_btn = ttk.Button(scan_buttons_frame, text="自定义扫描", width=20, command=self.custom_scan)
        self.custom_scan_btn.pack(side=tk.LEFT, padx=10)
        
        # 扫描说明
        info_card = ttk.LabelFrame(scan_frame, text="扫描说明", padding="20")
        info_card.pack(fill=tk.BOTH, expand=True, pady=10, padx=20)
        
        info_text = """
快速扫描：扫描系统关键区域和运行进程，耗时较短
全盘扫描：扫描所有驱动器，彻底检查系统，耗时较长
自定义扫描：扫描指定路径，针对性检查特定文件夹

720安全卫士会优先使用Windows Defender进行扫描，
如果不可用则使用自研扫描引擎作为备选。
        """
        info_label = ttk.Label(info_card, text=info_text, font=('微软雅黑', 10), justify=tk.LEFT)
        info_label.pack(anchor=tk.W, pady=5)
    
    def show_clean(self):
        """显示系统清理页面"""
        self.clear_right_frame()
        
        # 创建清理页面内容
        clean_frame = ttk.Frame(self.right_frame)
        clean_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(clean_frame, text="系统清理", font=('微软雅黑', 18, 'bold'))
        title_label.pack(pady=20)
        
        # 清理选项卡片
        clean_card = ttk.LabelFrame(clean_frame, text="清理选项", padding="20")
        clean_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 清理选项按钮
        clean_buttons_frame = ttk.Frame(clean_card)
        clean_buttons_frame.pack(fill=tk.X, pady=10)
        
        self.clean_temp_btn = ttk.Button(clean_buttons_frame, text="清理临时文件", width=20, command=self.clean_temp)
        self.clean_temp_btn.pack(side=tk.LEFT, padx=10)
        
        self.clean_browser_btn = ttk.Button(clean_buttons_frame, text="清理浏览器缓存", width=20, command=self.clean_browser)
        self.clean_browser_btn.pack(side=tk.LEFT, padx=10)
        
        # 清理说明
        info_card = ttk.LabelFrame(clean_frame, text="清理说明", padding="20")
        info_card.pack(fill=tk.BOTH, expand=True, pady=10, padx=20)
        
        info_text = """
临时文件清理：删除系统临时目录中的文件，释放磁盘空间
浏览器缓存清理：清理Chrome、Edge、Firefox等浏览器的缓存文件

清理操作不会影响系统正常运行，只会删除无用的临时文件。
        """
        info_label = ttk.Label(info_card, text=info_text, font=('微软雅黑', 10), justify=tk.LEFT)
        info_label.pack(anchor=tk.W, pady=5)
    
    def show_manage(self):
        """显示系统管理页面"""
        self.clear_right_frame()
        
        # 创建管理页面内容
        manage_frame = ttk.Frame(self.right_frame)
        manage_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(manage_frame, text="系统管理", font=('微软雅黑', 18, 'bold'))
        title_label.pack(pady=20)
        
        # 管理选项卡片
        manage_card = ttk.LabelFrame(manage_frame, text="管理选项", padding="20")
        manage_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 管理选项按钮
        manage_buttons_frame = ttk.Frame(manage_card)
        manage_buttons_frame.pack(fill=tk.X, pady=10)
        
        self.startup_btn = ttk.Button(manage_buttons_frame, text="启动项管理", width=20, command=self.startup_manage)
        self.startup_btn.pack(side=tk.LEFT, padx=10)
        
        self.process_btn = ttk.Button(manage_buttons_frame, text="进程管理", width=20, command=self.process_manage)
        self.process_btn.pack(side=tk.LEFT, padx=10)
        
        # 管理说明
        info_card = ttk.LabelFrame(manage_frame, text="管理说明", padding="20")
        info_card.pack(fill=tk.BOTH, expand=True, pady=10, padx=20)
        
        info_text = """
启动项管理：查看和禁用系统启动项，加速系统启动
进程管理：使用Process Explorer管理系统进程

这些功能需要管理员权限才能正常使用。
        """
        info_label = ttk.Label(info_card, text=info_text, font=('微软雅黑', 10), justify=tk.LEFT)
        info_label.pack(anchor=tk.W, pady=5)
    
    def show_uninstall(self):
        """显示软件卸载页面"""
        self.clear_right_frame()
        
        # 创建卸载页面内容
        uninstall_frame = ttk.Frame(self.right_frame)
        uninstall_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(uninstall_frame, text="软件卸载", font=('微软雅黑', 18, 'bold'))
        title_label.pack(pady=20)
        
        # 卸载选项卡片
        uninstall_card = ttk.LabelFrame(uninstall_frame, text="卸载选项", padding="20")
        uninstall_card.pack(fill=tk.X, pady=10, padx=20)
        
        # 卸载按钮
        uninstall_buttons_frame = ttk.Frame(uninstall_card)
        uninstall_buttons_frame.pack(fill=tk.X, pady=10)
        
        self.uninstall_btn = ttk.Button(uninstall_buttons_frame, text="打开卸载工具", width=30, command=self.uninstall_software)
        self.uninstall_btn.pack(side=tk.LEFT, padx=10)
        
        # 卸载说明
        info_card = ttk.LabelFrame(uninstall_frame, text="卸载说明", padding="20")
        info_card.pack(fill=tk.BOTH, expand=True, pady=10, padx=20)
        
        info_text = """
720安全卫士使用Geek Uninstaller进行软件卸载，
它可以彻底卸载软件并清理残留文件。

使用前请确保tools目录中存在geek.exe文件。
        """
        info_label = ttk.Label(info_card, text=info_text, font=('微软雅黑', 10), justify=tk.LEFT)
        info_label.pack(anchor=tk.W, pady=5)
    
    def clear_right_frame(self):
        """清空右侧内容区"""
        for widget in self.right_frame.winfo_children():
            widget.destroy()
    
    def check_admin(self):
        """检查管理员权限，直接提权"""
        if not self.av_scanner.is_admin() and self.av_scanner.is_windows:
            # 直接提权，不显示提示
            self.av_scanner.run_as_admin()
            self.root.quit()
            sys.exit(0)
    
    def update_output(self):
        """更新输出文本框"""
        while self.running:
            try:
                message = self.output_queue.get(timeout=0.5)
                self.output_text.config(state=tk.NORMAL)
                self.output_text.insert(tk.END, message + "\n")
                self.output_text.see(tk.END)
                self.output_text.config(state=tk.DISABLED)
            except queue.Empty:
                continue
    
    def update_progress(self, progress, message=None):
        """更新进度条"""
        self.progress_var.set(progress)
        if message:
            self.progress_label.config(text=message)
        self.root.update_idletasks()
    
    def update_status(self, status):
        """更新状态栏"""
        self.status_var.set(status)
        self.current_status = status
        
        # 更新状态指示器颜色
        if status == "就绪":
            self.status_indicator.config(bg="green")
        elif "扫描" in status or "清理" in status:
            self.status_indicator.config(bg="blue")
        elif "错误" in status:
            self.status_indicator.config(bg="red")
        else:
            self.status_indicator.config(bg="yellow")
        
        self.root.update_idletasks()
    
    def disable_buttons(self):
        """禁用所有按钮"""
        # 禁用导航按钮
        for btn in self.nav_buttons.values():
            btn.config(state=tk.DISABLED)
        
        # 禁用功能按钮
        try:
            self.quick_scan_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.full_scan_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.custom_scan_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.clean_temp_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.clean_browser_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.startup_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.process_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.uninstall_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.quick_all_btn.config(state=tk.DISABLED)
        except:
            pass
        try:
            self.quick_clean_btn.config(state=tk.DISABLED)
        except:
            pass
    
    def enable_buttons(self):
        """启用所有按钮"""
        # 启用导航按钮
        for btn in self.nav_buttons.values():
            btn.config(state=tk.NORMAL)
        
        # 启用功能按钮
        try:
            self.quick_scan_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.full_scan_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.custom_scan_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.clean_temp_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.clean_browser_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.startup_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.process_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.uninstall_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.quick_all_btn.config(state=tk.NORMAL)
        except:
            pass
        try:
            self.quick_clean_btn.config(state=tk.NORMAL)
        except:
            pass
    
    def quick_scan(self):
        """快速扫描"""
        def scan_thread():
            self.update_status("正在执行快速扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="quick")
            self.update_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def full_scan(self):
        """全盘扫描"""
        def scan_thread():
            self.update_status("正在执行全盘扫描...")
            self.disable_buttons()
            self.av_scanner.scan(scan_type="full")
            self.update_status("就绪")
            self.enable_buttons()
        
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def custom_scan(self):
        """指定路径扫描"""
        path = filedialog.askdirectory(title="选择要扫描的目录")
        if path:
            def scan_thread():
                self.update_status("正在执行指定路径扫描...")
                self.disable_buttons()
                self.av_scanner.scan(scan_type="custom", path=path)
                self.update_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=scan_thread, daemon=True).start()
    
    def clean_temp(self):
        """清理临时文件"""
        response = messagebox.askyesno("清理确认", "此操作将删除系统临时目录中的文件，是否继续？")
        if response:
            def clean_thread():
                self.update_status("正在清理临时文件...")
                self.disable_buttons()
                self.av_scanner.clean_temp()
                self.update_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=clean_thread, daemon=True).start()
    
    def clean_browser(self):
        """清理浏览器缓存"""
        response = messagebox.askyesno("清理确认", "此操作将清理浏览器缓存文件，是否继续？")
        if response:
            def clean_thread():
                self.update_status("正在清理浏览器缓存...")
                self.disable_buttons()
                results = self.av_scanner.system_cleaner.clean_browser_cache()
                for log in results['logs']:
                    self.av_scanner._log(log)
                self.av_scanner._log(f"浏览器缓存清理完成，共清理 {results['cleaned']} 项")
                self.update_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=clean_thread, daemon=True).start()
    
    def run_all(self):
        """执行全部功能"""
        response = messagebox.askyesno("全部功能确认", "此操作将先执行快速扫描，然后清理临时文件，是否继续？")
        if response:
            def all_thread():
                self.update_status("正在执行全部功能...")
                self.disable_buttons()
                self.av_scanner.run_all()
                self.update_status("就绪")
                self.enable_buttons()
            
            threading.Thread(target=all_thread, daemon=True).start()
    
    def startup_manage(self):
        """启动项管理功能"""
        if not self.av_scanner.is_windows:
            messagebox.showerror("错误", "此功能仅支持Windows系统")
            return
            
        # 创建启动项管理窗口
        startup_window = tk.Toplevel(self.root)
        startup_window.title("启动项管理")
        startup_window.geometry("800x600")
        
        # 创建列表框
        list_frame = ttk.Frame(startup_window, padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建树视图
        columns = ("name", "path", "type")
        tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        tree.heading("name", text="名称")
        tree.heading("path", text="路径")
        tree.heading("type", text="类型")
        
        # 设置列宽
        tree.column("name", width=150)
        tree.column("path", width=500)
        tree.column("type", width=100)
        
        # 添加滚动条
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 加载启动项
        def load_startup_items():
            # 清空现有数据
            for item in tree.get_children():
                tree.delete(item)
            
            # 获取启动项
            startup_items = self.av_scanner.get_startup_items()
            for name, path, item_type in startup_items:
                tree.insert("", tk.END, values=(name, path, item_type))
        
        # 禁用选中的启动项
        def disable_selected():
            selected_item = tree.selection()
            if selected_item:
                item = tree.item(selected_item[0])
                name, path, item_type = item["values"]
                success, msg = self.av_scanner.disable_startup_item(name, path)
                if success:
                    messagebox.showinfo("成功", msg)
                    load_startup_items()
                else:
                    messagebox.showerror("错误", msg)
        
        # 创建按钮框架
        btn_frame = ttk.Frame(startup_window, padding="10")
        btn_frame.pack(fill=tk.X)
        
        refresh_btn = ttk.Button(btn_frame, text="刷新列表", command=load_startup_items)
        refresh_btn.pack(side=tk.LEFT, padx=5)
        
        disable_btn = ttk.Button(btn_frame, text="禁用选中项", command=disable_selected)
        disable_btn.pack(side=tk.LEFT, padx=5)
        
        # 初始加载
        load_startup_items()
    
    def process_manage(self):
        """运行第三方进程管理器 Process Explorer"""
        def process_thread():
            self.update_status("正在启动Process Explorer...")
            self.av_scanner._log("=== 启动Process Explorer ===")
            
            # 运行第三方工具
            success, msg = self.av_scanner.third_party_tools.run_process_explorer()
            if success:
                self.av_scanner._log(msg)
            else:
                messagebox.showerror("错误", msg)
                self.av_scanner._log(f"错误：{msg}")
            
            self.update_status("就绪")
        
        threading.Thread(target=process_thread, daemon=True).start()
    
    def uninstall_software(self):
        """运行第三方卸载工具 Geek Uninstaller"""
        def uninstall_thread():
            self.update_status("正在启动Geek Uninstaller...")
            self.av_scanner._log("=== 启动Geek Uninstaller ===")
            
            # 运行第三方工具
            success, msg = self.av_scanner.third_party_tools.run_geek_uninstaller()
            if success:
                self.av_scanner._log(msg)
            else:
                messagebox.showerror("错误", msg)
                self.av_scanner._log(f"错误：{msg}")
            
            self.update_status("就绪")
        
        threading.Thread(target=uninstall_thread, daemon=True).start()
    
    def on_closing(self):
        """窗口关闭事件处理"""
        self.running = False
        self.root.quit()
        sys.exit(0)


def main():
    """主函数"""
    try:
        # 创建主窗口
        root = tk.Tk()
        app = AVGUI(root)
        
        # 设置窗口关闭事件
        root.protocol("WM_DELETE_WINDOW", app.on_closing)
        
        # 运行主循环
        root.mainloop()
    except KeyboardInterrupt:
        print("程序已退出")
    except Exception as e:
        print(f"发生错误：{e}")
        input("按Enter键退出...")


if __name__ == "__main__":
    main()